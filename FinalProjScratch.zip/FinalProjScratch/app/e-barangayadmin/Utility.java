import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Map;

public class Utility {


    static DatabaseReference databaseReference;

    public static boolean onlyLetters(String input) {
        // Regular expression to check if the string contains numbers
        String regex = "^[a-zA-Z\\s]+$";
        return input.matches(regex);
    }

    public static boolean onlyLettersNsymbols(String input) {
        // Regular expression to check if the string contains numbers
        String regex = "^[a-zA-Z\\s\\W_]*$";
        return input.matches(regex);
    }

    public static void confirmGreen(EditText correct, Context context, Activity activity){
        correct.setCompoundDrawables(null, null, null, null);
        correct.setError(null);
        correct.invalidate();
        Drawable greenIcon = ContextCompat.getDrawable(activity, R.drawable.ic_action_accepted);// Replace with your drawable resource
        correct.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, greenIcon, null);
        int acceptedColor = ContextCompat.getColor(context, R.color.acceptedGreen);
        correct.setTextColor(acceptedColor);
    }

    public static void rejectRed(EditText reject, Context context, Activity activity){
        reject.setCompoundDrawables(null, null, null, null);
        Drawable redIcon =  ContextCompat.getDrawable(activity, R.drawable.ic_action_rejected); // Replace with your drawable resource
        reject.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, redIcon, null);
        reject.invalidate();
        int rejectedColor = ContextCompat.getColor(context, R.color.rejectedRed);
        reject.setTextColor(rejectedColor);
    }

    public static void resetColor(EditText correct, Context context){
        correct.invalidate();
        correct.setCompoundDrawables(null, null, null, null);
        int resetColor = ContextCompat.getColor(context, R.color.white);
        correct.setTextColor(resetColor);
    }

    public static void nextPage(TabLayout tabLayoutFromBase, int position){
        // Delay in milliseconds
        long delayMillis = 2000; // 2 seconds

        CountDownTimer countDownTimer = new CountDownTimer(delayMillis, delayMillis) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Not used in this example
            }

            @Override
            public void onFinish() {
                TabLayout.Tab selectTab = tabLayoutFromBase.getTabAt(position + 1);
                if (selectTab != null){
                    selectTab.select();
                }
            }
        };

        countDownTimer.start();


    }

    public static void hideKeyboard(Activity activity) {
        View view = activity.findViewById(android.R.id.content);
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public interface nameCallback {
        void onFullNameReceived(String firstName);
    }


    public interface DocCountCallback {
        void onDocCountReceived(int counter);
    }

    public interface RequestStatusCallback {
        void onStatusReceived(String Status);
    }



    public static void getFullName(String userId, nameCallback callback) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/" + userId);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Accounts acc = snapshot.getValue(Accounts.class);

                    String fullName = acc.getFullname();


                    // Call the callback with the result
                    callback.onFullNameReceived(fullName);
                } else {
                    // Call the callback with null if the snapshot doesn't exist
                    callback.onFullNameReceived(null);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle errors
                callback.onFullNameReceived(null);
            }
        });
    }





    public static void getDocCount(String USERID, String REQID, DocCountCallback callback) {

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/"+USERID+"/Requests/"+REQID+"/requestedDocument");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    long initCount = snapshot.getChildrenCount();
                    int count = (int) initCount;
                    callback.onDocCountReceived(count);
                } else {
                    callback.onDocCountReceived(0);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onDocCountReceived(0);

            }
        });
    }

    public static void getReqStatus(String USERID, String REQID, RequestStatusCallback callback) {

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/"+USERID+"/Requests/"+REQID);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    String status = snapshot.getValue(requestsRecord.class).getStatus();
                    callback.onStatusReceived(status);
                } else {
                    callback.onStatusReceived("not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onStatusReceived("cancelled");

            }
        });
    }

    public static void updateFirebaseData(Map<String, Object> updateMap, Context context){

        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.updateChildren(updateMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();

            }
        });

    }




}
