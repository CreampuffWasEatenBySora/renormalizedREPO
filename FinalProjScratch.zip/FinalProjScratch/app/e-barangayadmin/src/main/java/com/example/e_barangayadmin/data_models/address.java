package com.example.e_barangayadmin.data_models;

public class address {

    private String municipality;
    private String barangay;

    private String subdivision;
    private String houseNum;

    private String phoneNum;


    public String getMunicipality() { return municipality; }
    public String getBarangay() { return barangay; }
    public String getSubdivision() { return subdivision; }
    public String getHouseNum() { return houseNum; }
    public String getPhoneNum() { return phoneNum; }

    public address(String municipality,
                   String barangay,
                   String subdivision,
                   String houseNum,
                   String phoneNum){

        this.municipality = municipality;
        this.barangay = barangay;
        this.subdivision = subdivision;
        this.houseNum = houseNum;
        this.phoneNum = phoneNum;

    }

    public address(){

    }


}
