package com.example.e_barangayadmin.account_pages;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayadmin.R;
import com.example.e_barangayadmin.data_models.AccountModel;
import com.example.e_barangayadmin.data_models.RequestFormModel;
import com.example.e_barangayadmin.homepage;
import com.example.e_barangayadmin.request_pages.request_list_adapter;
import com.example.e_barangayadmin.request_pages.request_list_page;
import com.google.android.gms.common.util.JsonUtils;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class account_list_page extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView emptyAlert, subheader, header;
    public static TabLayout tabLayout;
    TabLayout pagination;
    ImageButton back, filter;
    ImageView clear;
    ImageButton searchButton;
    EditText searchBox;
    static String listMode = "Client", status = "Pending", filterText ="";
    LinearLayout switcher;
    List<AccountModel> userslist = new ArrayList<>();
    int page = 1;

    int pageLimit = 5;
    List<AccountModel> limitedlist = new ArrayList<>();;

    static DatabaseReference databaseReference;
    static ValueEventListener accountListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_list);

        setUpComponents();
        populateList(listMode, "Pending", filterText);

   /*     back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
            }
        });*/

        switcher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listMode.equals("Client")){
                    subheader.setText("Switch to Client");
                    header.setText("Admin Accounts");
                    tabLayout.setVisibility(View.GONE);
                    listMode = "Admin";
                    populateList(listMode, "Verified", filterText);
                } else {
                    subheader.setText("Switch to Admin");
                    header.setText("Client Accounts");
                    tabLayout.setVisibility(View.VISIBLE);
                    listMode = "Client";
                    populateList(listMode, status, filterText);
                }
            }
        });


    }

    void setUpComponents(){

        subheader = findViewById(R.id.recycler_subheader);
        header = findViewById(R.id.recycler_header);
        switcher = findViewById(R.id.recycler_switcher);
        searchBox = findViewById(R.id.recycler_search);
        back = findViewById(R.id.recycler_backward);
        searchButton = findViewById(R.id.recycler_searchButton);
        pagination = findViewById(R.id.pagination_tab);
        clear  = findViewById(R.id.clearButton);
        tabLayout = findViewById(R.id.recycler_tab);
        emptyAlert = findViewById(R.id.recycler_emptyAlert);
        emptyAlert.setVisibility(View.GONE);
        clear.setVisibility(View.GONE);

        tabLayout.addTab(tabLayout.newTab().setText("Pending"));
        tabLayout.addTab(tabLayout.newTab().setText("Verified"));
        tabLayout.addTab(tabLayout.newTab().setText("Rejected"));
        tabLayout.setTabTextColors(getResources().getColorStateList(R.color.black));
        tabLayout.setSelectedTabIndicatorColor(getResources().getColor(R.color.blue));


        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        status = "Pending";

                        break;
                    case 1:
                        status = "Verified";
                        break;
                    case 2:
                        status = "Rejected";
                        break;
                    default:
                        status = "Pending"; // Default to pending if unknown tab is selected
                }
                populateList(listMode, status, filterText);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                // Called to notify you that somewhere within the text, characters have been added or removed.
                // This is where you can perform your action after the text has changed.
                filterText = editable.toString();
                // Add your logic here to handle the changed text
                if (filterText.isEmpty()){
                    clear.setVisibility(View.GONE);
                    populateList(listMode, status, filterText);

                } else {
                    clear.setVisibility(View.VISIBLE);
                }

            }
        });


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = searchBox.getText().toString();
                populateList(listMode, status, filterText);
            }
        });


        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = "";
                searchBox.setText("");
                populateList(listMode, status, filterText);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
            }
        });

    }


    void populateList(String AccountType, String status, String filter) {

        filter = filter.toLowerCase().trim();


        userslist = new ArrayList<>();

        ///" + homepage.currentAccount.getUserID()+"/Requests
        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
        String finalFilter = filter;
        accountListener = databaseReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot itemSnapShot: snapshot.getChildren()){

                    AccountModel account = itemSnapShot.getValue(AccountModel.class);

                    if (itemSnapShot.exists()) {

                        if (account.isAdmin() && AccountType.equals("Admin") && status.equals("Verified") && account.getFullname().toLowerCase().contains(finalFilter)){
                                    userslist.add(account);
                                    System.out.println("added: " + account.getFullname());
                                    System.out.println("List: " + userslist);

                                    setPaginationLimits(userslist.size());
                                    limitedPopulateList(page);


                        } else if(!account.isAdmin() && AccountType.equals("Client") && account.getStatus().equals(status)  && account.getFullname().toLowerCase().contains(finalFilter)) {
                                    userslist.add(account);
                                    System.out.println("added: " + account.getFullname());
                                    System.out.println("CList: " + userslist);
                                    setPaginationLimits(userslist.size());
                                    limitedPopulateList(page);
                        }

                    } else {

                        setPaginationLimits(userslist.size());
                        limitedPopulateList(page);
                    }


                }


                System.out.println(userslist.size());
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


    }


    void setPaginationLimits(int setSize){

        pagination.removeAllTabs();

        int pageNums = setSize / pageLimit;
        int remainder = setSize % pageLimit;
        for (int i = 0; i <= pageNums; i++) {

            if (!((remainder == 0) && (i == pageNums))){
                pagination.addTab(pagination.newTab().setText(String.valueOf(i+1)));
            }
        }

        pagination.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                limitedPopulateList(tab.getPosition()+1);
                page = tab.getPosition()+1;
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
    void limitedPopulateList(int page){


        limitedlist.clear();
        recyclerView = findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(account_list_page.this, 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        account_list_adapter adapter = new account_list_adapter(account_list_page.this, limitedlist);
        recyclerView.setAdapter(adapter);


        int startRange = (page * pageLimit) - pageLimit; // Calculate start index of the range
        int upperRange = Math.min(page * pageLimit, userslist.size()); // Calculate end index of the range

        limitedlist.clear(); // Clear limitedlist if needed

        for (int i = startRange; i < upperRange; i++) {
            limitedlist.add(userslist.get(i));
            adapter.notifyDataSetChanged();
        }

        if (userslist.isEmpty()){
            emptyAlert.setVisibility(View.VISIBLE);
        } else {
            emptyAlert.setVisibility(View.GONE);

        }
        System.out.println(limitedlist.size() + " and " + userslist.size());

        // Notify adapter after adding all items

    }



    void closeActivity(){

        finish();
        databaseReference.removeEventListener(accountListener);
        Intent intent = new Intent(getApplicationContext(),homepage.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {

        // replaces the default 'Back' button actions
        // Aside from this button, there's no other way to come out of this activity.
        if(keyCode==KeyEvent.KEYCODE_BACK )   {

            //This is made to prevent going back to the previous activities such as:
            // adding, editing , or interacting with elements.
            closeActivity();
        }
        return true;
    }
}