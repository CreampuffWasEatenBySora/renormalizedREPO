package com.example.e_barangayadmin.request_pages;

import static com.example.e_barangayadmin.Utility.getDocCount;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayadmin.R;
import com.example.e_barangayadmin.Utility;
import com.example.e_barangayadmin.data_models.AccountModel;
import com.example.e_barangayadmin.data_models.RequestFormModel;
import com.example.e_barangayadmin.homepage;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class request_list_page extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView emptyAlert;
    public static TabLayout tabLayout;
    TabLayout pagination;
    ImageButton back, searchButton, filter;
    EditText searchBox;

    int page = 1;

    int pageLimit = 5;
    List<RequestFormModel> requestsList;
    ImageView clear;
    static String filterText ="", status ="";

    List<RequestFormModel> limitedlist = new ArrayList<>();;
    
    public static DatabaseReference requestDatabaseReference;
    public static ValueEventListener requestListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_list);

        setUpComponents();
        int position  = tabLayout.getSelectedTabPosition();

        switch (position){

            case 0: populateList("Pending", filterText);
            break;

            case 1: populateList("Ready", filterText);
            break;

            case 2:populateList("Rejected", filterText);
            break;

            case 3:populateList("Collected", filterText);
            break;

            default:populateList("Pending", filterText);
            break;

        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
            }
        });


    }

    void setUpComponents(){

        back = findViewById(R.id.recycler_backward);
        searchBox = findViewById(R.id.recycler_search);
        searchButton = findViewById(R.id.request_searchButton);
        clear = findViewById(R.id.clearButton);
        tabLayout = findViewById(R.id.recycler_tab);
        pagination = findViewById(R.id.pagination_tab);
        emptyAlert = findViewById(R.id.recycler_emptyAlert);
        emptyAlert.setVisibility(View.GONE);
        clear.setVisibility(View.GONE);

        tabLayout.addTab(tabLayout.newTab().setText("Pending"));
        tabLayout.addTab(tabLayout.newTab().setText("Approved"));
        tabLayout.addTab(tabLayout.newTab().setText("Rejected"));
        tabLayout.addTab(tabLayout.newTab().setText("Collected"));


        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        status = "Pending";
                        break;
                    case 1:
                        status = "Ready";
                        break;
                    case 2:
                        status = "Rejected";
                        break;
                    case 3:
                        status = "Collected";
                        break;
                    default:
                        status = "Pending"; // Default to pending if unknown tab is selected
                }
                populateList(status, filterText);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                // Called to notify you that somewhere within the text, characters have been added or removed.
                // This is where you can perform your action after the text has changed.
                filterText = editable.toString();
                // Add your logic here to handle the changed text
                if (filterText.isEmpty()){
                    clear.setVisibility(View.GONE);
                    populateList(status, filterText);

                } else {
                    clear.setVisibility(View.VISIBLE);
                }

            }
        });


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = searchBox.getText().toString();
                populateList(status, filterText);
            }
        });


        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = "";
                searchBox.setText("");
                populateList(status, filterText);
            }
        });
    }


    void populateList(String status, String filter) {


        requestsList = new ArrayList<>();

        ///" + homepage.currentAccount.getUserID()+"/Requests
        int baseLimit = 10;

        requestDatabaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
        requestListener = requestDatabaseReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                requestsList.clear();

                for (DataSnapshot itemSnapShot: snapshot.getChildren()){

                    AccountModel account = itemSnapShot.getValue(AccountModel.class);

                    requestDatabaseReference = FirebaseDatabase.getInstance().getReference("Accounts/" + account.getUserID() + "/Requests");
                    requestListener = requestDatabaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot reqsnapshot) {

                            if (reqsnapshot.exists()){

                                for (DataSnapshot requestSnapshot: reqsnapshot.getChildren()){
                                    RequestFormModel request = requestSnapshot.getValue(RequestFormModel.class);
                                    if (request.getStatus().equals(status) && request.getRequestID().toLowerCase().contains(filter)) {

                                        getDocCount(request.getClientID(), request.getRequestID(), new Utility.DocCountCallback() {
                                            @Override
                                            public void onDocCountReceived(int counter) {
                                                if (counter != 0) {

                                                    requestsList.add(request);
                                                    setPaginationLimits(requestsList.size());
                                                    limitedPopulateList(page);

                                                }}});}
                                    else {

                                        setPaginationLimits(requestsList.size());
                                        limitedPopulateList(page);

                                    }



                                }
                            }
                            else {
                                setPaginationLimits(requestsList.size());
                                limitedPopulateList(page);
                            }


                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });



                }




            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


    }
    
    
    void setPaginationLimits(int setSize){

        pagination.removeAllTabs();

        int pageNums = setSize / pageLimit;
        int remainder = setSize % pageLimit;
        for (int i = 0; i <= pageNums; i++) {

            if (!((remainder == 0) && (i == pageNums))){
            pagination.addTab(pagination.newTab().setText(String.valueOf(i+1)));
            }
        }

        pagination.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                limitedPopulateList(tab.getPosition()+1);
                page = tab.getPosition()+1;
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        
    }
    void limitedPopulateList(int page){

        limitedlist.clear();
        recyclerView = findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(request_list_page.this, 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        request_list_adapter adapter = new request_list_adapter(request_list_page.this, limitedlist);
        recyclerView.setAdapter(adapter);

        int startRange = (page * pageLimit) - pageLimit; // Calculate start index of the range
        int upperRange = Math.min(page * pageLimit, requestsList.size()); // Calculate end index of the range

        limitedlist.clear(); // Clear limitedlist if needed
        for (int i = startRange; i < upperRange; i++) {
            limitedlist.add(requestsList.get(i));
            adapter.notifyDataSetChanged();
        }

        if (requestsList.isEmpty()){
            emptyAlert.setVisibility(View.VISIBLE);
        } else {
            emptyAlert.setVisibility(View.GONE);

        }

        // Notify adapter after adding all items

    }

    void closeActivity(){

        finish();
        Intent intent = new Intent(getApplicationContext(),homepage.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {

        // replaces the default 'Back' button actions
        // Aside from this button, there's no other way to come out of this activity.
        if(keyCode==KeyEvent.KEYCODE_BACK )   {

            //This is made to prevent going back to the previous activities such as:
            // adding, editing , or interacting with elements.
            closeActivity();
        }
        return true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        requestDatabaseReference.removeEventListener(requestListener);


    }
}