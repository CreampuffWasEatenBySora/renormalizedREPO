package com.example.e_barangayadmin.request_pages;

import static androidx.core.content.ContextCompat.startActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.e_barangayadmin.Utility;
import com.example.e_barangayadmin.data_models.AccountModel;
import com.example.e_barangayadmin.data_models.RequestFormModel;
import com.example.e_barangayadmin.data_models.RequestedDocumentModel;
import com.example.e_barangayadmin.document_pages.document_list_page;
import com.example.e_barangayadmin.homepage;
import com.example.e_barangayadmin.request_pages.viewing_request_detail_pages.requested_document_list_page;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class request_utilities_admin {

    static ValueEventListener eventListener;
    static DatabaseReference databaseReference;
    static List<String> tokens = new ArrayList<>();

    public static RequestFormModel request = new RequestFormModel("-", "-", null,"-","-","-","-","-","-" );
    public static int docCount = 0;
    public static AccountModel requestAccount = new AccountModel();


    public static void getRequest(String clientID, String requestID, Context context) {


        Utility.getRequest(clientID,requestID, new Utility.RequestObjectCallback() {
            @Override
            public void onRequestReceived(RequestFormModel fetchedRequest) {
                request = fetchedRequest;
                getAccount(context);

            }


        });

    }

    public static void countDocs() {


        Utility.getDocCount(request.getClientID(), request.getRequestID(), new Utility.DocCountCallback() {
            @Override
            public void onDocCountReceived(int counter) {
                docCount = counter;
            }
        });

    }

    public static void getAccount(Context context) {



        Utility.getAccount(request.getClientID(), new Utility.AccountObjectCallback() {
            @Override
            public void onAccountReceived(AccountModel account) {
                requestAccount = account;

                request_list_page.requestDatabaseReference.removeEventListener(request_list_page.requestListener);
                Intent intent = new Intent(context, requested_document_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);


            }

        });

    }

    static void LaunchRequestNotifications(String recipientToken){

        // Username, message, current userID, and recipient token

        //databaseReference.removeEventListener(eventListener);
        AccountModel currentUser = homepage.currentAccount;
        RequestFormModel request = request_utilities_admin.request;


        try {
            String title = "";
            String body = "";
            if (request.getStatus().equals("Ready")){
                title = "Your request was approved!";
                body = "Requested documents now ready to collect.";
            } else {
                title = "Sorry, your request was rejected...";
                body = "Please check the remarks of the rejection.";

            }
            JSONObject jsonObject = new JSONObject();
            JSONObject notifObject = new JSONObject();
            notifObject.put("title", title);
            notifObject.put("body", body);

            JSONObject dataObject = new JSONObject();
            dataObject.put("userId", currentUser.getUserID());
            dataObject.put("requestId",request.getRequestID());

            jsonObject.put("notification", notifObject);
            jsonObject.put("data", dataObject);
            jsonObject.put("to",recipientToken);

            System.out.println("sent to token: " + recipientToken);
            Utility.launchNotificationAPI(jsonObject);
        } catch (Exception e ){
            System.out.println("Error: " + e);
        }



    }

    public static void clearUtilityPage(){
        request = new RequestFormModel();
        docCount = 0;
        tokens.clear();

    }

    public static void updateViewedRequestForm(Context context, String status, String remark){



        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false); // prevent user from dismissing dialog
        progressDialog.show();

        Map<String, Object> updateMap = new HashMap<>();


        if (status.equals("Ready")){
            updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/status" , status);
            updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/dateRelease" , Utility.getDate());
            updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/confirmer" , homepage.currentAccount.getFullname());

        } else {
            updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/status" , status);
            updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/remarks" , remark);
            updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/confirmer" , homepage.currentAccount.getFullname());
            updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/dateRelease" , Utility.getDate());


        }


        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.updateChildren(updateMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                LaunchRequestNotifications(requestAccount.getDeviceToken());
                Toast.makeText(context, "request status updated", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();

                backToRequestList(context);
            }

        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(context, "request data update fail", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                backToRequestList(context);


            }
        });


    }

    static void backToRequestList(Context context){
        Intent intent = new Intent(context, request_list_page.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        clearUtilityPage();

    }

}
