package com.example.e_barangayadmin.request_pages;

import static com.example.e_barangayadmin.Utility.getDocCount;
import static com.example.e_barangayadmin.Utility.getFullName;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayadmin.R;
import com.example.e_barangayadmin.Utility;
import com.example.e_barangayadmin.data_models.RequestFormModel;
import com.example.e_barangayadmin.request_pages.viewing_request_detail_pages.requested_document_list_page;

import java.util.List;

public class request_list_adapter extends RecyclerView.Adapter<RequestListViewHolder> {


    private Context context;
    private List<RequestFormModel> requestList;

            public request_list_adapter (Context context, List<RequestFormModel> requests) {
                this.context = context;
                this.requestList = requests;
            }

            @NonNull
            @Override
            public RequestListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_card_for_request, parent, false);
                return new RequestListViewHolder(view);

            }

            @Override
            public void onBindViewHolder(@NonNull RequestListViewHolder holder, int position) {


                RequestFormModel request = requestList.get(position);
                holder.request_ID.setText(request.getRequestID());

                getFullName(request.getClientID(), new Utility.nameCallback() {
                    @Override
                    public void onFullNameReceived(String firstName) {
                        final String[] cardText = {firstName + " requested "};
                        getDocCount(request.getClientID(), request.getRequestID(), new Utility.DocCountCallback() {
                            @Override
                            public void onDocCountReceived(int counter) {


                                cardText[0] += counter + " document(s)";
                                holder.requestee_name.setText(cardText[0]);


                                if (request.getStatus().equals("Ready")){

                                    holder.request_dateNstatus.setText(request.getDateRelease());

                                } else if (request.getStatus().equals("Rejected")){

                                    holder.request_dateNstatus.setText(request.getDateRelease());

                                } else {

                                    holder.request_dateNstatus.setText(request.getDateRequested());

                                }

                                holder.requestCard.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        request_utilities_admin.getRequest(request.getClientID(), request.getRequestID(), context);
                                        request_list_page.requestDatabaseReference.removeEventListener(request_list_page.requestListener);

                                    }
                                });

                            }

                        });}});





            }

            @Override
            public int getItemCount() {
                return requestList.size();
            }
}

class RequestListViewHolder extends RecyclerView.ViewHolder{

    TextView requestee_name, request_dateNstatus, request_ID;
    CardView requestCard;


    public RequestListViewHolder(@NonNull View itemView){
        super(itemView);


        requestCard = itemView.findViewById(R.id.clientRequestCard);
        requestee_name = itemView.findViewById(R.id.clientRequestCard_Name);
        request_dateNstatus = itemView.findViewById(R.id.clientRequestCard_date);
        request_ID = itemView.findViewById(R.id.clientRequestCard_ID);

        try {
            Typeface interFont = ResourcesCompat.getFont(itemView.getContext(), R.font.inter);
            requestee_name.setTypeface(interFont);
            request_dateNstatus.setTypeface(interFont);
            request_ID.setTypeface(interFont);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



}
