package com.example.e_barangayadmin.account_pages;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.e_barangayadmin.R;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;

public class account_pending_image extends AppCompatActivity {
    StorageReference storageReference;
    String filepath;
    Button back;
    PhotoView docImg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_image);

        docImg = findViewById(R.id.docImage);

        back = findViewById(R.id.button);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(),account_pending_review.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        Bundle bundle = getIntent().getExtras();
        if (bundle != null ){
            filepath = bundle.getString("Path");
            if(filepath.contains("doc")){
                back.setText("Confirm document photo");
            } else{
                back.setText("Confirm Selfie photo");
            }
        }
        storageReference = FirebaseStorage.getInstance().getReference(filepath);
        System.out.println(storageReference.getName());
        System.out.println(filepath);

        try {

            ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Loading image...");
            progressDialog.setCancelable(false); // prevent user from dismissing dialog
            progressDialog.show();


            File localfile = File.createTempFile("tempfile", ".jpg");
            storageReference.getFile(localfile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                    Bitmap bitmap = BitmapFactory.decodeFile(localfile.getAbsolutePath());
                    System.out.println(localfile.getAbsolutePath());
                    docImg.setImageBitmap(bitmap);
                    progressDialog.dismiss();

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e)
                {
                    progressDialog.dismiss();
                    Toast.makeText(account_pending_image.this, "Image wasn't available.", Toast.LENGTH_LONG);
                    System.out.println(e.toString());
                }
            });

        } catch (IndexOutOfBoundsException | IOException e){
            e.printStackTrace();
        }
    }
}