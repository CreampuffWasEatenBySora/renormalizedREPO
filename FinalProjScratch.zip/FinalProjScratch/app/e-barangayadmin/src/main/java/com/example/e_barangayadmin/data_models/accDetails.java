package com.example.e_barangayadmin.data_models;

public class accDetails {

    private String email;
    private String password;
    private String phoneNum;
    private String status;
    private boolean isAdmin;

    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getPhoneNum() { return phoneNum; }
    public String getStatus() { return status; }
    public boolean isAdmin() { return isAdmin; }

    public accDetails(String email,
                   String password,
                   String phoneNum,
                   String status,
                      boolean isAdmin){

        this.email = email;
        this.password = password;
        this.phoneNum = phoneNum;
        this.status = status;
        this.isAdmin = isAdmin;

    }

    public accDetails(){

    }

}
