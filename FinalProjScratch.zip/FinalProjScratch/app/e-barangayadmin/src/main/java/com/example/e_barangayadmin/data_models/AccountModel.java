package com.example.e_barangayadmin.data_models;

//Basically, parang form to. Parang questionnaire.

public class AccountModel {

    private String userID;
    private String status;

    private String fullname;
    private String birthdate;
    private String email;
    private String password;
    private registrationsRecord regDetails = new registrationsRecord();

    private address address = new address();

    private RequestFormModel Requests = new RequestFormModel();

    private boolean admin;
    private String deviceToken;
    private historyRecord history;


    public String getUserID() { return userID; }
    public String getStatus() { return status; }
    public String getFullname() { return fullname; }
    public String getBirthdate() { return birthdate; }

    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public registrationsRecord getRegDetails() { return regDetails; }
    public address getAddress() { return address; }

    public RequestFormModel getRequests() { return Requests; }

    public boolean isAdmin() { return admin; }
    public String getDeviceToken() { return deviceToken; }
    public historyRecord getHistory() { return history; }



    public AccountModel(String ID,
                        String status,
                        String fullName,
                        String birthdate,
                        String email,
                        String password,
                        registrationsRecord regDetails,
                        address address,
                        RequestFormModel requests,
                        boolean isAdmin,
                        String deviceToken,
                        historyRecord history){

        this.userID = ID;
        this.status = status;
        this.fullname = fullName;
        this.birthdate = birthdate;
        this.email = email;
        this.password = password;
        this.regDetails = regDetails;
        this.address = address;
        this.Requests = requests;
        this.admin = isAdmin;
        this.deviceToken = deviceToken;
        this.history = history;

    }

    public AccountModel(){

    }

}


