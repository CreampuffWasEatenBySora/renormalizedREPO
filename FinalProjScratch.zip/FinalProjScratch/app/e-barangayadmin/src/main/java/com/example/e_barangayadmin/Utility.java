package com.example.e_barangayadmin;


import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.example.e_barangayadmin.data_models.AccountModel;
import com.example.e_barangayadmin.data_models.RequestFormModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class Utility {
    static DatabaseReference databaseReference;

    public static boolean onlyLetters(String input) {
        // Regular expression to check if the string contains numbers
        String regex = "^[A-Za-z\\s.,!?]+$";
        return input.matches(regex);
    }

    public static String getDate(){

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
        String formattedDate = df.format(c);
        return formattedDate;
    }

    public static boolean onlyLettersNsymbols(String input) {
        // Regular expression to check if the string contains numbers
        String regex = "^[a-zA-Z\\s\\W_]*$";
        return input.matches(regex);
    }

    public static void confirmGreen(EditText correct, Context context, Activity activity){
        correct.setCompoundDrawables(null, null, null, null);
        correct.setError(null);
        correct.invalidate();
        Drawable greenIcon = ContextCompat.getDrawable(activity, R.drawable.ic_action_accepted);// Replace with your drawable resource
        correct.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, greenIcon, null);
        int acceptedColor = ContextCompat.getColor(context, R.color.acceptedGreen);
        correct.setTextColor(acceptedColor);
    }

    public static void rejectRed(EditText reject, Context context, Activity activity){
        reject.setCompoundDrawables(null, null, null, null);
        Drawable redIcon =  ContextCompat.getDrawable(activity, R.drawable.ic_action_rejected); // Replace with your drawable resource
        reject.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, redIcon, null);
        reject.invalidate();
        int rejectedColor = ContextCompat.getColor(context, R.color.rejectedRed);
        reject.setTextColor(rejectedColor);
    }

    public static void resetColor(EditText correct, Context context){
        correct.invalidate();
        correct.setCompoundDrawables(null, null, null, null);
        int resetColor = ContextCompat.getColor(context, R.color.white);
        correct.setTextColor(resetColor);
    }

    public static void nextPage(TabLayout tabLayoutFromBase, int position){
        // Delay in milliseconds
        long delayMillis = 2000; // 2 seconds

        CountDownTimer countDownTimer = new CountDownTimer(delayMillis, delayMillis) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Not used in this example
            }

            @Override
            public void onFinish() {
                TabLayout.Tab selectTab = tabLayoutFromBase.getTabAt(position + 1);
                if (selectTab != null){
                    selectTab.select();
                }
            }
        };

        countDownTimer.start();


    }

    public static void hideKeyboard(Activity activity) {
        View view = activity.findViewById(android.R.id.content);
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public interface nameCallback {
        void onFullNameReceived(String firstName);
    }


    public interface DocCountCallback {
        void onDocCountReceived(int counter);
    }

    public interface RequestStatusCallback {
        void onStatusReceived(String Status);
    }


    public interface AccountObjectCallback {
        void onAccountReceived(AccountModel account);
    }


    public interface RequestObjectCallback {
        void onRequestReceived(RequestFormModel account);
    }

    public static void getFullName(String userId, nameCallback callback) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/" + userId);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    AccountModel acc = snapshot.getValue(AccountModel.class);

                    String fullName = acc.getFullname();


                    // Call the callback with the result
                    callback.onFullNameReceived(fullName);
                } else {
                    // Call the callback with null if the snapshot doesn't exist
                    callback.onFullNameReceived(null);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle errors
                callback.onFullNameReceived(null);
            }
        });
    }





    public static void getDocCount(String USERID, String REQID, DocCountCallback callback) {

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/"+USERID+"/Requests/"+REQID+"/requestedDocument");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    long initCount = snapshot.getChildrenCount();
                    int count = (int) initCount;
                    callback.onDocCountReceived(count);
                } else {
                    callback.onDocCountReceived(0);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onDocCountReceived(0);

            }
        });
    }

    public static void getReqStatus(String USERID, String REQID, RequestStatusCallback callback) {

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/"+USERID+"/Requests/"+REQID);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    String status = snapshot.getValue(RequestFormModel.class).getStatus();
                    callback.onStatusReceived(status);
                } else {
                    callback.onStatusReceived("not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onStatusReceived("cancelled");

            }
        });
    }


    public static void getAccount(String USERID, AccountObjectCallback callback) {
        AccountModel emptyAcc = new AccountModel();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/"+USERID);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                   AccountModel account = snapshot.getValue(AccountModel.class);
                    callback.onAccountReceived(account);
                } else {
                    callback.onAccountReceived(emptyAcc);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onAccountReceived(emptyAcc);

            }
        });
    }

    public static void getRequest(String USERID, String RequestID, RequestObjectCallback callback) {
        RequestFormModel emptyReq = new RequestFormModel();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/"+USERID+"/Requests/" +RequestID);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    RequestFormModel request = snapshot.getValue(RequestFormModel.class);
                    callback.onRequestReceived(request);
                } else {
                    callback.onRequestReceived(emptyReq);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onRequestReceived(emptyReq);

            }
        });
    }


    public static void updateFirebaseData(Map<String, Object> updateMap, Context context, String updateMessage, String failMessage){

        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.updateChildren(updateMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

                if (updateMessage != null){
                Toast.makeText(context, updateMessage, Toast.LENGTH_SHORT).show();
            }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

                if (updateMessage != null){
                    Toast.makeText(context, failMessage, Toast.LENGTH_SHORT).show();
                }

            }
        });

    }




    public static void launchNotificationAPI(JSONObject jsonObject){
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        OkHttpClient client = new OkHttpClient();
        String url = "https://fcm.googleapis.com/fcm/send";
        RequestBody body = RequestBody.create(jsonObject.toString(), JSON);

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .header("Authorization", "Bearer AAAANw_N_io:APA91bEiwZMysEcbEyJhSdmvmOBeVPYQGfsu1JcPCpwykYbHKuurmKnP3vi-pj2UTIQ9YeyL5m8VX1WhkcQC4oe5GSp6mxOmyaA-QQAJ7wihhKS0XApwVEANub2ZyKZBmZGWmOWGi-TH")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                System.out.println("Failed: " + e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                System.out.println("Sent confirmed " + request);

            }
        });

    }



}
