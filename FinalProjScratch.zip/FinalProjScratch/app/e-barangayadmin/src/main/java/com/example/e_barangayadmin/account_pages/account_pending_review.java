package com.example.e_barangayadmin.account_pages;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.e_barangayadmin.R;
import com.example.e_barangayadmin.Utility;
import com.example.e_barangayadmin.data_models.AccountModel;
import com.example.e_barangayadmin.homepage;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class account_pending_review extends AppCompatActivity {

    TextView status, fullName, address, phoneNumber, IDType, email, registration_date, accept_date, accept_person, reason, birthday;
    LinearLayout  IDCheck, selfieCheck , reject, accept, accept_box, detail_box, reject_box;
    ImageButton back;
    public static AccountModel account = new AccountModel();
    private DatabaseReference databaseReference;
    private FirebaseDatabase firebaseDatabase;


    static RelativeLayout layout;

    final int[] spinnerIndex = {0};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_pending_review);



        setUpComponents();


    }

    void setUpComponents(){

        IDCheck = findViewById(R.id.pending_id_check);
        selfieCheck = findViewById(R.id.pending_selfie_check);
        accept = findViewById(R.id.pending_accept);
        reject = findViewById(R.id.pending_reject);
        back = findViewById(R.id.recycler_backward);
        fullName = findViewById(R.id.pending_fullname);
        address = findViewById(R.id.pending_address);
        detail_box = findViewById(R.id.detail_box);
        phoneNumber = findViewById(R.id.pending_phonenum);
        IDType = findViewById(R.id.pending_ID_type);
        email = findViewById(R.id.pending_email);
        accept_box = findViewById(R.id.pending_accept_box);
        registration_date = findViewById(R.id.pending_register_date);
        reject_box = findViewById(R.id.reject_box);
        accept_person = findViewById(R.id.verified_by);
        reason = findViewById(R.id.remarks);
        status = findViewById(R.id.recycler_subheader);
        birthday = findViewById(R.id.pending_birthday);


        accept_date = findViewById(R.id.date_verified);

        String municipality = account.getAddress().getMunicipality();
        String barangay = account.getAddress().getBarangay();
        String subdivision = account.getAddress().getSubdivision();
        String houseNum = account.getAddress().getHouseNum();

        String Address = subdivision + ", " + houseNum + ", Barangay " + barangay +", " + municipality + ", Cavite." ;

        fullName.setText(account.getFullname());
        address.setText(Address);
        phoneNumber.setText(account.getAddress().getPhoneNum());
        IDType.setText(account.getRegDetails().getIdtype());
        email.setText(account.getEmail());
        registration_date.setText(account.getRegDetails().getDateRegistered());
        status.setText(account.getStatus());
        birthday.setText(account.getBirthdate());

        if(!account.getStatus().equals("Pending")){
           accept_box.setVisibility(View.INVISIBLE);
           detail_box.setVisibility(View.VISIBLE);
           accept_date.setText(account.getRegDetails().getDateResponded());
           accept_person.setText(account.getRegDetails().getConfirmer());

           if(account.getStatus().equals("Rejected")){
                reject_box.setVisibility(View.VISIBLE);
                reason.setText(account.getRegDetails().getRemarks());
           }
        }



        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Map<String, Object> updateMap = new HashMap<>();
                updateMap.put("Accounts/" + account.getUserID() + "/status", "Verified");
                updateMap.put("Accounts/" + account.getUserID() + "/regDetails/confirmer", homepage.currentAccount.getFullname());
                updateMap.put("Accounts/" + account.getUserID() + "/regDetails/dateResponded", Utility.getDate());
                Utility.updateFirebaseData(updateMap, getApplicationContext(), "Account verified successfully!", "There was an error verifying this account.");

                account_list_page.tabLayout.getTabAt(1).select();
                Intent intent = new Intent(getBaseContext(), account_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readyPopUpWindow();
            }
        });

        selfieCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getBaseContext(), account_pending_image.class);
                intent.putExtra("Path", "images/registrations/" + account.getUserID() + "/selfiePic");
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);

            }
        });

        IDCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getBaseContext(),account_pending_image.class);
                intent.putExtra("Path", "images/registrations/" + account.getUserID() + "/docPic");
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              closeActivity();
            }
        });

    }

    void readyPopUpWindow(){

        Button confirmReject, cancel;

        final Dialog dialog = new Dialog(this);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.popup_reject);
        dialog.setCancelable(false);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        confirmReject = dialog.findViewById(R.id.rejection_popup_confirm_reject);
        cancel = dialog.findViewById(R.id.rejection_popup_cancel);
        Spinner spinner = dialog.findViewById(R.id.rejection_popup_signup_spinner);
        List<String> documentTypes = new ArrayList<>(Arrays.asList("Choose Rejection Reason", "Blurry Photos", "Inaccurate Information", "Not a resident of this barangay"));
        account_pending_rejectReason_select_SpinnerAdapter adapter = new  account_pending_rejectReason_select_SpinnerAdapter(account_pending_review.this, documentTypes);
        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                //Change the selected item's text color
                spinnerIndex[0] = position;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
            }
        });

            confirmReject.setOnClickListener(v -> {
            if (spinnerIndex[0] == 0){
                Toast.makeText(account_pending_review.this, "Please choose a reason from the list!", Toast.LENGTH_SHORT).show();
            } else {


                Map<String, Object> updateMap = new HashMap<>();
                updateMap.put("Accounts/" + account.getUserID() + "/status", "Rejected");
                updateMap.put("Accounts/" + account.getUserID() + "/regDetails/confirmer", homepage.currentAccount.getFullname());
                updateMap.put("Accounts/" + account.getUserID() + "/regDetails/remarks", spinner.getSelectedItem().toString());
                updateMap.put("Accounts/" + account.getUserID() + "/regDetails/dateResponded", Utility.getDate());
                Utility.updateFirebaseData(updateMap, getApplicationContext(), "Account rejection successful.", "There was error in rejecting this account.");

                account_list_page.tabLayout.getTabAt(2).select();
                Intent intent = new Intent(getBaseContext(), account_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);

            }


        });

          cancel.setOnClickListener(v -> dialog.dismiss());


        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);





    }

    void closeActivity(){

        finish();
        Intent intent = new Intent(getApplicationContext(), account_list_page.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);

    }
}