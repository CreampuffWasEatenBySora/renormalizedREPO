package com.example.e_barangayadmin.document_pages;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayadmin.R;
import com.example.e_barangayadmin.Utility;
import com.example.e_barangayadmin.data_models.AvailableDocumentModel;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class document_list_adapter extends RecyclerView.Adapter<documentListViewHolder> {


    private Context context;
    private List<AvailableDocumentModel> documentList;

            public document_list_adapter(Context context, List<AvailableDocumentModel> documents) {
                this.context = context;
                this.documentList = documents;
            }

            @NonNull
            @Override
            public documentListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.available_document_recycler_card, parent, false);
                return new documentListViewHolder(view);

            }

            @Override
            public void onBindViewHolder(@NonNull documentListViewHolder holder, int position) {


               AvailableDocumentModel document = documentList.get(position);
               holder.document_name.setText(document.getDocName());

                holder.edit.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Button edit, cancel;
                        TextView documentName, documentDesc;
                        EditText editName, editDescription;

                        final Dialog dialog = new Dialog(context);


                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setContentView(R.layout.popup_edit_document);
                        dialog.setCancelable(false);


                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                        edit = dialog.findViewById(R.id.request_popup_confirm_request);
                        cancel = dialog.findViewById(R.id.popup_add_cancel);
                        documentName = dialog.findViewById(R.id.popup_edit_document_name);
                        documentDesc = dialog.findViewById(R.id.popup_edit_document_description);
                        editDescription = dialog.findViewById(R.id.popup_edit_document_desc_field);
                        editName = dialog.findViewById(R.id.popup_edit_document_name_field);
                        documentName.setText(document.getDocName());
                        documentDesc.setText(document.getDocumentDescription());


                        edit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                String description = editDescription.getText().toString().trim();
                                String name = editName.getText().toString().trim();

                                // Only validate the description for
                                if (!description.isEmpty() && !Utility.onlyLetters(description)) {
                                    Toast.makeText(context, "Only letters are allowed.", Toast.LENGTH_SHORT).show();
                                } else if (!name.isEmpty() && !Utility.onlyLetters(name)) {
                                    Toast.makeText(context, "Only letters are allowed.", Toast.LENGTH_SHORT).show();
                                }  else {
                                    Map<String, Object> updateMap = new HashMap<>();

                                   if (!description.isEmpty()){
                                       updateMap.put("Documents/"+document.getDocumentID()+"/documentDescription", description);
                                   }
                                   if (!name.isEmpty()){
                                       updateMap.put("Documents/"+document.getDocumentID()+"/docName", name);
                                   }

                                   if (!updateMap.isEmpty()){
                                       Utility.updateFirebaseData(updateMap, context, "Document edited successfully1", "There was an error in editing this document");
                                       dialog.dismiss();
                                   }

                                }
                            }
                        });

                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });


                        dialog.show();
                        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

                    }
                });
                holder.delete.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        AlertDialog.Builder deleteDocAlertBuilder = new AlertDialog.Builder(context);

                        deleteDocAlertBuilder.setTitle("Delete Document?");
                        deleteDocAlertBuilder.setMessage("Are you sure you want to delete [" +document.getDocName()+"]?");

                        deleteDocAlertBuilder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Documents/" + document.getDocumentID());
                                databaseReference.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Toast.makeText(context, "Document deleted successfully.", Toast.LENGTH_SHORT);
                                    }
                                });

                            }
                        });

                        deleteDocAlertBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                //Just cancels the dialog box
                            }
                        });

                        AlertDialog dialog = deleteDocAlertBuilder.create();
                        dialog.show();

                    }
                });



            }

            @Override
            public int getItemCount() {
                return documentList.size();
            }
}

class documentListViewHolder extends RecyclerView.ViewHolder{

    TextView document_name;
    ImageButton edit, delete;
    CardView document_card;


    public documentListViewHolder(@NonNull View itemView){
        super(itemView);


        document_card = itemView.findViewById(R.id.available_document_card);
        document_name = itemView.findViewById(R.id.available_document_name);
        edit = itemView.findViewById(R.id.popup_edit_document_editButton);
        delete = itemView.findViewById(R.id.popup_edit_document_deleteButton);

    }



}
