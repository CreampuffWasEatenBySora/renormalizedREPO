package com.example.e_barangayadmin.request_pages.viewing_request_detail_pages;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayadmin.R;
import com.example.e_barangayadmin.data_models.RequestedDocumentModel;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class requested_documents_list_adapter extends RecyclerView.Adapter<requested_documents_viewholder> {


    private Context context;
    private List<RequestedDocumentModel> requestedDocuments;

            public requested_documents_list_adapter(Context context, List<RequestedDocumentModel> requestedDocuments) {
                this.context = context;
                this.requestedDocuments = requestedDocuments;
            }

            @NonNull
            @Override
            public requested_documents_viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.requested_document_recycler_card, parent, false);
                return new requested_documents_viewholder(view);

            }

            @Override
            public void onBindViewHolder(@NonNull requested_documents_viewholder holder, int position) {



                RequestedDocumentModel document = requestedDocuments.get(position);

                holder.requested_doc_name.setText(document.getDocName());
                holder.editBox.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Button   cancel;
                        TextView documentName, documentPurpose;


                        final Dialog dialog = new Dialog(context);


                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setContentView(R.layout.popup_requested_document_reason);
                        dialog.setCancelable(false);


                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                        cancel = dialog.findViewById(R.id.request_popup_cancel);
                        documentName = dialog.findViewById(R.id.popup_requested_document_name);
                        documentPurpose = dialog.findViewById(R.id.popup_requested_document_reason);
                        documentName.setText(document.getDocName());
                        documentPurpose.setText(document.getPurpose());

                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });


                        dialog.show();
                        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

                    }
                });





            }

            @Override
            public int getItemCount() {
                return requestedDocuments.size();
            }
}

class requested_documents_viewholder extends RecyclerView.ViewHolder{

    TextView requested_doc_name, requested_document_status;
    CardView requestCard;
    LinearLayout editBox;


    public requested_documents_viewholder(@NonNull View itemView){
        super(itemView);


        requestCard = itemView.findViewById(R.id.requested_document_card);
        requested_doc_name = itemView.findViewById(R.id.requested_document_name);
        requested_document_status = itemView.findViewById(R.id.requested_document_status);
        editBox = itemView.findViewById(R.id.requested_document_card_reasonBox);

    }



}
