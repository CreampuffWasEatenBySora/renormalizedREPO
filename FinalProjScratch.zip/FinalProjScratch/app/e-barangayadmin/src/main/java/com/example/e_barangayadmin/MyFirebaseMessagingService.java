package com.example.e_barangayadmin;

import static android.content.ContentValues.TAG;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.e_barangayadmin.data_models.AccountModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.HashMap;
import java.util.Map;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    static DatabaseReference databaseReference;
    static ValueEventListener eventListener;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null && homepage.currentAccount != null) {

            String title = remoteMessage.getNotification().getTitle();
            String body = remoteMessage.getNotification().getBody();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(getBaseContext(), 0, intent, PendingIntent.FLAG_IMMUTABLE);
            int notificationId = (int) System.currentTimeMillis();

            // Create and show notification
            NotificationCompat.Builder notificationBuilder =
                    new NotificationCompat.Builder(this, "notifSample")
                            .setContentTitle(title)
                            .setContentText(body)
                            .setSmallIcon(R.drawable.ic_action_accepted)
                            .setContentIntent(pendingIntent)
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT);

            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            notificationManager.notify(notificationId, notificationBuilder.build());

        }

        // Also if you intend on generating your own notifications as a result of a received FCM
        // message, here is where that should be initiated. See sendNotification method below.
    }
    public static void updateTokenInDatabase(String token, String formerToken, String USERID, Context context) {

        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {


            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
                    if (snapshot.exists()){

                        AccountModel account = itemSnapshot.getValue(AccountModel.class);

                        if (account.getDeviceToken() != null){
                        if (account.getDeviceToken().equals(formerToken) && !account.getUserID().equals(USERID)){

                            Map<String, Object> updateMap = new HashMap<>();
                            updateMap.put("Accounts/"+ account.getUserID() +"/deviceToken", "emptyToken");

                            Utility.updateFirebaseData(updateMap, context, null, null );

                        }}}}

                finishTokenUpdate(USERID, token, context);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    static void finishTokenUpdate(String USERID, String token,  Context context){

        databaseReference.removeEventListener(eventListener);
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("Accounts/"+ USERID +"/deviceToken", token);
        Utility.updateFirebaseData(updateMap, context,null, null );

    }


}
