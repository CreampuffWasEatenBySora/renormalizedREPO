package com.example.e_barangayadmin.data_models;

//Basically, parang form to. Parang questionnaire.

public class AvailableDocumentModel {

    private String documentID;

    private String docName;
    private String documentDescription;

    private String dateModified;
    private boolean available;


    public String getDocumentID() { return documentID; }
    public String getDocName() { return docName; }

    public String getDateModified() {return dateModified; }
    public String getDocumentDescription() { return documentDescription; }



    public AvailableDocumentModel(String documentID,
                                  String documentName,
                                  String documentDescription,
                                  String docDate,
                                  boolean isAvailable){

        this.documentID = documentID;
        this.docName = documentName;
        this.documentDescription = documentDescription;
        this.dateModified = docDate;
        this.available = isAvailable;


    }

    public AvailableDocumentModel(){

    }

}


