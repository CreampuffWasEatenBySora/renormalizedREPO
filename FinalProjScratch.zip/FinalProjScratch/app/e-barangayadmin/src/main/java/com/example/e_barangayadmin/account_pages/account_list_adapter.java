package com.example.e_barangayadmin.account_pages;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayadmin.R;
import com.example.e_barangayadmin.data_models.AccountModel;
import com.example.e_barangayadmin.homepage;

import java.util.List;

public class account_list_adapter extends RecyclerView.Adapter<userListViewHolder> {


    private Context context;
    private List<AccountModel> accountslist;

            public account_list_adapter(Context context, List<AccountModel> accountslist) {
                this.context = context;
                this.accountslist = accountslist;
            }

            @NonNull
            @Override
            public userListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_card_for_account, parent, false);
                return new userListViewHolder(view);

            }

            @Override
            public void onBindViewHolder(@NonNull userListViewHolder holder, int position) {


                AccountModel account = accountslist.get(position);
                holder.account_name.setText(account.getFullname());



                holder.forward.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        account_pending_review.account = account;
                        account_list_page.databaseReference.removeEventListener(account_list_page.accountListener);
                        Intent intent = new Intent(context, account_pending_review.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        context.startActivity(intent);

                    }
                });





            }

            @Override
            public int getItemCount() {
                return accountslist.size();
            }
}

class userListViewHolder extends RecyclerView.ViewHolder{

    TextView account_name, account_accessLevel;
    Button forward;
    CardView accountCard;


    public userListViewHolder(@NonNull View itemView){
        super(itemView);

        accountCard = itemView.findViewById(R.id.adminAccountCard);
        forward = itemView.findViewById(R.id.account_forward);
        account_name = itemView.findViewById(R.id.account_name);


    }



}
