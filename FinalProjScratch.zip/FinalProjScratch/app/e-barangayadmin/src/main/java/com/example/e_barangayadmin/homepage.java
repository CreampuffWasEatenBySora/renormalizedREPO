package com.example.e_barangayadmin;

import static com.example.e_barangayadmin.Utility.getFullName;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;


import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.e_barangayadmin.account_pages.account_list_page;
import com.example.e_barangayadmin.account_pages.account_pending_review;
import com.example.e_barangayadmin.data_models.AccountModel;
import com.example.e_barangayadmin.document_pages.document_list_page;
import com.example.e_barangayadmin.request_pages.request_list_page;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class homepage extends AppCompatActivity {

    public static AccountModel currentAccount = new AccountModel();

    ImageButton requestButton, documentsButton, accountsButton, logOutButton, settingsButton;

    TextView greetingText;


    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {


                    System.out.println("You can now receive notilkmpfications!");


                } else {
                    System.out.println("No notifications, that's alright!");

                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        setNewToken(currentAccount.getUserID(), currentAccount.getDeviceToken(), homepage.this);
        setGreeting();
        askNotificationPermission();
        setUpComponents();

        requestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), request_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);


            }
        });

        documentsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), document_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);


            }
        });

        accountsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), account_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);


            }
        });

        accountsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), account_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);


            }
        });


        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                account_pending_review.account = currentAccount;
                Intent intent = new Intent(getApplicationContext(), account_pending_review.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                
            }
        });

        logOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                currentAccount = new AccountModel();
                Intent intent = new Intent(getApplicationContext(), homepage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

    }


    void setUpComponents(){

        accountsButton = findViewById(R.id.home_manageAccounts);
        documentsButton = findViewById(R.id.home_manageDocuments);
        requestButton = findViewById(R.id.home_manageRequests);
        logOutButton = findViewById(R.id.panel_exit);
        settingsButton = findViewById(R.id.panel_setting);

    }

    void setGreeting(){

        greetingText = findViewById(R.id.homepage_greeting);
        getFullName(currentAccount.getUserID(), new Utility.nameCallback() {
            @Override
            public void onFullNameReceived(String fullName) {
                // Use the first name here
                int firstNameFind = fullName.lastIndexOf('.') - 2 ;
                String firstName = fullName.substring(0, firstNameFind);
                greetingText.setText("Welcome, " + firstName + "!");

            }
        });

    }




    public static void sendNotification(String message, String recipient){

        // Username, message, current userID, and recipient token

        AccountModel currentUser = homepage.currentAccount;

        try {
            JSONObject jsonObject = new JSONObject();
            JSONObject notifObject = new JSONObject();
            notifObject.put("title", "Testing notification");
            notifObject.put("body", message);

            JSONObject dataObject = new JSONObject();
            dataObject.put("userId", currentUser.getUserID());

            jsonObject.put("notification", notifObject);
            jsonObject.put("data", dataObject);
            jsonObject.put("to", currentUser.getDeviceToken());

            System.out.println("sent to token: " + currentUser.getDeviceToken());
            callApi(jsonObject);
        } catch (Exception e ){
            System.out.println("Error: " + e);
        }



    }

    public static void callApi(JSONObject jsonObject){
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        OkHttpClient client = new OkHttpClient();
        String url = "https://fcm.googleapis.com/fcm/send";
        RequestBody body = RequestBody.create(jsonObject.toString(), JSON);

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .header("Authorization", "Bearer AAAANw_N_io:APA91bEiwZMysEcbEyJhSdmvmOBeVPYQGfsu1JcPCpwykYbHKuurmKnP3vi-pj2UTIQ9YeyL5m8VX1WhkcQC4oe5GSp6mxOmyaA-QQAJ7wihhKS0XApwVEANub2ZyKZBmZGWmOWGi-TH")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                System.out.println("Failed: " + e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                System.out.println("Sent confirmed " + request);

            }
        });

    }


    // Declare the launcher at the top of your Activity/Fragment:


    private void askNotificationPermission() {
        // This is only necessary for API level >= 33 (TIRAMISU)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                    PackageManager.PERMISSION_GRANTED) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    // Create the NotificationChannel
                    CharSequence name = "Notification Channel Name";
                    String description = "Notification Channel Description";
                    int importance = NotificationManager.IMPORTANCE_DEFAULT;
                    NotificationChannel channel = new NotificationChannel("notifSample", name, importance);
                    channel.setDescription(description);

                    // Register the channel with the system
                    NotificationManager notificationManager = getSystemService(NotificationManager.class);
                    notificationManager.createNotificationChannel(channel);
                    }

                    System.out.println("You can now receive notifications!" );

            } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {

                    System.out.println("Permission is needed" );


            } else {
                    // Directly ask for the permission
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                    System.out.println("You are now asked to enable receive notifications!" );

            }}}


    void setNewToken(String userId, String formerToken, Context context){

        //Along with notification permission and settings, also manage token generation here:
        FirebaseMessaging firebaseMessaging = FirebaseMessaging.getInstance();
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            System.out.println("Token is not received... " );
                            return;
                        }


                        // Get new FCM registration token
                        String token = task.getResult();
                        System.out.println("Token is successfully received: " + token);
                        MyFirebaseMessagingService.updateTokenInDatabase(token, formerToken, userId, context);

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        System.out.println("Token generation failed!: " + e);

                    }
                });


    }


}