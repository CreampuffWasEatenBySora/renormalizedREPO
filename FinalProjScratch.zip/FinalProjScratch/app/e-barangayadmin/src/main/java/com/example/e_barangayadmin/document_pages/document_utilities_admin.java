package com.example.e_barangayadmin.document_pages;

import android.content.Context;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.e_barangayadmin.Utility;
import com.example.e_barangayadmin.data_models.AccountModel;
import com.example.e_barangayadmin.data_models.AvailableDocumentModel;
import com.example.e_barangayadmin.data_models.RequestFormModel;
import com.example.e_barangayadmin.data_models.RequestedDocumentModel;
import com.example.e_barangayadmin.homepage;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class document_utilities_admin {

    static ValueEventListener eventListener;
    static DatabaseReference databaseReference;
    static List<String> tokens = new ArrayList<>();

    public static AvailableDocumentModel document = new AvailableDocumentModel();



    public static void prepareNewRequestNotifications(){


        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
                    if (snapshot.exists()){

                        AccountModel account = itemSnapshot.getValue(AccountModel.class);

                        if (!account.isAdmin() && !account.getDeviceToken().equals("emptyToken") ){
                            tokens.add(account.getDeviceToken());
                            System.out.println("token added: " + account.getDeviceToken());
                        }}}

                LaunchRequestNotifications();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    static void LaunchRequestNotifications(){

        // Username, message, current userID, and recipient token

        databaseReference.removeEventListener(eventListener);
        AccountModel currentUser = homepage.currentAccount;


        for (String token : tokens
        ) {

            try {

                JSONObject jsonObject = new JSONObject();
                JSONObject notifObject = new JSONObject();
                notifObject.put("title", "A new document is available!");
                notifObject.put("body", "Please check the document list for: " + document.getDocName() );

                JSONObject dataObject = new JSONObject();
                dataObject.put("userId", currentUser.getUserID());
                dataObject.put("notifFor","new_document");
                dataObject.put("requestId",document.getDocumentID());

                jsonObject.put("notification", notifObject);
                jsonObject.put("data", dataObject);
                jsonObject.put("to", token);

                System.out.println("sent to token: " + token);
                Utility.launchNotificationAPI(jsonObject);
            } catch (Exception e ){
                System.out.println("Error: " + e);
            }
        }

        clearUtilityPage();

    }

    static void clearUtilityPage(){

        document = new AvailableDocumentModel();
        tokens.clear();

    }


}
