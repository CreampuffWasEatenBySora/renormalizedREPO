package com.example.e_barangayadmin.account_pages;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.example.e_barangayadmin.R;

import java.util.List;

public class account_pending_rejectReason_select_SpinnerAdapter extends ArrayAdapter<String> {

    private final LayoutInflater mInflater;

    public account_pending_rejectReason_select_SpinnerAdapter(Context context, List<String> items) {
        super(context, android.R.layout.simple_spinner_item, items);
        mInflater = LayoutInflater.from(context);
        setDropDownViewResource(R.layout.dropdown);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    private View getCustomView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.dropdown, parent, false);
        }

        TextView textView = convertView.findViewById(android.R.id.text1);

        // Check if it's the first item (prompt) and apply a different style or color
        if (position == 0) {
            textView.setTextColor(ContextCompat.getColor(getContext(), R.color.gray)); // Change color to gray
        } else {
            textView.setTextColor(ContextCompat.getColor(getContext(), R.color.black)); // Change color back to default
        }

        textView.setText(getItem(position));
        return convertView;
    }
}

