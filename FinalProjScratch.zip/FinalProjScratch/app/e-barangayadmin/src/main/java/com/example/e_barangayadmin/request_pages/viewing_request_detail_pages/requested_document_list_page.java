package com.example.e_barangayadmin.request_pages.viewing_request_detail_pages;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayadmin.R;
import com.example.e_barangayadmin.Utility;
import com.example.e_barangayadmin.account_pages.account_list_page;
import com.example.e_barangayadmin.account_pages.account_pending_rejectReason_select_SpinnerAdapter;
import com.example.e_barangayadmin.account_pages.account_pending_review;
import com.example.e_barangayadmin.data_models.RequestFormModel;
import com.example.e_barangayadmin.data_models.RequestedDocumentModel;
import com.example.e_barangayadmin.request_pages.request_list_page;
import com.example.e_barangayadmin.request_pages.request_utilities_admin;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class requested_document_list_page extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView emptyAlert, requestID, residentName;
    TabLayout tabLayout;
    ImageButton back, search, filter;
    FloatingActionButton approve_request, reject_request;
    List<RequestedDocumentModel> requested_documents_list;
    DatabaseReference databaseReference;
    ValueEventListener requestListener;
    LinearLayout checkStatus, actionBox;
    RequestFormModel request = new RequestFormModel("-", "-", null,"-","-","-","-","-","-" );
    AlertDialog.Builder approveBuilder, noReasonViewedBuilder, rejectBuilder;
    public static int reasonsViewed = 0;

    final int[] spinnerIndex = {0};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requested_document_list);

        setUpComponents();
        populateList();



    }

    void setUpComponents(){



        approve_request = findViewById(R.id.request_approveButton);
        reject_request = findViewById(R.id.request_rejectButton);
        requestID = findViewById(R.id.viewRequest_id);
        residentName = findViewById(R.id.viewRequest_name);
        checkStatus = findViewById(R.id.request_checkStatus);
        actionBox = findViewById(R.id.actionBox);
        back = findViewById(R.id.request_status_backward);
        noReasonViewedBuilder = new AlertDialog.Builder(this);
        buildNoReasonViewedDialog();
        approveBuilder = new AlertDialog.Builder(this);
        buildApproveDialog();
        rejectBuilder = new AlertDialog.Builder(this);
        buildRejectDialog();


        if (request_utilities_admin.request != null){
            request = request_utilities_admin.request;

            if (request.getStatus()!=null){
            if (!request.getStatus().equals("Pending")){
                actionBox.setVisibility(View.GONE);
                checkStatus.setVisibility(View.VISIBLE);
            } else{
                actionBox.setVisibility(View.VISIBLE);
                checkStatus.setVisibility(View.GONE);
            }}

            requestID.setText(request_utilities_admin.request.getRequestID());

            Utility.getFullName(request_utilities_admin.request.getClientID(), new Utility.nameCallback() {
                @Override
                public void onFullNameReceived(String firstName) {
                    // Use the first name here
                    String statement = firstName + "'s Request form";
                    residentName.setText(statement);
                }
            });


            approve_request.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Dialog dialog = approveBuilder.create();
                    dialog.show();

                }
            });

            reject_request.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Dialog dialog = rejectBuilder.create();
                    dialog.show();

                }});


            checkStatus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    readyPopUpWindow(request_utilities_admin.request);
                }});

        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                request_utilities_admin.clearUtilityPage();
                Intent intent = new Intent(getApplicationContext(),request_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });



    }



    void populateList() {


        recyclerView = findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(requested_document_list_page.this, 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        requested_documents_list = new ArrayList<>();
        requested_documents_list_adapter adapter = new requested_documents_list_adapter(requested_document_list_page.this, requested_documents_list);
        recyclerView.setAdapter(adapter);


        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/" + request.getClientID() +"/Requests/"+ request.getRequestID()+"/requestedDocument");
        requestListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                requested_documents_list.clear();
                for (DataSnapshot itemSnapShot: snapshot.getChildren()){
                    RequestedDocumentModel requestedDocument = itemSnapShot.getValue(RequestedDocumentModel.class);


                    requested_documents_list.add(requestedDocument);
                    adapter.notifyDataSetChanged();
                }
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


    }



    //These functions are here so that the custom dialog boxes are built.
    public void buildNoReasonViewedDialog(){

        noReasonViewedBuilder.setTitle("Check request reasons first.");
        noReasonViewedBuilder.setMessage("You're about to leave without checking each reason for request.");

        noReasonViewedBuilder.setPositiveButton("Got it.", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button saves the form as a pending form, instead of just "New".



            }});

    }


    public void buildApproveDialog(){


        approveBuilder.setTitle("Approve Request form?");
        approveBuilder.setMessage("The resident will be notified that the documents are ready to be collected.");

        approveBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();

                request_utilities_admin.updateViewedRequestForm(requested_document_list_page.this, "Ready", null);
            }
        });
        approveBuilder.setNegativeButton("Not yet", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button discards the form.

            }
        });

    }

    //These functions are here so that the custom dialog boxes are built.
    public void buildRejectDialog(){

        rejectBuilder.setTitle("Reject request form?");
        rejectBuilder.setMessage("The resident will be notified of the rejection.");

        rejectBuilder.setPositiveButton("Reject", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                rejectPopupWindow();
            }
        });

        rejectBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

    }

    void rejectPopupWindow(){

        Button confirmReject, cancel;

        final Dialog dialog = new Dialog(this);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.popup_reject_request);
        dialog.setCancelable(false);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        confirmReject = dialog.findViewById(R.id.rejection_popup_confirm_reject);
        cancel = dialog.findViewById(R.id.rejection_popup_cancel);
        Spinner spinner = dialog.findViewById(R.id.rejection_popup_signup_spinner);
        List<String> documentTypes = new ArrayList<>(Arrays.asList("Choose Rejection Reason", "Invalid request purpose", "Duplicate request", "Documents not available anymore"));
        account_pending_rejectReason_select_SpinnerAdapter adapter = new  account_pending_rejectReason_select_SpinnerAdapter(requested_document_list_page.this, documentTypes);
        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                //Change the selected item's text color
                spinnerIndex[0] = position;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
            }
        });

        confirmReject.setOnClickListener(v -> {
            if (spinnerIndex[0] == 0){
                Toast.makeText(requested_document_list_page.this, "Please choose a remark from the list!", Toast.LENGTH_SHORT).show();
            } else {



                dialog.dismiss();
                request_utilities_admin.updateViewedRequestForm(requested_document_list_page.this, "Rejected", spinner.getSelectedItem().toString());
                request_list_page.tabLayout.getTabAt(2).select();

                Intent intent = new Intent(getApplicationContext(), request_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }


        });

        cancel.setOnClickListener(v -> dialog.dismiss());


        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);





    }

    void readyPopUpWindow(RequestFormModel request){

        Button  confirm;
        TextView status, confirmerDate, collectDate;

        final Dialog dialog = new Dialog(this);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.popup_request_status);
        dialog.setCancelable(false);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        confirm = dialog.findViewById(R.id.request_popup_confirm);
        status = dialog.findViewById(R.id.popup_requested_document_approveDate);
        confirmerDate = dialog.findViewById(R.id.popup_requested_document_confirmerDate);
        collectDate = dialog.findViewById(R.id.popup_requested_document_collectDate);
        String statusText = "";
        String confirmerDateText = "";
        String collectDateText = "";

        ImageView iconImageView = dialog.findViewById(R.id.iconImageView);

        if (request.getStatus().equals("Ready")){
            iconImageView.setImageResource(R.drawable.approved_icon);
            statusText = "Approved for Collection";
            confirmerDateText = "by "+ request.getConfirmer() +" on " + request.getDateRelease() + ".";
            collectDateText = "It is yet to be collected.";

        } else if (request.getStatus().equals("Rejected")){
            iconImageView.setImageResource(R.drawable.rejected_icon);
            statusText = "Rejected";
            confirmerDateText = "By "+ request.getConfirmer() +"\n\nDue to: " + request.getRemarks() + " on " + request.getDateRelease() + "." ;
            collectDateText = "It will not be collected.";

        } else if (request.getStatus().equals("Collected")) {
            iconImageView.setImageResource(R.drawable.collected_icon);
            statusText = "Approved";
            confirmerDateText = "by " + request.getConfirmer()  + " on " + request.getDateRelease() + ".";
            collectDateText = "It was collected on " + request.getDateCollected() + ".";
        }


        status.setText(statusText);
        confirmerDate.setText(confirmerDateText);
        collectDate.setText(collectDateText);

        confirm.setOnClickListener(v -> dialog.dismiss());


        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);





    }



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        //Use this reference to check details about the request form.

        // replaces the default 'Back' and 'home' button actions
        // Aside from those two buttons, there's no other way to come out of this activity.
        if(keyCode==KeyEvent.KEYCODE_BACK || keyCode==KeyEvent.KEYCODE_HOME)   {


            request_utilities_admin.clearUtilityPage();
            Intent intent = new Intent(getApplicationContext(),request_list_page.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        }
        return true;
    }

}