package com.example.e_barangayadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.example.e_barangayadmin.data_models.AccountModel;
import com.google.firebase.messaging.FirebaseMessaging;

import java.sql.SQLOutput;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public static FirebaseAuth mAuth;
    EditText email_field, password_field;
    Button loginButton;
    String email, password;
    List<AccountModel> dataClassList;
    DatabaseReference databaseReference;
    ValueEventListener eventListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginpages);

        setUpComponents();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //if checking fields doesn't find an error, then proceed to login.
                if (checkFields()){
                    checkDatabase();
                }

            }
        });



    }


    void setUpComponents(){

        email_field = findViewById(R.id.login_emailField);
        password_field = findViewById(R.id.login_passwordField);
        loginButton = findViewById(R.id.login_button);

    }


    boolean checkFields(){

        boolean passed = true;
        email = email_field.getText().toString();
        password = password_field.getText().toString();

        HashMap<EditText, String> fields = new HashMap<>();
        fields.put(email_field, email);
        fields.put(password_field, password);

        //Checking for empty fields.
        for (Map.Entry<EditText, String> entry : fields.entrySet()){

            if (entry.getValue().isEmpty()){
                entry.getKey().setError("Do not leave empty fields.");
                passed = false;
                Utility.rejectRed(entry.getKey(), getApplicationContext(), MainActivity.this);
            } else {
                Utility.confirmGreen(entry.getKey(), getApplicationContext(), MainActivity.this);
            }
        }

        return passed;

    }

    void checkDatabase(){




        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false); // prevent user from dismissing dialog
        progressDialog.show();

        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            boolean passed = false;

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                progressDialog.dismiss();
                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
                    if (snapshot.exists()){

                        AccountModel account = itemSnapshot.getValue(AccountModel.class);

                        if (account.getEmail().equals(email) && account.getPassword().equals(password) && account.isAdmin() ){

                            homepage.currentAccount = account;
                            passed = true;

                        }}}

                if (passed){
                    login();
                } else {
                    System.out.println("OnDataChanged triggered.");
                    Utility.rejectRed(email_field, MainActivity.this, MainActivity.this);
                    Utility.rejectRed(password_field, MainActivity.this, MainActivity.this);
                    Toast.makeText(MainActivity.this, "Incorrect email or password. ", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    void login(){

        Intent intent = new Intent(MainActivity.this, homepage.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }

    @Override
    protected void onDestroy() {

        databaseReference.removeEventListener(eventListener);

        super.onDestroy();
    }
}

