package com.example.e_barangayadmin.data_models;

//Basically, parang form to. Parang questionnaire.

public class RequestedDocumentModel {

    private String requestDocID;

    private String docName;
    private String documentRecipient;
    private String extra;
    private String purpose;
    private String status;
    private String remarks;


    public String getRequestDocID() { return requestDocID; }
    public String getDocName() { return docName; }
    public String getDocumentRecipient() { return documentRecipient; }

    public String getExtra() { return extra; }
    public String getPurpose() { return purpose; }
    public String getStatus() { return status; }
    public String getRemarks() { return remarks; }





    public RequestedDocumentModel(String requestDocID,
                                  String documentName,
                                  String documentRecipient,
                                  String purpose,
                                  String extra,
                                  String status,
                                  String remarks){

        this.requestDocID = requestDocID;
        this.docName = documentName;
        this.documentRecipient = documentRecipient;
        this.purpose = purpose;
        this.status = status;
        this.extra = extra;
        this.remarks = remarks;


    }

    public RequestedDocumentModel(){

    }

}


