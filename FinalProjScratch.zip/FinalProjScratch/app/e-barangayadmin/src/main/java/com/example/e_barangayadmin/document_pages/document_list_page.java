package com.example.e_barangayadmin.document_pages;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayadmin.R;
import com.example.e_barangayadmin.Utility;
import com.example.e_barangayadmin.account_pages.account_list_adapter;
import com.example.e_barangayadmin.account_pages.account_list_page;
import com.example.e_barangayadmin.data_models.AccountModel;
import com.example.e_barangayadmin.data_models.AvailableDocumentModel;
import com.example.e_barangayadmin.homepage;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class document_list_page extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView emptyAlert;
    TabLayout tabLayout;
    TabLayout pagination;
    ImageButton back, filter;
    ImageView clear;
    ImageButton searchButton;
    EditText searchBox;
    static String  filterText ="";
    int page = 1;

    int pageLimit = 4;
    List<AvailableDocumentModel> limitedlist = new ArrayList<>();;

    String newDocName, newDocDesc;

    List<AvailableDocumentModel> documentList = new ArrayList<>();
    DatabaseReference databaseReference;
    ValueEventListener documentListener;
    FloatingActionButton addDocument;
    AlertDialog.Builder newDocBuilder;

    AvailableDocumentModel newDocument = new AvailableDocumentModel();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document_list);

        setUpComponents();
        populateList(filterText);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
            }
        });
        addDocument.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readyPopUpWindow();
            }
        });


    }

    void setUpComponents(){

        back = findViewById(R.id.recycler_backward);
        // search = findViewById(R.id.recycler_search);
        emptyAlert = findViewById(R.id.recycler_emptyAlert);
        searchBox = findViewById(R.id.recycler_search);
        searchButton = findViewById(R.id.recycler_searchButton);
        pagination = findViewById(R.id.pagination_tab);
        clear  = findViewById(R.id.clearButton);
        emptyAlert.setVisibility(View.GONE);
        addDocument = findViewById(R.id.document_addButton);
        newDocBuilder = new AlertDialog.Builder(this);
        buildNewRequestDialog();

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                // Called to notify you that somewhere within the text, characters have been added or removed.
                // This is where you can perform your action after the text has changed.
                filterText = editable.toString();
                // Add your logic here to handle the changed text
                if (filterText.isEmpty()){
                    clear.setVisibility(View.GONE);
                    populateList(filterText);

                } else {
                    clear.setVisibility(View.VISIBLE);
                }

            }
        });


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = searchBox.getText().toString();
                populateList(filterText);
            }
        });


        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = "";
                searchBox.setText("");
                populateList(filterText);
            }
        });

    }


    void populateList( String filter) {

        filter = filter.toLowerCase();
        documentList = new ArrayList<>();

        ///" + homepage.currentAccount.getUserID()+"/Requests
        databaseReference = FirebaseDatabase.getInstance().getReference("Documents");
        String finalFilter = filter;
        documentListener = databaseReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                documentList.clear();


                    if (snapshot.exists()) {

                        for (DataSnapshot itemSnapShot: snapshot.getChildren()){
                            AvailableDocumentModel document = itemSnapShot.getValue(AvailableDocumentModel.class);

                        if (document.getDocName().toLowerCase().contains(finalFilter)){

                            documentList.add(document);
                            setPaginationLimits(documentList.size());
                            limitedPopulateList(page);

                        } else {

                            setPaginationLimits(documentList.size());
                            limitedPopulateList(page);
                        }
                        }

                    } else {

                        setPaginationLimits(documentList.size());
                        limitedPopulateList(page);
                    }




            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

    }


    void setPaginationLimits(int setSize){

        pagination.removeAllTabs();

        int pageNums = setSize / pageLimit;
        int remainder = setSize % pageLimit;
        for (int i = 0; i <= pageNums; i++) {

            if (!((remainder == 0) && (i == pageNums))){
                pagination.addTab(pagination.newTab().setText(String.valueOf(i+1)));
            }
        }

        pagination.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                limitedPopulateList(tab.getPosition()+1);
                page = tab.getPosition()+1;
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
    void limitedPopulateList(int page){


        limitedlist.clear();
        recyclerView = findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(document_list_page.this, 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        document_list_adapter adapter = new document_list_adapter(document_list_page.this, limitedlist);
        recyclerView.setAdapter(adapter);


        int startRange = (page * pageLimit) - pageLimit; // Calculate start index of the range
        int upperRange = Math.min(page * pageLimit, documentList.size()); // Calculate end index of the range

        limitedlist.clear(); // Clear limitedlist if needed


        for (int i = startRange; i < upperRange; i++) {
            limitedlist.add(documentList.get(i));
            adapter.notifyDataSetChanged();
        }

        if (documentList.isEmpty()){
            emptyAlert.setVisibility(View.VISIBLE);
        } else {
            emptyAlert.setVisibility(View.GONE);

        }

        adapter.notifyDataSetChanged();


        // Notify adapter after adding all items

    }




    void closeActivity(){

        finish();
        databaseReference.removeEventListener(documentListener);
        Intent intent = new Intent(getApplicationContext(),homepage.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {

        // replaces the default 'Back' button actions
        // Aside from this button, there's no other way to come out of this activity.
        if(keyCode==KeyEvent.KEYCODE_BACK )   {

            //This is made to prevent going back to the previous activities such as:
            // adding, editing , or interacting with elements.
            closeActivity();
        }
        return true;
    }

    void readyPopUpWindow(){

        Button confirmAdd, cancel;
        EditText docName, docDesc;

        final Dialog dialog = new Dialog(this);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.popup_add_document);
        dialog.setCancelable(false);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        confirmAdd = dialog.findViewById(R.id.popup_add_confirm_addButton);
        cancel = dialog.findViewById(R.id.popup_add_cancel);
        docName = dialog.findViewById(R.id.popup_add_document_name_field);
        docDesc = dialog.findViewById(R.id.popup_add_document_desc_field);

        confirmAdd.setOnClickListener(v -> {

            String name = docName.getText().toString().trim();
            String desc = docDesc.getText().toString().trim();
            if (name.isEmpty() || desc.isEmpty()){

                Toast.makeText(document_list_page.this, "Do not leave empty fields!", Toast.LENGTH_SHORT).show();

            } else {

                newDocName = name;
                newDocDesc = desc;
                Dialog alertDialogBox = newDocBuilder.create();
                dialog.dismiss();
                alertDialogBox.show();

            }



        });

        cancel.setOnClickListener(v -> dialog.dismiss());


        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

    }



    public void buildNewRequestDialog(){

        newDocBuilder.setTitle("Save new document?");
        newDocBuilder.setMessage("Barangay residents will be notified.");

        newDocBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {


                uploadNewDocument(newDocName, newDocDesc);


            }
        });

        newDocBuilder.setNegativeButton("Discard", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

    }

    void uploadNewDocument(String docName, String docDesc){

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Documents" );
        String documentID = databaseReference.push().getKey();

        AvailableDocumentModel newDocument = new AvailableDocumentModel(documentID, docName, docDesc, Utility.getDate(), true);
        databaseReference.child(documentID).setValue(newDocument)

                .addOnSuccessListener(unused -> {

                            Toast.makeText(document_list_page.this, "Document [" + docName + "] added successfully!", Toast.LENGTH_SHORT).show();
                            document_utilities_admin.document = newDocument;
                            document_utilities_admin.prepareNewRequestNotifications();
                        }

                ).addOnFailureListener(e -> {
                    Toast.makeText(document_list_page.this, "Due to:" + e, Toast.LENGTH_SHORT ).show();
                    Toast.makeText(document_list_page.this, "Document [" + docName+"] added unsuccessfully...", Toast.LENGTH_SHORT ).show();

                });



    }

}