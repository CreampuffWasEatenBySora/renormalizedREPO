package com.example.e_barangayclient.signup_pages.fragments;

import static com.example.e_barangayclient.homepage.currentAccount;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_barangayclient.R;
import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.AccountModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.data_models.imageData;
import com.example.e_barangayclient.request_pages.file_utilities;
import com.example.e_barangayclient.request_pages.viewing_returned_request_detail_pages.returned_request_list_page;
import com.example.e_barangayclient.signup_pages.signup_base_page;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageReference;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Signup_stepOne_fragment extends Fragment {

    TabLayout tabLayoutFromBase = signup_base_page.tabLayout;
    TabLayout.Tab tabText = tabLayoutFromBase.getTabAt(0);

    public Signup_stepOne_fragment() {}
    private EditText firstname_field, middlename_field, lastname_field;
    private String firstname_text, middlename_text, lastname_text, fullname, birthdate;
    private Button nextButton, birthdayButton;
    private ImageView imageSample;
    private ViewPager2 viewPager2;
   // This one is to be used when multiple upload is supported
   // private ArrayList<Uri> images = new ArrayList<>();
    private Uri image;

    ValueEventListener stepOneEventListener;
    View view;






    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         view = inflater.inflate(R.layout.fragment_signup_step_one, container, false);
         getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        setUpComponents();


        // Set onClickListener for the signupButton here
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkFields();
                }




        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {}

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }


    void setUpComponents(){
        // Initialize Buttons here
        nextButton = view.findViewById(R.id.next_button);

        // Initialize the details to be uploaded into firebase
        firstname_field = view.findViewById(R.id.signup_firstName);
        middlename_field = view.findViewById(R.id.signup_MidName);
        lastname_field = view.findViewById(R.id.signup_LastName);
        birthdayButton = view.findViewById(R.id.birthdateButton);

        setTextChangeListener(firstname_field, firstname_text);
        setTextChangeListener(middlename_field, middlename_text);
        setTextChangeListener(lastname_field, lastname_text);

        birthdayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });


    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.add(Calendar.YEAR, -18);
        //Imposes a limit of at least 18 y.o in the system.
        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        Calendar  Date = Calendar.getInstance();
                        Date.set(year, month, dayOfMonth);

                            String selectedDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                            birthdate = selectedDate;
                            birthdayButton.setText(selectedDate);

                    }

                }, year, month, dayOfMonth);
        datePickerDialog.getDatePicker().setMaxDate(calendar.getTimeInMillis());
        datePickerDialog.show();
    }

    void setTextChangeListener(EditText field, String value){

        field.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                // Called to notify you that somewhere within the text, characters have been added or removed.
                // This is where you can perform your action after the text has changed.
                String newText = editable.toString();
                // Add your logic here to handle the changed text
                if (!newText.equals(value)) {
                    Utility.resetColor(field, getContext());
                    tabText.setText("1");
                    signup_base_page.verifiedSteps[0] = false;

                }
            }
        });
    }

    void checkFields(){

        boolean passed = true;
        firstname_text = firstname_field.getText().toString().trim();
        middlename_text = String.valueOf(middlename_field.getText().toString().trim().toCharArray()[0]).toUpperCase();
        lastname_text = lastname_field.getText().toString().trim();

        HashMap <EditText, String> fields = new HashMap<>();
        fields.put(firstname_field, firstname_text);
        fields.put(middlename_field, middlename_text);
        fields.put(lastname_field, lastname_text);



        for (Map.Entry<EditText, String> entry : fields.entrySet()){

            if (entry.getValue().isEmpty()){
                entry.getKey().setError("Do not leave empty fields.");
                passed = false;
                Utility.rejectRed(entry.getKey(), getContext(), getActivity());
            } else if (!onlyLetters(entry.getValue())){
                entry.getKey().setError("Only letters are allowed.");
                passed = false;
                Utility.rejectRed(entry.getKey(), getContext(), getActivity());
            } else {
                Utility.confirmGreen(entry.getKey(), getContext(), getActivity());
            }

        }

        if (birthdate == null){
            passed = false;
            Toast.makeText(getContext(), "Please enter your birthdate!", Toast.LENGTH_SHORT);
        }

        if (passed){
            fullname = firstname_text +" "+ middlename_text +". " + lastname_text;
            goToNextPage();
        } else {
            tabText.setText("1");
            signup_base_page.verifiedSteps[0] = false;
        }
    }

    private static boolean onlyLetters(String input) {
        // Regular expression to check if the string contains numbers
        String regex = "^[a-zA-Z\\s]+$";
        return input.matches(regex);
    }


    void goToNextPage() {
        signup_base_page.enterbirhtdate = birthdate;
        signup_base_page.verifiedSteps[0] = true;
        tabText.setText("\u2714");
        signup_base_page.enterName = fullname;
        Utility.hideKeyboard(getActivity());
        Toast.makeText(getContext(), signup_base_page.enterName, Toast.LENGTH_SHORT).show();
        Utility.nextPage(tabLayoutFromBase, 0);
    }
}
