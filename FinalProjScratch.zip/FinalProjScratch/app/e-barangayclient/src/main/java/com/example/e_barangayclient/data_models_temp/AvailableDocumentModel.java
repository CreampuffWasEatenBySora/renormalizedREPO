package com.example.e_barangayclient.data_models_temp;

//Basically, parang form to. Parang questionnaire.

public class AvailableDocumentModel {

    private String documentID;

    private String docName;
    private String documentDescription;

    private String dateModified;
    private String docMisc;
    private boolean available;


    public String getDocumentID() { return documentID; }
    public String getDocName() { return docName; }

    public String getDateModified() {return dateModified; }
    public String getdocMisc() {return docMisc; }
    public String getDocumentDescription() { return documentDescription; }
    public boolean isAvailable() { return available; }



    public AvailableDocumentModel(String documentID,
                                  String documentName,
                                  String documentDescription,
                                  String docDate,
                                  String miscRequirements,
                                  boolean isAvailable){

        this.documentID = documentID;
        this.docName = documentName;
        this.documentDescription = documentDescription;
        this.dateModified = docDate;
        this.docMisc = miscRequirements;
        this.available = isAvailable;


    }

    public AvailableDocumentModel(){

    }

}


