package com.example.e_barangayclient.collectionPages.collection_detail_pages;

import static com.example.e_barangayclient.Utility.APILINK;
import static com.example.e_barangayclient.homepage.currentAccount;
import static com.example.e_barangayclient.request_pages.request_utilities.prepareNewRequestNotifications;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_barangayclient.R;
import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.collectionPages.utilities;
import com.example.e_barangayclient.data_models.CollectFormModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.data_models.imageData;
import com.example.e_barangayclient.homepage;
import com.example.e_barangayclient.request_pages.file_utilities;
import com.example.e_barangayclient.request_pages.request_list_page;
import com.example.e_barangayclient.request_pages.request_utilities;
import com.example.e_barangayclient.request_pages.viewing_returned_request_detail_pages.returned_request_downloadRequest;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class returned_collection_page extends AppCompatActivity implements cameraActionListener {

    static RecyclerView requestedDocumentRecycler, requirementRecycler;
    private final static int CAMERA_PERMISSION_CODE = 1;

    public RequestedDocumentModel requestedDocument = new RequestedDocumentModel();
    public documentRequirementModel requirement = new documentRequirementModel();
    public ImageView imageView  ;
    int position;
    ActivityResultLauncher<Uri> takePictureLauncher;
    Uri imageUri;
    TextView requestID, requestFormTitle, confirmerName;
    EditText searchBox;
    TabLayout tabLayout;
    ImageButton back,  filter, information, save_request;
    Button setScheduleButton;
    String collectionDate;

    static List<RequestedDocumentModel> requested_documents_list;
    static List<documentRequirementModel> requirements_list;
    static HashMap<String, Uri> requirementUriList = new HashMap<>();
    static com.example.e_barangayclient.collectionPages.collection_detail_pages.requested_documents_list_adapter requestedDocumentsListAdapter;
    static com.example.e_barangayclient.collectionPages.collection_detail_pages.requirements_list_adapter requirements_list_adapter ;
    DatabaseReference databaseReference;
    ValueEventListener requestListener;
    CollectFormModel collection = utilities.collection;
    LinearLayout checkStatus, requirementBox, requestedDocumentBox;
    AlertDialog.Builder saveReqBuilder, zeroDocBuilder, newReqBuilder, confirmCollectBuilder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_returned_document_list);

        setUpComponents();


            populateList();

//            checkStatus.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    readyPopUpWindow(request);
//                }
//            });




    }








    void setUpComponents(){

        back = findViewById(R.id.recycler_backward);
        setScheduleButton = findViewById(R.id.request_addButton);
        save_request = findViewById(R.id.request_saveButton);
        confirmerName = findViewById(R.id.confirmerName);
        information = findViewById(R.id.informationButton);
        requestFormTitle = findViewById(R.id.request_form_title);
        requestID = findViewById(R.id.viewRequest_id);
        confirmCollectBuilder = new AlertDialog.Builder(this);
        buildconfirmCollectDialog();
        saveReqBuilder = new AlertDialog.Builder(this);
        buildSaveDialog();
        newReqBuilder = new AlertDialog.Builder(this);
        buildNewRequestDialog();
//        registerPictureLauncher();


            requestID.setText(collection.getRequest().getRequestCode());

            String status = collection.getRequest().getStatus();

            if (status.equals("COL")){

                requestFormTitle.setText("Completed Collection");
                setScheduleButton.setText("Collected on: " + collection.getDateCollected());
                setScheduleButton.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(129, 133, 138)));
                setScheduleButton.setEnabled(false);
                save_request.setEnabled(false);
                confirmerName.setText("Confirmed by: Brgy. Officer " + collection.getRequest().getOfficerName());

            } else if (status.equals("TBC")) {

                requestFormTitle.setText("Scheduled Collection");
                setScheduleButton.setText("Please collect on: " + collection.getDateScheduled());
                setScheduleButton.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(129, 133, 138)));
                setScheduleButton.setEnabled(false);
                save_request.setEnabled(false);
                confirmerName.setText("Confirmed by: Brgy. Officer " + collection.getRequest().getOfficerName());

            } else if (status.equals("RED")) {

                requestFormTitle.setText("Ready for Collection");
                setScheduleButton.setText("Confirm Document Pick-up");

                save_request.setEnabled(false);
                confirmerName.setText("Confirmed by: Brgy. Officer " + collection.getRequest().getOfficerName());


                setScheduleButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        AlertDialog dialog = saveReqBuilder.create();
                        dialog.show();

                    }
                });


            }

            else {

                requestFormTitle.setText("Cancelled Collection");
                setScheduleButton.setText("Cancelled on:" + collection.getDateCollected());
                setScheduleButton.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(129, 133, 138)));
                setScheduleButton.setEnabled(false);
                save_request.setEnabled(false);

            }



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkBack();
            }});

        information.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // readyNewRequestTutorial();
            }
        });

        requestedDocumentRecycler = findViewById(R.id.requested_recyclerView);
        GridLayoutManager requestedDocument_gridLayoutManager = new GridLayoutManager(returned_collection_page.this, 1);
        requestedDocumentRecycler.setLayoutManager(requestedDocument_gridLayoutManager);
        requested_documents_list = new ArrayList<>();
        requestedDocumentsListAdapter = new requested_documents_list_adapter(returned_collection_page.this, requested_documents_list, returned_collection_page.this, this);
        requestedDocumentRecycler.setAdapter(requestedDocumentsListAdapter);


        requirementRecycler = findViewById(R.id.requirement_recyclerView);
        GridLayoutManager requirement_gridLayoutManager = new GridLayoutManager(returned_collection_page.this, 1);
        requirementRecycler.setLayoutManager(requirement_gridLayoutManager);
        requirements_list = new ArrayList<>();
        requirements_list_adapter = new requirements_list_adapter(returned_collection_page.this, requirements_list,this);
        requirementRecycler.setAdapter(requirements_list_adapter);




    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.add(Calendar.DAY_OF_MONTH, 1);

        //Imposes a limit of at least 18 y.o in the system.
        DatePickerDialog datePickerDialog = new DatePickerDialog(returned_collection_page.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        Calendar selectDate = Calendar.getInstance();
                        selectDate.set(year, monthOfYear, dayOfMonth);
                        boolean isSunday = (selectDate.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY);

                        if (isSunday){

                            Toast.makeText(returned_collection_page.this, "The barangay office is closed on sundays.", Toast.LENGTH_SHORT).show();

                        } else {

                            Calendar  Date = Calendar.getInstance();
                            Date.set(year, month, dayOfMonth);

                            String selectedDate =   year  + "/" + (monthOfYear + 1) + "/" + dayOfMonth ;
                            collectionDate = selectedDate;
                            setScheduleButton.setText(selectedDate);

                        }
                    }

                }, year, month, dayOfMonth);
        datePickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis());
        datePickerDialog.show();
    }

    void populateList(){

        requested_documents_list.clear();

        for (Map.Entry<String, RequestedDocumentModel> entry : collection.getRequest().getRequestedDocument().entrySet()) {
            requested_documents_list.add(entry.getValue());
        }

        getRequirementImages();

    }
    void getRequirementImages() {


        JSONObject postData = new JSONObject();

        RequestQueue queue = Volley.newRequestQueue(returned_collection_page.this);
        String url = APILINK+"/getRequirementURLs ";


        try {

            postData.put("userID", currentAccount.getUUID());
            postData.put("requestCode", collection.getRequest().getRequestCode());
            postData.put("accessKey", currentAccount.getAccessToken());
            postData.put("requestID", collection.getRequest().getRequestID());

        } catch (Exception e){
            e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");
                            JSONArray request_data = jsonResponse.getJSONArray("requirement_URLs");

//                            System.out.println(request_data);

                            if ("success".equals(status)) {
                                for (int i = 0; i < request_data.length() ; i++) {

                                    String URL =  request_data.getJSONObject(i).getString("filePath");
                                    String filename =  URL.substring(URL.lastIndexOf('/') + 1);
                                    String reqId =  request_data.getJSONObject(i).getString("requirementId");
                                    String reqName =  request_data.getJSONObject(i).getString("requirementName");
                                    String reqDesc =  request_data.getJSONObject(i).getString("requirementDesc");

                                    documentRequirementModel requirement = new documentRequirementModel(
                                            reqId,
                                            reqName,
                                            null,
                                            reqDesc,
                                            URL
                                    );

                                    Uri requirementUri = file_utilities.getFromExternalCache(returned_collection_page.this, filename);


                                    // if the file is already in cache, just use it right away.
                                    if (requirementUri != null){
//                                        System.out.println("File:" + filename + "  is already in cache!");

                                        imageData image = new imageData(requirementUri,filename);
                                        requirement.setRequirement_image(image);
                                        requirements_list.add(requirement);
                                        requirements_list_adapter.notifyDataSetChanged();

                                    } else {
                                        // if not, then download the file, then cache it.
                                        downloadRequirement(URL, requirement);
//                                        System.out.println("File:" + filename + " is not in cache, downloading it NOW!");
                                    }





                                }
                            } else {
                                Toast.makeText(returned_collection_page.this, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            System.out.println("ERROR HERE");
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }


        };

        queue.add(stringRequest);



    }


    void downloadRequirement(String url, documentRequirementModel requirement){


        RequestQueue  requestQueue = Volley.newRequestQueue(this);
        String fileName = url.substring(url.lastIndexOf('/') + 1);
        File file = new File(getExternalCacheDir(), fileName);

        Map<String, String> params = new HashMap<>();
        // Add any parameters if needed

        com.example.e_barangayclient.request_pages.viewing_returned_request_detail_pages.returned_request_downloadRequest request = new returned_request_downloadRequest(
                Request.Method.GET,
                url,
                params,
                file, returned_collection_page.this,
                "com.example.e_barangayclient.fileProvider",
                new Response.Listener<Uri>() {
                    @Override
                    public void onResponse(Uri fileUri) {

                        imageData image = new imageData(fileUri,requirement.getRequirement_name());

                        requirement.setRequirement_image(image);

                        requirements_list.add(requirement);
                        requirements_list_adapter.notifyDataSetChanged();
                        // Do something with the URI
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println(  "Error downloading file: " + error.getMessage());
                    }
                }


                );




        requestQueue.add(request);
    }



    //These functions are here so that the custom dialog boxes are built.


    public void buildconfirmCollectDialog(){


        confirmCollectBuilder.setTitle("Confirm document pick-up?");
        confirmCollectBuilder.setMessage("This will notify the administrators.");

        confirmCollectBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button saves the form as a pending form, instead of just "New".
                dialog.dismiss();
                collectConfirmed();


            }});

        confirmCollectBuilder.setNegativeButton("Not yet", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
                // This button discards the form.
                finish();
                //Then they'll be redirected to the home page.
                Intent intent = new Intent(getApplicationContext(),request_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }});

    }


    public void buildSaveDialog(){


        saveReqBuilder.setTitle("Confirm Collection?");
        saveReqBuilder.setMessage("Only confirm when the documents are handed over to you.");

        saveReqBuilder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // Upload the whole request form, along with the documents.
                dialog.dismiss();
               confirmCollection();
            }
        });
        saveReqBuilder.setNegativeButton("Not yet", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

                // This button discards the form.

            }
        });

    }

    //These functions are here so that the custom dialog boxes are built.
    public void buildNewRequestDialog(){

        newReqBuilder.setTitle("Save request form?");
        newReqBuilder.setMessage("You requested document(s).");

        newReqBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button saves the form as a pending form, instead of just "New".
                dialog.dismiss();
           //     uploadRequest();

            }
        });

        newReqBuilder.setNegativeButton("Discard", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button discards the form.
                dialog.dismiss();
                request_utilities.temporary_requested_document_list.clear();
                request_utilities.request = new RequestFormModel();

                //Then they'll be redirected to the home page.
                Intent intent = new Intent(getApplicationContext(),homepage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

    }



    void collectConfirmed(){

        updateApprovedRequestForm(returned_collection_page.this);
        finish();
        Intent intent = new Intent(getApplicationContext(),request_list_page.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }



    private void confirmCollection() {

        JSONObject postData = new JSONObject();

        RequestQueue queue = Volley.newRequestQueue(returned_collection_page.this);
        String url = APILINK+"/confirmCollection ";


        try {

            postData.put("id", collection.getCollectionId());
            postData.put("userId", currentAccount.getUUID());
        } catch (Exception e){
            e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");


                            if ("success".equals(status)) {
                                Intent intent = new Intent(returned_collection_page.this, request_list_page.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            } else {
                                Toast.makeText(returned_collection_page.this, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(stringRequest);






    }


    void updateApprovedRequestForm(Context context){

        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Updating request...");
        progressDialog.setCancelable(false); // prevent user from dismissing dialog


        Map<String, Object> updateMap = new HashMap<>();
//        updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/status" , "Collected");
//        updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/dateCollected" , Utility.getDate());
        Utility.updateFirebaseData(updateMap, context, "Collection confirmed succcessfully!", "There was an error, sorry!" );
        String title =  "Document request collected!";
        String body = homepage.currentAccount.getFullName() + " collected their requested documents! ";
        progressDialog.show();
        prepareNewRequestNotifications(title,body);
        progressDialog.dismiss();


    }


    private void updateTutorialsSeen(List<String> tutorials){
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("Accounts/"+ currentAccount.getUUID() +"/tutorialsSeen",  tutorials);
        Utility.updateFirebaseData(updateMap, returned_collection_page.this, null, null );
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //Use this reference to check details about the request form.

        // replaces the default 'Back' and 'home' button actions
        // Aside from those two buttons, there's no other way to come out of this activity.
        if(keyCode==KeyEvent.KEYCODE_BACK || keyCode==KeyEvent.KEYCODE_HOME)   {

            checkBack();

                    }
        return true;
    }


    void checkBack(){

        // Check if there are document requests in the request form.
        if (request_utilities.temporary_requested_document_list.isEmpty() && collection.getStatus().equals("New") ){

            AlertDialog dialog = zeroDocBuilder.create();
            dialog.show();

        }

        // Now, let's check if new request ba ung form.
        else {
            if (collection.getStatus().equals("New")){

                AlertDialog dialog = newReqBuilder.create();
                dialog.show();

            } else {
                finish();
                Intent intent = new Intent(getApplicationContext(),request_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        }
    }


    @Override
    protected void onDestroy() {
        System.out.println("onDestroy");

        if (!collection.getStatus().equals("New")){
            System.out.println("Request form destroyed.");
            request_utilities.clearUtilityPage();
        } else{

            System.out.println("Request form preserved.");
        }

        super.onDestroy();

    }




    public void ImageDownload(String registrationID, String residentID){


    }


    @Override
    public void onRequestCameraPermission(documentRequirementModel requirement) {

    }
}