package com.example.e_barangayclient.signup_pages;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.e_barangayclient.MainActivity;
import com.example.e_barangayclient.R;



public class signup_complete extends AppCompatActivity {

    public static String email = "", password = "";
    Button toLogInButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_complete);

        toLogInButton = findViewById(R.id.toLogin_button);

        toLogInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(signup_complete.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("new_account_email", email);
                intent.putExtra("new_account_password", password);
                startActivity(intent);
            }
        });

    }
}