package com.example.e_barangayclient;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class welcome_page_one extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popup_tutorial_welcome_document);
    }
}