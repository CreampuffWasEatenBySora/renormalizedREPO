package com.example.e_barangayclient.request_pages.viewing_request_detail_pages;

import android.widget.ImageView;

import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;

public interface cameraActionListener {
    void onRequestCameraPermission( documentRequirementModel requirement );
}
