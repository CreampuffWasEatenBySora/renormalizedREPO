package com.example.e_barangayclient.data_models;

import android.graphics.Bitmap;
import android.net.Uri;

public class imageData {

   private Uri imageUri;

    private String id;



    public Uri getImageUri(){
        return imageUri;
    }


    public String getId(){
        return id;
    }

    public imageData(Uri imageUri, String id){

        this.imageUri = imageUri;

        this.id = id;
    }

    public imageData(){

    }

}
