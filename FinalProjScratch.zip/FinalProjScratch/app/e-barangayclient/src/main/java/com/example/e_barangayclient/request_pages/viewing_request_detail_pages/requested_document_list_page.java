package com.example.e_barangayclient.request_pages.viewing_request_detail_pages;

import static com.example.e_barangayclient.Utility.APILINK;
import static com.example.e_barangayclient.homepage.currentAccount;
import static com.example.e_barangayclient.request_pages.request_utilities.prepareNewRequestNotifications;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.example.e_barangayclient.R;
import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.data_models.imageData;
import com.example.e_barangayclient.homepage;
import com.example.e_barangayclient.request_pages.RequestFormMultipartRequest;
import com.example.e_barangayclient.request_pages.adding_request_pages.adding_request_document_selection_page;
import com.example.e_barangayclient.request_pages.request_list_page;
import com.example.e_barangayclient.request_pages.request_utilities;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class requested_document_list_page extends AppCompatActivity implements cameraActionListener {

    static RecyclerView requestedDocumentRecycler, requirementRecycler;
    private final static int CAMERA_PERMISSION_CODE = 1;

    public RequestedDocumentModel requestedDocument = new RequestedDocumentModel();
    public documentRequirementModel requirement = new documentRequirementModel();
    public ImageView imageView  ;
    int position;
    ActivityResultLauncher<Uri> takePictureLauncher;
    Uri imageUri;
    static TextView emptyAlert;
    TextView requestID;
    TextView requestFormTitle;
    static TextView extra;
    static TextView extra2;
    EditText searchBox;
    TabLayout tabLayout;
    ImageButton back,  filter, information, save_request;
    Button add_request;

    static List<RequestedDocumentModel> requested_documents_list;
    static List<documentRequirementModel> requirements_list;
    static  requested_documents_list_adapter requestedDocumentsListAdapter;
    static  requirements_list_adapter requirements_list_adapter ;
    DatabaseReference databaseReference;
    ValueEventListener requestListener;
    RequestFormModel request = request_utilities.request;
    LinearLayout checkStatus, requirementBox, requestedDocumentBox;
    AlertDialog.Builder saveReqBuilder, zeroDocBuilder, newReqBuilder, confirmCollectBuilder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requested_document_list);

        setUpComponents();


    //    checkforTutorials();
        if ( request.getStatus().equals("New")){
            System.out.println("new request detected: ");
            checkStatus.setVisibility(View.GONE);
            populateNewRequestList();
        } else {
            add_request.setVisibility(View.GONE);
            save_request.setVisibility(View.GONE);
            checkStatus.setVisibility(View.VISIBLE);
            populateList();

            checkStatus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    readyPopUpWindow(request);
                }
            });
        }




    }




//    private void checkforTutorials() {
//
//
//            if (!currentAccount.getTutorialsSeen().contains("new_request")){
//                readyNewRequestTutorial();
//            }
//
//    }






    void setUpComponents(){

        back = findViewById(R.id.recycler_backward);
        emptyAlert = findViewById(R.id.recycler_emptyAlert);
        emptyAlert.setVisibility(View.GONE);
        add_request = findViewById(R.id.request_addButton);
        save_request = findViewById(R.id.request_saveButton);
        checkStatus = findViewById(R.id.request_checkStatus);
        information = findViewById(R.id.informationButton);
        requestFormTitle = findViewById(R.id.request_form_title);
        requestID = findViewById(R.id.viewRequest_id);
        extra  = findViewById(R.id.extra);
        extra2 = findViewById(R.id.extra2);

        zeroDocBuilder = new AlertDialog.Builder(this);
        buildZeroDialog();
        confirmCollectBuilder = new AlertDialog.Builder(this);
        buildconfirmCollectDialog();
        saveReqBuilder = new AlertDialog.Builder(this);
        buildSaveDialog();
        newReqBuilder = new AlertDialog.Builder(this);
        buildNewRequestDialog();
        registerPictureLauncher();
        System.out.println("Temp request list: " + request_utilities.request);

            requestID.setText(request_utilities.request.getRequestCode());
            requestFormTitle.setText("Your " + request_utilities.request.getStatus() + " Request Form");






        add_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                adding_request_document_selection_page.request = request;
                Intent intent = new Intent(getApplicationContext(), adding_request_document_selection_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);

            }
        });

        save_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (request_utilities.temporary_requested_document_list.isEmpty()){

                    AlertDialog dialog = zeroDocBuilder.create();
                    dialog.show();
                } else if (!CompleteRequirements()){
                    Toast.makeText(getApplicationContext().getApplicationContext(), "Complete all requirements first.", Toast.LENGTH_SHORT).show();
                }
                else {
                    AlertDialog dialog = saveReqBuilder.create();
                    dialog.show();
                }

            }});
        checkStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                readyPopUpWindow(request);

            }});

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkBack();
            }});

        information.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // readyNewRequestTutorial();
            }
        });

        requestedDocumentRecycler = findViewById(R.id.requested_recyclerView);
        GridLayoutManager requestedDocument_gridLayoutManager = new GridLayoutManager(requested_document_list_page.this, 1);
        requestedDocumentRecycler.setLayoutManager(requestedDocument_gridLayoutManager);
        requested_documents_list = new ArrayList<>();
        requestedDocumentsListAdapter = new requested_documents_list_adapter(requested_document_list_page.this, requested_documents_list, requested_document_list_page.this,this);
        requestedDocumentRecycler.setAdapter(requestedDocumentsListAdapter);


        requirementRecycler = findViewById(R.id.requirement_recyclerView);
        GridLayoutManager requirement_gridLayoutManager = new GridLayoutManager(requested_document_list_page.this, 1);
        requirementRecycler.setLayoutManager(requirement_gridLayoutManager);
        requirements_list = new ArrayList<>();
        requirements_list_adapter = new requirements_list_adapter(requested_document_list_page.this, requirements_list, requested_document_list_page.this);
        requirementRecycler.setAdapter(requirements_list_adapter);




    }

    boolean CompleteRequirements(){

        boolean isComplete = true;

        for (RequestedDocumentModel document: requested_documents_list){

            for ( Map.Entry<String, documentRequirementModel> entry : document.getRequirements().entrySet()) {

                if (entry.getValue().getRequirement_image() == null){
                    isComplete = false;
                }
            }
        }

        return isComplete;
    }

     static void populateNewRequestList(){
         System.out.println("Temp request list: " + request_utilities.temporary_requested_document_list);


        requested_documents_list.clear();
        for (RequestedDocumentModel document: request_utilities.temporary_requested_document_list
             ) {
            requested_documents_list.add(document);
            System.out.println(requested_documents_list);

            for (Map.Entry<String, documentRequirementModel> entry : document.getRequirements().entrySet()){

                boolean isDuplicate = false;

                for (documentRequirementModel requirement: requirements_list){

                    if (requirement.getRequirement_name().equals(entry.getValue().getRequirement_name())){
                        isDuplicate = true;
                        imageData requirementImage = requirement.getRequirement_image();
                        if ( requirementImage != null){
                            entry.getValue().setRequirement_image(requirementImage);
                            requirement.setRequirement_image(requirementImage);
//                            System.out.println("Entered already existing requirement: " + entry.getValue().getRequirement_name() + " for " + document.getDocName());
                        }

//                        else {
//                            System.out.println("Duplicate Requirement: " + entry.getValue().getRequirement_name() + " for " + document.getDocName());
//                        }
//
                    }
                }

                if (!isDuplicate) {
                    requirements_list.add(entry.getValue());
                }

            }

        }

        if (requested_documents_list.isEmpty()){
            emptyAlert.setVisibility(View.VISIBLE);
            extra.setVisibility(View.GONE);
            extra2.setVisibility(View.GONE);
        } else {
            emptyAlert.setVisibility(View.GONE);
            extra.setVisibility(View.VISIBLE);
            extra2.setVisibility(View.VISIBLE);

        }

         requestedDocumentsListAdapter.notifyDataSetChanged();
         requirements_list_adapter.notifyDataSetChanged();


    }


    void populateList() {

//
//        recyclerView = findViewById(R.id.recyclerView);
//        GridLayoutManager gridLayoutManager = new GridLayoutManager(requested_document_list_page.this, 1);
//        recyclerView.setLayoutManager(gridLayoutManager);
//        requested_documents_list = new ArrayList<>();
//        requested_documents_list_adapter adapter = new requested_documents_list_adapter(requested_document_list_page.this, requested_documents_list);
//        recyclerView.setAdapter(adapter);
//
//
//        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/"
//                +
//                // request.getClientID() +
//                "/Requests/"+ request_utilities.request.getRequestID()+"/requestedDocument");
//        requestListener = databaseReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                requested_documents_list.clear();
//                for (DataSnapshot itemSnapShot: snapshot.getChildren()){
//                    RequestedDocumentModel requestedDocument = itemSnapShot.getValue(RequestedDocumentModel.class);
//
//                    requested_documents_list.add(requestedDocument);
//                    adapter.notifyDataSetChanged();
//                }
//
//                if (requested_documents_list.isEmpty()){
//                    emptyAlert.setVisibility(View.VISIBLE);
//                } else {
//                    emptyAlert.setVisibility(View.GONE);
//
//                }
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//            }
//        });


    }

     void uploadRequest(){
         ImageUpload("E", currentAccount.getUUID());

//
//        final boolean[] success = {true};
//
//        ProgressDialog progressDialog = new ProgressDialog(requested_document_list_page.this);
//        progressDialog.setMessage("Sending request...");
//        progressDialog.setCancelable(false); // prevent user from dismissing dialog
//        progressDialog.show();
//
//
//
//        // Uploads the request form created earlier
//        RequestFormModel requestEntry =  request_utilities.request;
//        requestEntry.setStatus("Pending");
//        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/" + requestEntry.getClientID() +"/Requests/" );
//         System.out.println("Initiated request upload");
//        databaseReference.child(requestEntry.getRequestID()).setValue(requestEntry).addOnSuccessListener(new OnSuccessListener<Void>() {
//            @Override
//            public void onSuccess(Void unused) {
//                System.out.println("Completed request upload");
//
//              DatabaseReference documentDatabaseReference = FirebaseDatabase.getInstance().getReference("Accounts/" + requestEntry.getClientID() +"/Requests/" + requestEntry.getRequestID() +"/requestedDocument");
//
//                //sets the requested documents in the uploaded request form
//                for (RequestedDocumentModel document: request_utilities.temporary_requested_document_list) {
//
//                    System.out.println("Uploading document: " + document.getDocName());
//                    String reqDocID = documentDatabaseReference.push().getKey();
//                    documentDatabaseReference.child(reqDocID).setValue(document).addOnSuccessListener(new OnSuccessListener<Void>() {
//                        @Override
//                        public void onSuccess(Void unused) {
//                            progressDialog.dismiss();
//
//                            System.out.println("Document uploaded safely: " + document.getDocName());
//                            int docCount = request_utilities.temporary_requested_document_list.size();
//                            String title =  "New request submitted!";
//                            String body = homepage.currentAccount.getFullName() + " has requested "+ docCount+" documents!";
//                            prepareNewRequestNotifications(title, body);
//                            Toast.makeText(getApplicationContext().getApplicationContext(), "Request successfully entered!", Toast.LENGTH_SHORT).show();
//                            Intent intent = new Intent(getApplicationContext(), request_list_page.class);
//                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//                            startActivity(intent);
//                        }
//                    }).addOnFailureListener(new OnFailureListener() {
//
//                        @Override
//
//                        public void onFailure(@NonNull Exception e) {
//                            progressDialog.dismiss();
//
//                            System.out.println("Error: " + e);
//                            success[0] = false;
//                        }
//                    });}
//
//
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(getApplicationContext().getApplicationContext(), "Data Entry unsuccessful!", Toast.LENGTH_SHORT).show();
//                progressDialog.dismiss();
//
//            }});

    }


    //These functions are here so that the custom dialog boxes are built.
    public void buildZeroDialog(){


        zeroDocBuilder.setTitle("Discard Request form?");
        zeroDocBuilder.setMessage("You're about to leave without requesting a single document.");

        zeroDocBuilder.setPositiveButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button saves the form as a pending form, instead of just "New".



            }});

        zeroDocBuilder.setNegativeButton("Discard", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button discards the form.
                request_utilities.temporary_requested_document_list.clear();
                request_utilities.request = new RequestFormModel();

                //Then they'll be redirected to the home page.
                Intent intent = new Intent(getApplicationContext(),request_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);

                startActivity(intent);

            }});

    }

    public void buildconfirmCollectDialog(){


        confirmCollectBuilder.setTitle("Confirm document pick-up?");
        confirmCollectBuilder.setMessage("This will notify the administrators.");

        confirmCollectBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button saves the form as a pending form, instead of just "New".
                dialog.dismiss();
                collectConfirmed();


            }});

        confirmCollectBuilder.setNegativeButton("Not yet", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
                // This button discards the form.
                finish();
                //Then they'll be redirected to the home page.
                Intent intent = new Intent(getApplicationContext(),request_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }});

    }


    public void buildSaveDialog(){


        saveReqBuilder.setTitle("Save Request form?");
        saveReqBuilder.setMessage("You are about to save a request.");

        saveReqBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // Upload the whole request form, along with the documents.
                dialog.dismiss();
                uploadRequest();
            }
        });
        saveReqBuilder.setNegativeButton("Not yet", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

                // This button discards the form.

            }
        });

    }

    //These functions are here so that the custom dialog boxes are built.
    public void buildNewRequestDialog(){

        newReqBuilder.setTitle("Save request form?");
        newReqBuilder.setMessage("You requested document(s).");

        newReqBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button saves the form as a pending form, instead of just "New".
                dialog.dismiss();
                uploadRequest();

            }
        });

        newReqBuilder.setNegativeButton("Discard", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // This button discards the form.
                dialog.dismiss();
                request_utilities.temporary_requested_document_list.clear();
                request_utilities.request = new RequestFormModel();

                //Then they'll be redirected to the home page.
                Intent intent = new Intent(getApplicationContext(),homepage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });

    }

    void readyPopUpWindow(RequestFormModel request){

        Button collect, confirm;
        TextView status, confirmerDate, collectDate;

        final Dialog dialog = new Dialog(this);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.popup_request_status);
        dialog.setCancelable(false);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        confirm = dialog.findViewById(R.id.request_popup_confirm);
        collect = dialog.findViewById(R.id.request_popup_collectConfirm);
        status = dialog.findViewById(R.id.popup_requested_document_approveDate);
        confirmerDate = dialog.findViewById(R.id.popup_requested_document_confirmerDate);
        collectDate = dialog.findViewById(R.id.popup_requested_document_collectDate);
        String statusText = "";
        String confirmerDateText = "";
        String collectDateText = "";

        ImageView iconImageView = dialog.findViewById(R.id.iconImageView);

        if (request.getStatus().equals("Ready")){
            iconImageView.setImageResource(R.drawable.approved_icon);
            statusText = "Approved \nfor collection";
           // confirmerDateText = "by "+ request.getConfirmer() +" on " + request.getDateRelease() + ".";
            collectDateText = "You can collect the documents.";

        } else if (request.getStatus().equals("Rejected")){
            iconImageView.setImageResource(R.drawable.rejected_icon);
            statusText = "Rejected";
          //  confirmerDateText = "By "+ request.getConfirmer() +"\n\nDue to: " + request.getRemarks() + " on " + request.getDateRelease() + "." ;
            collectDateText = "It will not be collected.";
            collect.setVisibility(View.GONE);

        } else if (request.getStatus().equals("Collected")) {
            iconImageView.setImageResource(R.drawable.collected_icon);
            statusText = "Approved";
         //   confirmerDateText = "by " + request.getConfirmer()+ " on " + request.getDateRelease() + ".";
         //   collectDateText = "You collected it on " + request.getDateCollected() + ".";
                collect.setVisibility(View.GONE);

        } else {

            iconImageView.setImageResource(R.drawable.pending_icon);
            statusText = "Pending";
            confirmerDateText = "You submitted this request on: " + request.getDateRequested() +".";
            collectDateText = "Please wait patiently until an admin approves your request for collection.";
            collect.setVisibility(View.GONE);

        }



        status.setText(statusText);
        confirmerDate.setText(confirmerDateText);
        collectDate.setText(collectDateText);

        collect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Dialog dialog1 = confirmCollectBuilder.create();
                dialog1.show();
            }
        });

        confirm.setOnClickListener(v -> dialog.dismiss());


        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);





    }


    void collectConfirmed(){

        updateApprovedRequestForm(requested_document_list_page.this);
        finish();
        Intent intent = new Intent(getApplicationContext(),request_list_page.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }

//    void readyNewRequestTutorial(){
//
//        Button next;
//        TabLayout StepTabLayout;
//        TextView stepText, appTitle;
//        ImageView stepImage;
//
//        final Dialog dialog = new Dialog(this);
//
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.request_form_instructions);
//        dialog.setCancelable(false);
//
//        next = dialog.findViewById(R.id.next_button);
//        StepTabLayout = dialog.findViewById(R.id.tutorialTab);
//        stepImage  = dialog.findViewById(R.id.stepImage);
//        stepText = dialog.findViewById(R.id.stepBox);
//
//        StepTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                switch (tab.getPosition()) {
//                    case 0:
//                        stepImage.setImageResource(R.drawable.requestpic1);
//                        stepText.setText("This is your request form. \\nThis page allows you to add your desired document(s) to your request.");
//                        break;
//
//                    case 1:
//                        stepImage.setImageResource(R.drawable.requestpic2);
//                        stepText.setText("You can navigate to this page by clicking the 'Add Document' button. Then, select the document you want.");
//                        break;
//
//                    case 2:
//                        stepImage.setImageResource(R.drawable.requestpic3);
//                        stepText.setText("Once you finish adding all of the documents you need, confirm your request using the 'Confirm Request' button below.");
//                        break;
//
//
//                    default:
//                        stepImage.setImageResource(R.drawable.pendingpic1);
//                        stepText.setText("This is where you can view your pending requests.");
//                }
//            }
//
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {}
//
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {}
//        });
//
//        for (int i = 0; i < StepTabLayout.getTabCount(); i++) {
//            TextView tabTextView = (TextView) LayoutInflater.from(this).inflate(R.layout.bullet_empty_tab, null);
//            tabTextView.setText("");
//            StepTabLayout.getTabAt(i).setCustomView(tabTextView);
//        }
//
//
//        next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int tab = StepTabLayout.getSelectedTabPosition();
//                System.out.println("Selected tab: " + tab + " and tab count:" + StepTabLayout.getTabCount()  );
//                if (StepTabLayout.getTabCount() > tab+1){
//                    TabLayout.Tab selectTab = StepTabLayout.getTabAt(tab + 1);
//                    selectTab.select();
//                } else {
//
//                    List<String> getTutorialsSeen = new ArrayList<>();
//
//                    if (currentAccount.getTutorialsSeen() != null){
//
//                        currentAccount.getTutorialsSeen().add("new_request");
//                        updateTutorialsSeen(currentAccount.getTutorialsSeen());
//
//                    } else {
//
//                        getTutorialsSeen.add("new_request");
//                        updateTutorialsSeen(getTutorialsSeen);
//
//                    }
//
//                    dialog.dismiss();
//
//
//                }
//
//            }
//        });
//
//
//
//        dialog.show();
//        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
//
//
//    }


     void updateApprovedRequestForm(Context context){

        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Updating request...");
        progressDialog.setCancelable(false); // prevent user from dismissing dialog


        Map<String, Object> updateMap = new HashMap<>();
//        updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/status" , "Collected");
//        updateMap.put("Accounts/" + request.getClientID() + "/Requests/" + request.getRequestID() + "/dateCollected" , Utility.getDate());
        Utility.updateFirebaseData(updateMap, context, "Collection confirmed succcessfully!", "There was an error, sorry!" );
        String title =  "Document request collected!";
        String body = homepage.currentAccount.getFullName() + " collected their requested documents! ";
        progressDialog.show();
        prepareNewRequestNotifications(title,body);
        progressDialog.dismiss();


    }


    private void updateTutorialsSeen(List<String> tutorials){
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("Accounts/"+ currentAccount.getUUID() +"/tutorialsSeen",  tutorials);
        Utility.updateFirebaseData(updateMap,requested_document_list_page.this, null, null );
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //Use this reference to check details about the request form.

        // replaces the default 'Back' and 'home' button actions
        // Aside from those two buttons, there's no other way to come out of this activity.
        if(keyCode==KeyEvent.KEYCODE_BACK || keyCode==KeyEvent.KEYCODE_HOME)   {

            checkBack();

                    }
        return true;
    }


    void checkBack(){

        // Check if there are document requests in the request form.
        if (request_utilities.temporary_requested_document_list.isEmpty() && request.getStatus().equals("New") ){

            AlertDialog dialog = zeroDocBuilder.create();
            dialog.show();

        }

        // Now, let's check if new request ba ung form.
        else {
            if (request.getStatus().equals("New")){

                AlertDialog dialog = newReqBuilder.create();
                dialog.show();

            } else {
                finish();
                Intent intent = new Intent(getApplicationContext(),request_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        }
    }


    @Override
    protected void onDestroy() {
        System.out.println("onDestroy");

        if (!request.getStatus().equals("New")){
            System.out.println("Request form destroyed.");
            request_utilities.clearUtilityPage();
        } else{

            System.out.println("Request form preserved.");
        }

        super.onDestroy();

    }

    private void registerPictureLauncher() {
        takePictureLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicture(),
                result -> {
                    if (result) {

                        for (RequestedDocumentModel document: request_utilities.temporary_requested_document_list
                        ) {

                            for (Map.Entry<String, documentRequirementModel> entry : document.getRequirements().entrySet()){
                                if ( entry.getValue().getRequirement_name().equals(requirement.getRequirement_name())){
                                    imageData requirementImage = new imageData(imageUri,requirement.getRequirement_Id());
                                    requirements_list.get(requirements_list.indexOf(requirement)).setRequirement_image(requirementImage);

                                }
                            }

                        }
                        System.out.println("image assigned.");
                        populateNewRequestList();


                    }
                }
        );
    }

    @Override
    public void onRequestCameraPermission(documentRequirementModel requirement_from_list) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
        } else {
            requirement = requirement_from_list;
            launchCamera();
        }
    }

    private void launchCamera() {
        imageUri = createImageUri( );
        takePictureLauncher.launch(imageUri);
    }

    private Uri createImageUri() {
        File imageFile = new File(getFilesDir(),requirement.getRequirement_name());
        return FileProvider.getUriForFile(this, "com.example.e_barangayclient.fileProvider", imageFile);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            launchCamera( );
        } else {
            Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
        }
    }


    public void ImageUpload(String registrationID, String residentID){

        JSONObject  requestData = new JSONObject();
        JSONObject  requestedDocuments = new JSONObject();



        RequestQueue queue = Volley.newRequestQueue(requested_document_list_page.this);
        String url = APILINK+"/storeRequest";


        List<imageData> imageDataList = new ArrayList<>();

        try {

            requestData.put("requestCode", request.getRequestCode());
            requestData.put("requesterID", currentAccount.getUUID());
            requestData.put("accessKey", currentAccount.getAccessToken());


            for (RequestedDocumentModel document : requested_documents_list){

                JSONObject requestedDocument_details =  new JSONObject();
                JSONArray requirements =  new JSONArray();

                requestedDocument_details.put("id", document.getRequested_docID());
                requestedDocument_details.put("reason", document.getPurpose());
                requestedDocument_details.put("quantity", document.getQuantity());

                for (Map.Entry<String, documentRequirementModel> entry: document.getRequirements().entrySet()){

                    JSONObject requirement  =  new JSONObject();
                    requirement.put("id", entry.getValue().getRequirement_Id());
                    requirements.put(requirement);
                }
                System.out.println("Added requirements to JSON: " + requirements);
                requestedDocument_details.put("requirements", requirements);
                requestedDocuments.put(document.getRequested_docID(), requestedDocument_details);

            }

            requestData.put("requested_documents",requestedDocuments);


            for (documentRequirementModel requirement: requirements_list) {
                         imageDataList.add(requirement.getRequirement_image());
            }

            System.out.println(imageDataList);

        }catch (Exception e){
            e.printStackTrace();
        }



        RequestFormMultipartRequest stringRequest = new RequestFormMultipartRequest(url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);

                            String status = jsonResponse.getString("status");

                            if ( status.equals("success")){
                                Toast.makeText(requested_document_list_page.this, "Upload successful!", Toast.LENGTH_SHORT).show();
                                request_utilities.request = new RequestFormModel();
                                request_utilities.temporary_requested_document_list.clear();
                                Intent intent = new Intent(requested_document_list_page.this, request_list_page.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            } else {
                                Toast.makeText(requested_document_list_page.this, "Upload failed!" , Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }, imageDataList, requested_document_list_page.this, requestData);

        queue.add(stringRequest);

    }




}