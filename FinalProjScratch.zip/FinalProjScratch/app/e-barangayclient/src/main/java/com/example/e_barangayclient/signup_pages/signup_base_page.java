package com.example.e_barangayclient.signup_pages;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.e_barangayclient.MainActivity;
import com.example.e_barangayclient.R;
import com.example.e_barangayclient.data_models.AccountModel;
import com.example.e_barangayclient.data_models.address;
import com.example.e_barangayclient.data_models.imageData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;

public class signup_base_page extends AppCompatActivity {


    RecyclerView recyclerView;
    SignUpPagerAdapter adapter;

    public static boolean[] verifiedSteps = {false, false, false, false, false};
    TextView  subheader, header;
    public static TabLayout tabLayout;
    private ViewPager2 viewPager2;

    ImageButton back, search, filter;
    public static String

            registerID, fragMunicipal, fragSubdivision, fragBarangay, fragHouseNum, fragPhoneNum, fragPassword,

    enterName, enterbirhtdate,
            enterIDtype,
            enterEmail,
            enterToken;
    //Firebase entry strings
    public static address Address = new address();
    public static Uri selfiePic, docPic;
    public static imageData selfieData, docData;
    private LinearLayout exitButton;
    public static AccountModel accountEntry = new AccountModel();

    String listMode = "Client", Status = "Pending";
    AccountModel newUser;
    static DatabaseReference databaseReference;
    static ValueEventListener accountListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_base_page);

        setUpComponents();
        setNewToken();
    }

    void setUpComponents(){

        subheader = findViewById(R.id.signup_subheader);
        header = findViewById(R.id.signup_header);
        back = findViewById(R.id.recycler_backward);
      //  search = findViewById(R.id.recycler_search);
        tabLayout = findViewById(R.id.recycler_tab);
        viewPager2 = findViewById(R.id.viewPager);
        exitButton = findViewById(R.id.signup_backToLOGIN);

        tabLayout.addTab(tabLayout.newTab().setText("1"));
        tabLayout.addTab(tabLayout.newTab().setText("2"));
        tabLayout.addTab(tabLayout.newTab().setText("3"));
        tabLayout.addTab(tabLayout.newTab().setText("4"));
        tabLayout.addTab(tabLayout.newTab().setText("5"));

        FragmentManager fragmentManager = getSupportFragmentManager();
        adapter = new SignUpPagerAdapter(fragmentManager, getLifecycle());
        viewPager2.setAdapter(adapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(signup_base_page.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }

    public static void setNewToken( ){


        //Along with notification permission and settings, also manage token generation here:
        FirebaseMessaging firebaseMessaging = FirebaseMessaging.getInstance();
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            System.out.println("Token is not received... " );
                            return;
                        }

                        // Get new FCM registration token
                        String token = task.getResult();
                        System.out.println("Token is successfully received: " + token);
                        enterToken = token;

                    }
                });

    }


    void closeActivity(){

        finish();
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);

    }

    @Override
    protected void onPause() {
        super.onPause();


    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {

        // replaces the default 'Back' button actions
        // Aside from this button, there's no other way to come out of this activity.
        if(keyCode==KeyEvent.KEYCODE_BACK )   {

            //This is made to prevent going back to the previous activities such as:
            // adding, editing , or interacting with elements.
            closeActivity();
        }
        return true;
    }

}