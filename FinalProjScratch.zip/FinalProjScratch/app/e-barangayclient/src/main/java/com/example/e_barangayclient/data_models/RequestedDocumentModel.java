package com.example.e_barangayclient.data_models;

//Basically, parang form to. Parang questionnaire.

import java.util.HashMap;

public class RequestedDocumentModel {

    private String requested_docID;
    private String docName;
    private String purpose;
    private String status;
    private int quantity;

    private HashMap<String, documentRequirementModel> requirements;
    public HashMap<String, documentRequirementModel> getRequirements() {return requirements; }

    public String getRequested_docID() { return requested_docID; }
    public String getDocName() { return docName; }
    public String getPurpose() { return purpose; }
    public int getQuantity() { return quantity; }
    public String getStatus() { return status; }

    public void setPurpose(String purpose){
        this.purpose = purpose;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public RequestedDocumentModel(String requestDocID,
                                  String documentName,
                                  String purpose,
                                  int quantity,
                                  HashMap<String, documentRequirementModel>  requirements,
                                  String status
                                  ){

        this.requested_docID = requestDocID;
        this.docName = documentName;
        this.quantity = quantity;
        this.purpose = purpose;
        this.requirements = requirements;
        this.status = status;


    }

    public RequestedDocumentModel(){

    }

}


