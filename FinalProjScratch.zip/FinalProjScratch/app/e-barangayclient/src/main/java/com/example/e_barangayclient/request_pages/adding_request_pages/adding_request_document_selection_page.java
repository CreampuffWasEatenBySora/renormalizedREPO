package com.example.e_barangayclient.request_pages.adding_request_pages;

import static com.example.e_barangayclient.Utility.APILINK;
import static com.example.e_barangayclient.request_pages.request_utilities.temporary_documentList;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_barangayclient.R;
import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.AvailableDocumentModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.homepage;
// import com.example.e_barangayclient.request_pages.request_list_page;
import com.example.e_barangayclient.request_pages.request_utilities;
// import com.example.e_barangayclient.request_pages.viewing_request_detail_pages.requested_document_list_page;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class adding_request_document_selection_page extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView emptyAlert;
    TabLayout pagination;
    ImageButton back, filter;

    ImageView clear;
    ImageButton searchButton;
    ProgressBar LoadingBar;
    EditText searchBox;
    static String  filterText ="";
    int page = 1;

    int pageLimit = 5;
    List<AvailableDocumentModel> limitedlist = new ArrayList<>();;
    List<AvailableDocumentModel> documentList;
    List<String> PickedDocuments = new ArrayList<>();
    public static RequestFormModel request = request_utilities.request;
    ValueEventListener documentListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document_list);

        setUpComponents();
        populateList(filterText);


    }

    void setUpComponents(){

        back = findViewById(R.id.recycler_backward);
        LoadingBar = findViewById(R.id.loadingBar);
        searchBox = findViewById(R.id.recycler_search);
        searchButton = findViewById(R.id.recycler_searchButton);
        pagination = findViewById(R.id.pagination_tab);
        clear  = findViewById(R.id.clearButton);
        emptyAlert = findViewById(R.id.recycler_emptyAlert);
        emptyAlert.setVisibility(View.GONE);
        LoadingBar.setVisibility(View.GONE);
        for (RequestedDocumentModel document: request_utilities.temporary_requested_document_list){

        //    PickedDocuments.add(document.getDocName());

        }

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                // Called to notify you that somewhere within the text, characters have been added or removed.
                // This is where you can perform your action after the text has changed.
                filterText = editable.toString();
                // Add your logic here to handle the changed text
                if (filterText.isEmpty()){
                    clear.setVisibility(View.GONE);
                    populateList(filterText);

                } else {
                    clear.setVisibility(View.VISIBLE);
                }

            }
        });


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = searchBox.getText().toString();
                populateList(filterText);
            }
        });


        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = "";
                searchBox.setText("");
            }
        });

//        back.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(adding_request_document_selection_page.this, requested_document_list_page.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
//                startActivity(intent);
//            }
//        });

    }



    void populateList(String filter) {

        filter = filter.toLowerCase();
        documentList = new ArrayList<>();

        LoadingBar.setVisibility(View.VISIBLE);

        RequestQueue queue = Volley.newRequestQueue(adding_request_document_selection_page.this);
        String url = APILINK+"/fetchDocuments";
        JSONObject postData = new JSONObject();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            LoadingBar.setVisibility(View.GONE);

                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");
                            JSONObject document_data = jsonResponse.getJSONObject("document_data");
                            JSONObject documents = document_data.getJSONObject("documents");

                            if ("success".equals(status)) {


                                JSONArray doc_keys = documents.names();

                                for (int i = 0; i < doc_keys.length() ; i++) {

                                    AvailableDocumentModel availableDocument = new AvailableDocumentModel();

                                    String key = doc_keys.getString (i);
                                    JSONObject document = documents.getJSONObject(key);
                                    availableDocument.setDocumentID(document.getString("id"));
                                    availableDocument.setDocName(document.getString("name"));
                                    availableDocument.setDocumentDescription(document.getString("description"));

                                    HashMap<String, documentRequirementModel> requirement_list = new HashMap<>();
                                    JSONObject requirements = document.getJSONObject("requirements");

                                    JSONArray req_keys = requirements.names();

                                    for (int j = 0; j < requirements.length(); j++) {

                                        String req_key = req_keys.getString(j);

                                        JSONObject requirement = requirements.getJSONObject(req_key);
                                        documentRequirementModel requirement_entry =  new documentRequirementModel(
                                                requirement.getString("id"),
                                                requirement.getString("name"),
                                                null,
                                                requirement.getString("description"), null
                                        );

                                        requirement_list.put( requirement.getString("name"), requirement_entry);


                                    }
                                    availableDocument.setRequirements(requirement_list);

                                    if (!temporary_documentList.contains(availableDocument.getDocumentID())){
                                        documentList.add(availableDocument);

                                    }

                                }

                                setPaginationLimits(documentList.size());
                                limitedPopulateList(1);



                            } else {
                                Toast.makeText(adding_request_document_selection_page.this, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            System.out.println("ERROR HERE");
                            e.printStackTrace();
                            LoadingBar.setVisibility(View.GONE);

                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(stringRequest);



    }


    void setPaginationLimits(int setSize){

        pagination.removeAllTabs();

        int pageNums = setSize / pageLimit;
        int remainder = setSize % pageLimit;
        for (int i = 0; i <= pageNums; i++) {

            if (!((remainder == 0) && (i == pageNums))){
                pagination.addTab(pagination.newTab().setText(String.valueOf(i+1)));
            }
        }

        pagination.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                limitedPopulateList(tab.getPosition()+1);
                page = tab.getPosition()+1;
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
    void limitedPopulateList(int page){


        limitedlist.clear();
        recyclerView = findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(adding_request_document_selection_page.this, 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        adding_request_available_document_list_adapter adapter = new adding_request_available_document_list_adapter(adding_request_document_selection_page.this, limitedlist);
        recyclerView.setAdapter(adapter);



        int startRange = (page * pageLimit) - pageLimit; // Calculate start index of the range
        int upperRange = Math.min(page * pageLimit, documentList.size()); // Calculate end index of the range


        for (int i = startRange; i < upperRange; i++) {

            if (!request_utilities.temporary_requested_document_list.contains(documentList.get(i))){
                limitedlist.add(documentList.get(i));
                adapter.notifyDataSetChanged();
            }

        }

        if (documentList.isEmpty()){
            emptyAlert.setVisibility(View.VISIBLE);
        } else {
            emptyAlert.setVisibility(View.GONE);

        }

        System.out.println("Document list size: " + documentList.size() + " Page list size: " + limitedlist.size()  );


    }



    public static void requestPopUpWindow(AvailableDocumentModel document, Context context){




    }




     public static void uploadData(String purpose, String documentName, Context context){
//        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/" + request_utilities.request.getClientID() + "/Requests/" + request_utilities.request.getRequestID() +"/requestedDocument");
//
//        String reqDocID = databaseReference.push().getKey();
//        RequestedDocumentModel requestDoc = new  RequestedDocumentModel(  reqDocID,
//                documentName,
//                purpose,
//                "Pending", "Pending");
//
//        databaseReference.child(reqDocID).setValue(requestDoc).addOnSuccessListener(new OnSuccessListener<Void>() {
//            @Override
//            public void onSuccess(Void unused) {
////
////                Intent intent = new Intent(context, requested_document_list_page.class);
////                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
////                context.startActivity(intent);
////                Toast.makeText(context.getApplicationContext(), "Documented entered successfully!", Toast.LENGTH_SHORT).show();
//
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(context.getApplicationContext(), "Data Entry unsuccessful!", Toast.LENGTH_SHORT).show();
//            }
//        });

    }


    @Override
    protected void onPause() {
        super.onPause();
    }
}