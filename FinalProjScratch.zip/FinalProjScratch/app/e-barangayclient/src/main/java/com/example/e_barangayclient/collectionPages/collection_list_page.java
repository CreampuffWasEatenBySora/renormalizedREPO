package com.example.e_barangayclient.collectionPages;

import static com.example.e_barangayclient.Utility.APILINK;
import static com.example.e_barangayclient.homepage.currentAccount;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_barangayclient.R;
import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.CollectFormModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.homepage;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class collection_list_page extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView emptyAlert;
    TabLayout tabLayout, pagination;
    int pageLimit = 5;
    int page = 1;
    EditText searchBox;
    ProgressBar progressBar;
    static String filterText ="", status ="TBC";
    ImageButton back,  searchButton, information;
    ImageView clear;
    List<CollectFormModel> collectionList;
    List<CollectFormModel> limitedlist = new ArrayList<>();;

    public static DatabaseReference requestDatabaseReference;
    static ValueEventListener requestListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection_list);

        Utility.createNotificationChannel(this);
        Utility.fetchNotifications(currentAccount.getUUID(), collection_list_page.this);

        setUpComponents();
     //   checkforTutorials();
        populateList("TBC", filterText);


    }

    void setUpComponents(){

        back = findViewById(R.id.recycler_backward);
        searchBox = findViewById(R.id.recycler_search);
        clear = findViewById(R.id.clearButton);
        searchButton = findViewById(R.id.request_searchButton);
        progressBar  = findViewById(R.id.loadingBar);
        tabLayout = findViewById(R.id.recycler_tab);
        emptyAlert = findViewById(R.id.recycler_emptyAlert);
        emptyAlert.setVisibility(View.GONE);
        information = findViewById(R.id.informationButton);
        clear.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);

//        information.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                switch (status) {
//                    case "Pending":
//                        readyPendingTutorial();
//                        break;
//                    case "Ready":
//                        readyApprovedTutorial();
//                        break;
//                    case "Rejected":
//                        readyRejectedTutorial();
//                        break;
//                    case "Collected":
//                        readyCollectedTutorial();
//                        break;
//                    default:
//                        readyPendingTutorial();
//                }
//            }
//        });

        pagination = findViewById(R.id.pagination_tab);


        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        status = "TBC";
                        break;
                    case 1:
                        status = "COL";
                        break;
                    case 2:
                        status = "CAN";
                        break;
                    default:
                        status = "TBC"; // Default to pending if unknown tab is selected
                }
          //      checkforTutorials();
                populateList(status, filterText);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });


        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                // Called to notify you that somewhere within the text, characters have been added or removed.
                // This is where you can perform your action after the text has changed.
                filterText = editable.toString();
                // Add your logic here to handle the changed text
                if (filterText.isEmpty()){
                    clear.setVisibility(View.GONE);
                    populateList(status, filterText);

                } else {
                    clear.setVisibility(View.VISIBLE);
                }

            }
        });


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = searchBox.getText().toString();
                populateList(status, filterText);
            }
        });


        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterText = "";
                searchBox.setText("");
                populateList(status, filterText);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),homepage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);

            }
        });



    }

//    private void checkforTutorials() {
//        if (currentAccount.getTutorialsSeen() != null){
//
//            if (!currentAccount.getTutorialsSeen().contains("Pending") && status.equals("Pending")){
//                readyPendingTutorial();
//
//            } else if(!currentAccount.getTutorialsSeen().contains("Ready") && status.equals("Ready")){
//                readyApprovedTutorial();
//            } else if(!currentAccount.getTutorialsSeen().contains("Rejected") && status.equals("Rejected")){
//                readyRejectedTutorial();
//            } else if(!currentAccount.getTutorialsSeen().contains("Collected") && status.equals("Collected")){
//                readyCollectedTutorial();
//            }
//        } else {
//
//            if (!currentAccount.getTutorialsSeen().contains("Pending") && status.equals("Pending")){
//                readyPendingTutorial();
//
//            } else if(!currentAccount.getTutorialsSeen().contains("Ready") && status.equals("Ready")){
//                readyApprovedTutorial();
//
//            } else if(!currentAccount.getTutorialsSeen().contains("Rejected") && status.equals("Rejected")){
//                readyRejectedTutorial();
//
//            } else if(!currentAccount.getTutorialsSeen().contains("Collected") && status.equals("Collected")){
//                readyCollectedTutorial();
//            }
//        }
//
//    }

    void populateList(String filter_status, String filter) {

        filter = filter.toLowerCase().trim();
        limitedlist.clear();
        collectionList = new ArrayList<>();

        progressBar.setVisibility(View.VISIBLE);

        JSONObject postData = new JSONObject();

        RequestQueue queue = Volley.newRequestQueue(collection_list_page.this);
        String url = APILINK+"/fetchCollections ";


        try {

            postData.put("userID", currentAccount.getUUID());

        } catch (Exception e){
            e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            progressBar.setVisibility(View.GONE);
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");

                            // Data about the collection record
                            JSONArray data = jsonResponse.getJSONArray("collection_data");


                            System.out.println(data);

                            if ("success".equals(status)) {


                                for (int i = 0; i < data.length() ; i++) {

                                    JSONObject request = data.getJSONObject(i);
                                    HashMap<String, RequestedDocumentModel> requested_document_list = new HashMap<>();

                                    if (request.getString("status").equals(filter_status)){

                                            JSONArray requested_documents = request.getJSONArray("requested_doc");
                                            for (int j = 0; j < requested_documents.length(); j++) {

                                                JSONObject document = requested_documents.getJSONObject(j);

                                        if (!document.getString("status").equals("REJ")){

                                            RequestedDocumentModel requested_document_entry = new RequestedDocumentModel(
                                                    request.getString("requestID"),
                                                    document.getString("docName"),
                                                    document.getString("request_reason"),
                                                    document.getInt("request_quantity"),
                                                    null,
                                                    document.getString("status")
                                            );

                                            requested_document_list.put(document.getString("docName"), requested_document_entry);
                                        }

                                        }

                                    RequestFormModel request_form = new RequestFormModel(
                                            request.getString("requestID"),
                                            request.getString("collectID"),
                                            request.getString("status"),
                                            request.getString("requestCode"),
                                            request.getString("dateScheduled"),
                                            request.getString("dateCollected"),
                                            requested_document_list,
                                            request.getString("dateRequested"),
                                            request.getString("dateResponded"),
                                            request.getString("reqApproveOfficerName"),
                                            request.getString("status"),
                                            null
                                    );


                                        CollectFormModel collection = new CollectFormModel(
                                                request.getString("collectID"),
                                                request.getString("dateScheduled"),
                                                request.getString("dateCollected"),
                                                request_form,
                                                request.getString("reqCollectOfficerName"),
                                                request.getString("status"),
                                                request.getString("remarks")
                                        );

                                        if ( !filterText.isEmpty()){

                                            if (collection.getRequest().getRequestCode().contains(filterText)){

                                                collectionList.add(collection);

                                            }

                                        } else {
                                            collectionList.add(collection);

                                        }

                                    }
                                }

                                setPaginationLimits(collectionList.size());
                                limitedPopulateList(1);

                            } else {
                                Toast.makeText(collection_list_page.this, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            System.out.println("ERROR HERE");
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(stringRequest);



    }



    void setPaginationLimits(int setSize){

        pagination.removeAllTabs();

        int pageNums = setSize / pageLimit;
        int remainder = setSize % pageLimit;
        for (int i = 0; i <= pageNums; i++) {

            if (!((remainder == 0) && (i == pageNums))){
                pagination.addTab(pagination.newTab().setText(String.valueOf(i+1)));
            }
        }

        pagination.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                limitedPopulateList(tab.getPosition()+1);
                page = tab.getPosition()+1;
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
    void limitedPopulateList(int page){

        limitedlist.clear();
        recyclerView = findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(collection_list_page.this, 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        list_adapter adapter = new  list_adapter(collection_list_page.this, limitedlist);
        recyclerView.setAdapter(adapter);

        int startRange = (page * pageLimit) - pageLimit; // Calculate start index of the range
        int upperRange = Math.min(page * pageLimit, collectionList.size()); // Calculate end index of the range


        for (int i = startRange; i < upperRange; i++) {
            limitedlist.add(collectionList.get(i));
            adapter.notifyDataSetChanged();
        }

        if (collectionList.isEmpty()){
            emptyAlert.setVisibility(View.VISIBLE);
        } else {
            emptyAlert.setVisibility(View.GONE);

        }

        // Notify adapter after adding all items

    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {

        // replaces the default 'Back' button actions
        // Aside from this button, there's no other way to come out of this activity.
        if(keyCode==KeyEvent.KEYCODE_BACK )   {

            //This is made to prevent going back to the previous activities such as:
            // adding, editing , or interacting with elements.
            Intent intent = new Intent(getApplicationContext(),homepage.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(intent);

        }
        return true;
    }

//    void readyPendingTutorial(){
//
//        Button next;
//        TabLayout StepTabLayout;
//        TextView stepText, appTitle;
//        ImageView stepImage;
//
//        final Dialog dialog = new Dialog(this);
//
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.pending_instructions);
//        dialog.setCancelable(false);
//
//        next = dialog.findViewById(R.id.next_button);
//        StepTabLayout = dialog.findViewById(R.id.tutorialTab);
//        stepImage  = dialog.findViewById(R.id.stepImage);
//        stepText = dialog.findViewById(R.id.stepBox);
//
//        StepTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                switch (tab.getPosition()) {
//                    case 0:
//                        stepImage.setImageResource(R.drawable.pendingpic1);
//                        stepText.setText("This is where you can view your pending requests.");
//                        break;
//
//                    case 1:
//                        stepImage.setImageResource(R.drawable.pendingpic2);
//                        stepText.setText("By clicking this button, this allows you to create a new request!");
//                        break;
//
//
//                    default:
//                        stepImage.setImageResource(R.drawable.pendingpic1);
//                        stepText.setText("This is where you can view your pending requests.");
//                }
//            }
//
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {}
//
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {}
//        });
//
//        for (int i = 0; i < StepTabLayout.getTabCount(); i++) {
//            TextView tabTextView = (TextView) LayoutInflater.from(this).inflate(R.layout.bullet_empty_tab, null);
//            tabTextView.setText("");
//            StepTabLayout.getTabAt(i).setCustomView(tabTextView);
//        }
//
//
//        next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int tab = StepTabLayout.getSelectedTabPosition();
//                System.out.println("Selected tab: " + tab + " and tab count:" + StepTabLayout.getTabCount()  );
//                if (StepTabLayout.getTabCount() > tab+1){
//                    TabLayout.Tab selectTab = StepTabLayout.getTabAt(tab + 1);
//                    selectTab.select();
//                } else {
//
//                    List<String> getTutorialsSeen = new ArrayList<>();
//
//                    if (currentAccount.getTutorialsSeen() != null){
//
//                            currentAccount.getTutorialsSeen().add("Pending");
//                            updateTutorialsSeen(currentAccount.getTutorialsSeen());
//
//                    } else {
//
//                            getTutorialsSeen.add("Pending");
//                            updateTutorialsSeen(getTutorialsSeen);
//
//                    }
//
//                    dialog.dismiss();
//
//
//                }
//
//            }
//        });
//
//
//
//        dialog.show();
//        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
//
//
//    }

//    void readyApprovedTutorial(){
//
//        Button next;
//        final Dialog dialog = new Dialog(this);
//
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.approved_instructions);
//        dialog.setCancelable(false);
//
//        next = dialog.findViewById(R.id.next_button);
//
//        next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                    List<String> getTutorialsSeen = new ArrayList<>();
//
//                    if (currentAccount.getTutorialsSeen() != null){
//
//                        currentAccount.getTutorialsSeen().add("Ready");
//                        updateTutorialsSeen(currentAccount.getTutorialsSeen());
//
//                    } else {
//
//                        getTutorialsSeen.add("Ready");
//                        updateTutorialsSeen(getTutorialsSeen);
//
//                    }
//
//                    dialog.dismiss();
//
//            }});
//
//
//
//        dialog.show();
//        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
//
//
//    }

//    void readyRejectedTutorial(){
//
//        Button next;
//        final Dialog dialog = new Dialog(this);
//
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.rejected_instructions);
//        dialog.setCancelable(false);
//
//        next = dialog.findViewById(R.id.next_button);
//
//        next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                List<String> getTutorialsSeen = new ArrayList<>();
//
//                if (currentAccount.getTutorialsSeen() != null){
//
//                    currentAccount.getTutorialsSeen().add("Rejected");
//                    updateTutorialsSeen(currentAccount.getTutorialsSeen());
//
//                } else {
//
//                    getTutorialsSeen.add("Rejected");
//                    updateTutorialsSeen(getTutorialsSeen);
//
//                }
//
//                dialog.dismiss();
//
//            }});
//
//
//
//        dialog.show();
//        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
//
//
//    }
//
//    void readyCollectedTutorial(){
//
//        Button next;
//        final Dialog dialog = new Dialog(this);
//
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.collected_instructions);
//        dialog.setCancelable(false);
//
//        next = dialog.findViewById(R.id.next_button);
//
//        next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                List<String> getTutorialsSeen = new ArrayList<>();
//
//                if (currentAccount.getTutorialsSeen() != null){
//
//                    currentAccount.getTutorialsSeen().add("Collected");
//                    updateTutorialsSeen(currentAccount.getTutorialsSeen());
//
//                } else {
//
//                    getTutorialsSeen.add("Collected");
//                    updateTutorialsSeen(getTutorialsSeen);
//
//                }
//
//                dialog.dismiss();
//
//            }});
//
//
//
//        dialog.show();
//        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
//
//
//    }
//




    private void updateTutorialsSeen(List<String> tutorials){
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("Accounts/"+ currentAccount.getUUID() +"/tutorialsSeen",  tutorials);
        Utility.updateFirebaseData(updateMap, collection_list_page.this, null, null );
    }


    @Override
    protected void onPause() {
        super.onPause();
        limitedlist.clear();
        collectionList.clear();
        // Close database reference event listeners here
        if (requestListener != null) {
            requestDatabaseReference.removeEventListener(requestListener);
        }
    }


}