//package com.example.e_barangayclient.signup_pages.fragments;
//
//import android.app.Activity;
//import android.app.ProgressDialog;
//import android.content.Context;
//import android.content.Intent;
//import android.net.Uri;
//import android.os.Bundle;
//import android.text.Editable;
//import android.text.TextWatcher;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.fragment.app.Fragment;
//import androidx.viewpager2.widget.ViewPager2;
//
//import com.example.e_barangayclient.R;
//import com.example.e_barangayclient.Utility;
//import com.example.e_barangayclient.data_models.AccountModel;
//import com.example.e_barangayclient.data_models.registrationsRecord;
//import com.example.e_barangayclient.signup_pages.signup_base_page;
//import com.example.e_barangayclient.signup_pages.signup_complete;
//import com.google.android.gms.tasks.OnCompleteListener;
//import com.google.android.gms.tasks.OnFailureListener;
//import com.google.android.gms.tasks.OnSuccessListener;
//import com.google.android.gms.tasks.Task;
//import com.google.android.material.tabs.TabLayout;
//import com.google.firebase.auth.AuthResult;
//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//import com.google.firebase.storage.FirebaseStorage;
//import com.google.firebase.storage.StorageReference;
//import com.google.firebase.storage.UploadTask;
//
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Locale;
//import java.util.Map;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//public class Signup_stepFive_fragment_temp extends Fragment {
//
//    TabLayout tabLayoutFromBase = signup_base_page.tabLayout;
//    TabLayout.Tab tabText = tabLayoutFromBase.getTabAt(4);
//    private FirebaseAuth mAuth;
//
//    public Signup_stepFive_fragment_temp() {}
//    private static EditText Email_field, Password_field, Confirmation_field;
//    private String email_text, password_text, confirmation_text;
//    private Button nextButton;
//
//
//    private static boolean passed = true;
//    private static boolean okPass = true;
//    private ImageView imageSample;
//    private ViewPager2 viewPager2;
//   // This one is to be used when multiple upload is supported
//   // private ArrayList<Uri> images = new ArrayList<>();
//    private Uri image;
//    private DatabaseReference databaseReference, emailDatabaseReference;
//    private ValueEventListener emailEventListener;
//    private FirebaseDatabase firebaseDatabase;
//    private StorageReference storageReferenceA, storageReferenceB;
//    View view;
//
//
//
//
//
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        view = inflater.inflate(R.layout.fragment_signup_step_five, container, false);
//
//        setUpComponents();
//        // Set onClickListener for the signupButton here
//
//        nextButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                checkFields();
//                verifySteps();
//                if (passed){
//                 findEmailMatch(email_text);
//                }
//
//                else {
//                    tabText.setText("5");
//                    signup_base_page.verifiedSteps[4] = false;
//                }
//
//
//                }
//
//
//
//
//        });
//
//        return view;
//    }
//
//
//
//
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {}
//
//    @Override
//    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//
//    }
//
//    void setUpComponents(){
//
//
//        mAuth = FirebaseAuth.getInstance();
//
//        // Initialize Buttons here
//        nextButton = view.findViewById(R.id.signup_next);
//
//        // Initialize the details to be uploaded into firebase
//        Email_field = view.findViewById(R.id.signup_email);
//        Password_field = view.findViewById(R.id.signup_password);
//        Confirmation_field = view.findViewById(R.id.signup_confirmPword);
//
//        setTextChangeListener(Email_field, email_text);
//        setTextChangeListener(Password_field, password_text);
//        setTextChangeListener(Confirmation_field, confirmation_text);
//    }
//    void checkFields(){
//
//
//        email_text = Email_field.getText().toString().trim();
//        password_text = Password_field.getText().toString().trim();
//        confirmation_text = Confirmation_field.getText().toString().trim();
//
//        HashMap <EditText, String> fields = new HashMap<>();
//        fields.put(Email_field, email_text);
//        fields.put(Password_field, password_text);
//        fields.put(Confirmation_field, confirmation_text);
//
//        for (Map.Entry<EditText, String> entry : fields.entrySet()){
//
//            if (entry.getValue().isEmpty()){
//                entry.getKey().setError("Do not leave empty fields.");
//                passed = false;
//                Utility.rejectRed(entry.getKey(), getContext(), getActivity());
//            } else {
//                Utility.confirmGreen(entry.getKey(), getContext(), getActivity());
//            }
//        }
//
//        if (!validEmail(email_text)){
//            Email_field.setError("Enter a valid email!");
//            passed = false;
//            Utility.rejectRed(Email_field, getContext(), getActivity());
//        }
//
//
//        validatePassword(password_text, confirmation_text, getContext(), getActivity());
//
//
//    }
//    void verifySteps(){
//        int i = 0;
//        for (boolean step : signup_base_page.verifiedSteps) {
//            i++;
//            if (!step){
//                passed = false;
//                tabText.setText("5");
//                Utility.nextPage(tabLayoutFromBase, i-2);
//                System.out.println("Switched to: " +  (i-1));
//                return;
//            }
//        }
//
//        if (passed){
//            signup_base_page.verifiedSteps[4] = true;
//        } else {
//            signup_base_page.verifiedSteps[4] = false;
//        }
//
//    }
//    void setTextChangeListener(EditText field, String value){
//
//        field.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}
//            @Override
//            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}
//            @Override
//            public void afterTextChanged(Editable editable) {
//                // Called to notify you that somewhere within the text, characters have been added or removed.
//                // This is where you can perform your action after the text has changed.
//                String newText = editable.toString();
//                // Add your logic here to handle the changed text
//                if (!newText.equals(value)) {
//                    Utility.resetColor(field, getContext());
//                    tabText.setText("5");
//                    signup_base_page.verifiedSteps[4] = false;
//
//                }
//            }
//        });
//
//
//    }
//
//
//    private static boolean validEmail(String input) {
//        final Pattern VALID_EMAIL_ADDRESS_REGEX =
//                Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
//        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(input);
//        return matcher.matches();
//    }
//
//    private static void validatePassword( String input, String confirm, Context context, Activity activity) {
//            // Regular expression to check if the string contains numbers
//
//        String upper = "[A-Z]";
//        String lower = "[a-z]";
//        String numbers = "[0-9]";
//        String specialChar = "[^a-zA-Z\\s0-9]";
//
//
//        if (!input.matches(".*" + upper + ".*")) {
//            passed = false;
//            Utility.rejectRed(Password_field, context, activity);
//            Utility.rejectRed(Confirmation_field, context, activity);
//            Password_field.setError("Passwords need to contain an UPPERCASE letter.");
//        } else if (!input.matches(".*" + lower + ".*")) {
//            passed = false;
//            Utility.rejectRed(Password_field, context, activity);
//            Utility.rejectRed(Confirmation_field, context, activity);
//            Password_field.setError("Passwords need to contain a lowercase letter.");
//        } else if (!input.matches(".*" + numbers + ".*")) {
//            passed = false;
//            Utility.rejectRed(Password_field, context, activity);
//            Utility.rejectRed(Confirmation_field, context, activity);
//            Password_field.setError("Passwords need to contain a number.");
//        } else if (!input.matches(".*" + specialChar + ".*")) {
//            passed = false;
//            Utility.rejectRed(Password_field, context, activity);
//            Utility.rejectRed(Confirmation_field, context, activity);
//            Password_field.setError("Passwords need to contain a special character (e.g *, &, /, $, %).");
//        } else if (input.length() < 8) {
//            passed = false;
//            Utility.rejectRed(Password_field, context, activity);
//            Utility.rejectRed(Confirmation_field, context, activity);
//            Password_field.setError("Passwords should be at least 8 characters long.");
//        } else if (!input.equals(confirm)) {
//            Confirmation_field.setError("Passwords must match!");
//            passed = false;
//            Utility.rejectRed(Confirmation_field, context, activity);
//        } else if (confirm.isEmpty()) {
//            Confirmation_field.setError("Don't leave empty fields!");
//            passed = false;
//            Utility.rejectRed(Confirmation_field, context, activity);
//        } else {
//            passed = true;
//            signup_base_page.verifiedSteps[4] = true;
//            Utility.confirmGreen(Confirmation_field, context, activity);
//        }
//    }
//
//    void findEmailMatch(String email){
//
//
//        ProgressDialog progressDialog = new ProgressDialog(getContext());
//        progressDialog.setMessage("Loading...");
//        progressDialog.setCancelable(false); // prevent user from dismissing dialog
//        progressDialog.show();
//
//        emailDatabaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
//        emailEventListener = emailDatabaseReference.addValueEventListener(new ValueEventListener() {
//            boolean passed = true;
//
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                progressDialog.dismiss();
//                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
//                    if (snapshot.exists()){
//
//                        AccountModel account = itemSnapshot.getValue(AccountModel.class);
//
//                        //Check if there are no duplicate full names on the database first.
//                        if (account.getEmail().equals(email) && !account.getStatus().equals("Rejected") ){
//                            passed = false;
//                        }}}
//
//                if (passed){
//
//                    tabText.setText("\u2714");
//                    signup_base_page.enterEmail = email_text;
//                    signup_base_page.fragPassword = password_text;
//
//                    emailDatabaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
//                    signup_base_page.registerID = emailDatabaseReference.push().getKey();
//                    uploadImage();
//
//
//                } else {
//                    Utility.rejectRed(Email_field, getContext(), getActivity());
//                    Email_field.setError("This email has already been used in another account.");
//                }
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//
//    }
//
//
//
//    public void uploadImage(){
//        emailDatabaseReference.removeEventListener(emailEventListener);
//
//        storageReferenceA = FirebaseStorage.getInstance().getReference();
//        storageReferenceB = FirebaseStorage.getInstance().getReference();
//
//        ProgressDialog progressDialog = new ProgressDialog(getContext());
//        progressDialog.setMessage("Uploading ID Selfie...");
//        progressDialog.setCancelable(false); // prevent user from dismissing dialog
//        progressDialog.show();
//
//
//        storageReferenceA = storageReferenceA.child("images/registrations/" + signup_base_page.registerID + "/selfiePic") ;
//        storageReferenceA.putFile(signup_base_page.selfiePic).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
//
//
//
//            @Override
//            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
//                Toast.makeText(getActivity().getApplicationContext(), "Selfie Photo Upload success!", Toast.LENGTH_SHORT).show();
//
//                progressDialog.dismiss();
//                progressDialog.setMessage("Uploading ID Picture...");
//                progressDialog.show();
//                storageReferenceB = storageReferenceB.child("images/registrations/" + signup_base_page.registerID + "/docPic") ;
//                storageReferenceB.putFile(signup_base_page.docPic).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
//                    @Override
//                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
//                        Toast.makeText(getActivity().getApplicationContext(), "Document Photo Upload success!", Toast.LENGTH_SHORT).show();
//
//                        progressDialog.dismiss();
//                        uploadData();
//
//                    }
//                }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//                        Toast.makeText(getActivity().getApplicationContext(), "Document Photo Upload FAILURE!", Toast.LENGTH_SHORT).show();
//                        tabText.setText("5");
//                        signup_base_page.verifiedSteps[4] = false;
//                    }
//                });
//
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(getActivity().getApplicationContext(), "Selfie Photo Upload FAILURE!", Toast.LENGTH_SHORT).show();
//                tabText.setText("5");
//                signup_base_page.verifiedSteps[4] = false;
//            }
//        });
//
//
//
//        }
//
//    public void uploadData(){
//
//        Date c = Calendar.getInstance().getTime();
//        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
//        String formattedDate = df.format(c);
//        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
//        registrationsRecord regDeets = new registrationsRecord(signup_base_page.enterIDtype, formattedDate,null,null,null);
//
//        ProgressDialog progressDialog = new ProgressDialog(getContext());
//        progressDialog.setMessage("Creating account...");
//        progressDialog.setCancelable(false); // prevent user from dismissing dialog
//
//        progressDialog.show();
//        signup_base_page.accountEntry = new AccountModel( signup_base_page.registerID,
//                                                 "Pending",
//                                                        signup_base_page.enterName,
//                                                        signup_base_page.enterbirhtdate,
//                                                        signup_base_page.enterEmail,
//                                                        signup_base_page.fragPassword,
//                                                        regDeets,
//                                                        signup_base_page.Address,
//                                                        null, false,
//                                                        signup_base_page.enterToken,
//                                                        null);
//        databaseReference.child(signup_base_page.registerID).setValue(signup_base_page.accountEntry).addOnSuccessListener(new OnSuccessListener<Void>() {
//
//
//
//            @Override
//            public void onSuccess(Void unused) {
//                Toast.makeText(getActivity().getApplicationContext(), "Data Entry success!", Toast.LENGTH_SHORT).show();
//
//                mAuth.createUserWithEmailAndPassword(signup_base_page.enterEmail, signup_base_page.fragPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//
//                        progressDialog.dismiss();
//                        signup_complete.email = email_text;
//                        signup_complete.password = password_text;
//                        Intent intent = new Intent(getContext(), signup_complete.class);
//                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//                        startActivity(intent);
//
//                    }
//                });
//
//
//
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(getActivity().getApplicationContext(), "Data Entry unsuccessful!", Toast.LENGTH_SHORT).show();
//            }
//        });}
//
//
//
//
//
//}
