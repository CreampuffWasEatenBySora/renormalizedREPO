package com.example.e_barangayclient.data_models_temp;

//Basically, parang form to. Parang questionnaire.

public class registrationsRecord {


    private String idtype;
    private String dateRegistered;
    private String dateResponded;
    private String confirmer;
    private String remarks;

    public String getIdtype() { return idtype; }

    public String getDateRegistered() { return dateRegistered; }
    public String getDateResponded() { return dateResponded; }
    public String getConfirmer() { return confirmer; }
    public String getRemarks() { return remarks; }


    public registrationsRecord(String idtype,
                               String DateRegistered,
                               String DateResponded,
                               String Confirmer,
                               String Remarks){

        this.idtype = idtype;
        this.dateRegistered = DateRegistered;
        this.dateResponded = DateResponded;
        this.confirmer = Confirmer;
        this.remarks = Remarks;
    }

    public registrationsRecord(){

    }

}


