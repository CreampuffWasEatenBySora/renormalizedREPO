package com.example.e_barangayclient;

import static android.content.Intent.getIntent;

import static com.example.e_barangayclient.Utility.APILINK;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_barangayclient.data_models.AccountModel;
import com.example.e_barangayclient.signup_pages.signup_base_page;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public static FirebaseAuth mAuth;
    EditText email_field, password_field;
    Button loginButton;
    TextView singupMessage;
    String email, password;
    List<AccountModel> dataClassList;
    DatabaseReference databaseReference;
    ValueEventListener eventListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginpages);

        setUpComponents();



        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                if checking fields doesn't find an error, then proceed to login.
                if (checkFields()){
                    SQLLogin();
                }


            }
        });

        singupMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, signup_base_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);

            }
        });


        Bundle bundle = getIntent().getExtras();
        if (bundle != null ){
            email_field.setText(bundle.getString("new_account_email"));
            password_field.setText(bundle.getString("new_account_password"));
        }


    }


    void setUpComponents(){

        email_field = findViewById(R.id.login_emailField);
        password_field = findViewById(R.id.login_passwordField);
        loginButton = findViewById(R.id.login_button);
        singupMessage = findViewById(R.id.login_signup_link);




    }


    boolean checkFields(){

        boolean passed = true;
        email = email_field.getText().toString();
        password = password_field.getText().toString();

        HashMap<EditText, String> fields = new HashMap<>();
        fields.put(email_field, email);
        fields.put(password_field, password);

        //Checking for empty fields.
        for (Map.Entry<EditText, String> entry : fields.entrySet()){

            if (entry.getValue().isEmpty()){
                entry.getKey().setError("Do not leave empty fields.");
                passed = false;
                Utility.rejectRed(entry.getKey(), getApplicationContext(), MainActivity.this);
            } else {
                Utility.confirmGreen(entry.getKey(), getApplicationContext(), MainActivity.this);
            }
        }

        return passed;

    }

//    void checkDatabase(){
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.setMessage("Loading...");
//        progressDialog.setCancelable(false); // prevent user from dismissing dialog
//        progressDialog.show();
//
//        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
//        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
//            boolean passed = false;
//
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                progressDialog.dismiss();
//                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
//                    if (snapshot.exists()){
//
//                        AccountModel account = itemSnapshot.getValue(AccountModel.class);
//
//                        if (account.getEmail().equals(email) && account.getPassword().equals(password) && !account.isAdmin() ){
//
//                            homepage.currentAccount = account;
//                            passed = true;
//
//                        }}}
//
//                if (passed){
//                    login();
//                } else {
//
//                    Utility.rejectRed(email_field, MainActivity.this, MainActivity.this);
//                    Utility.rejectRed(password_field, MainActivity.this, MainActivity.this);
//                    Toast.makeText(MainActivity.this, "Incorrect email or password. ", Toast.LENGTH_SHORT).show();
//                }
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//
//
//    }

    public void SQLLogin(){

        JSONObject postData = new JSONObject();

        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        String url = APILINK+"/login";

        JSONObject newAccountLoginObject = new JSONObject();
        try {


//            newAccountLoginObject.put("email", email_field.getText().toString());
//            newAccountLoginObject.put("password",  password_field.getText().toString());
//            System.out.println(email + password);


             newAccountLoginObject.put("email", email);
             newAccountLoginObject.put("password",  password);


        } catch (Exception e ){
            e.printStackTrace();
        }



        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");

                            if ("success".equals(status)) {
                                JSONObject userdata = new JSONObject(jsonResponse.getString("userdata")) ;

                                AccountModel account = new AccountModel(
                                        userdata.getString("UUID"),
                                        userdata.getString("Status"),
                                        userdata.getString("FullName"),
                                        userdata.getString("Birthday"),
                                        userdata.getString("access_token"),
                                        userdata.getString("Registration_id"),
                                        userdata.getString("Address_id"),
                                        userdata.getString("Email")
                                        );

                                homepage.currentAccount = account;

                                login();

                            } else {
                                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return newAccountLoginObject.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(stringRequest);

    }

    void login(){

        Intent intent = new Intent(MainActivity.this, homepage.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {

        // replaces the default 'Back' button actions
        // Aside from this button, there's no other way to come out of this activity.
        if(keyCode==KeyEvent.KEYCODE_BACK )   {

            //This is made to prevent going back to the previous activities such as:
            // adding, editing , or interacting with elements.
            finishAffinity();
        }
        return true;
    }

//    @Override
//    protected void onDestroy() {
//
//        if (databaseReference != null){
//            databaseReference.removeEventListener(eventListener);
//
//        }
//        super.onDestroy();
//    }
}



