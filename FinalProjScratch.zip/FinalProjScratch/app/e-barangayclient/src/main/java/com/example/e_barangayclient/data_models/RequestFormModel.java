package com.example.e_barangayclient.data_models;

//Basically, parang form to. Parang questionnaire.

import java.util.HashMap;

public class RequestFormModel {

    private String requestID;
    private String requestCode;
    private String collectSched;
    private String collectDate;
    private String collectId;
    private String collectStatus;

    private String dateRequested;
    private String dateResponded;

    private String status;
    private String officerName;
    private String remarks;

    private HashMap<String, documentRequirementModel> requirements;
    private HashMap<String, RequestedDocumentModel> requestedDocuments;

    public HashMap<String, documentRequirementModel> getRequirements() {return requirements; }

    public String getCollectSched() {
        return collectSched;
    }

    public String getRequestID() { return requestID; }
    public String getCollectId() { return collectId; }
    public String getCollectStatus() { return collectStatus; }
    public String getCollectDate() { return collectDate; }
    public String getRequestCode() { return requestCode; }
    public HashMap<String, RequestedDocumentModel>  getRequestedDocument() { return requestedDocuments; }
    public String getDateRequested() { return dateRequested; }
    public String getDateResponded() { return dateResponded; }


    public String getStatus() { return status; }
    public String getRemarks() { return remarks; }
    public String getOfficerName() { return officerName; }

    public void setStatus(String status){

        this.status = status;
    }




    public RequestFormModel(String requestID,
                            String collectId,
                            String collectStatus,
                            String requestCode,
                            String collectSched,
                            String collectDate,
                            HashMap<String, RequestedDocumentModel> requestedDocuments,
                            String dateRequested,
                            String dateRelease,
                            String confirmerName,
                            String status,
                            String remarks){

        this.requestID = requestID;
        this.collectStatus = collectStatus;
        this.collectId = collectId;
        this.requestCode = requestCode;
        this.collectDate = collectDate;
        this.collectSched = collectSched;
        this.requestedDocuments = requestedDocuments;
        this.dateRequested = dateRequested;
        this.dateResponded = dateRelease;
        this.officerName = confirmerName;
        this.status = status;
        this.remarks = remarks;


    }

    public RequestFormModel(){

    }

}


