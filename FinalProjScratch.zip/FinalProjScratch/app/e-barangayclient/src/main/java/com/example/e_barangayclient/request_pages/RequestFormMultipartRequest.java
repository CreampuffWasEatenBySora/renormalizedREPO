package com.example.e_barangayclient.request_pages;


import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.HttpHeaderParser;
import com.example.e_barangayclient.data_models.imageData;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class RequestFormMultipartRequest extends Request<String> {

    private final Response.Listener<String> mListener;
    private final List<imageData> mImageUris;
    private final JSONObject mAddedData;
    private final String mMimeType = "image/jpeg";

    private final Context mContext ;
    public RequestFormMultipartRequest(String url, Response.Listener<String> listener, Response.ErrorListener errorListener, List<imageData> imageUris, Context context,  JSONObject AddedData) {
        super(Method.POST, url, errorListener);
        mListener = listener;
        mImageUris = imageUris;
        mContext = context;
        mAddedData = AddedData;
    }

    @Override
    public String getBodyContentType() {
        return "multipart/form-data;boundary=" + "*****";
    }

    @Override
    public byte[] getBody() throws AuthFailureError {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(bos);
        String boundary = "*****";

        try {

            try {

                for (Iterator<String> it = mAddedData.keys(); it.hasNext(); ) {
                    String key = it.next();
                    dos.writeBytes("--" + boundary + "\r\n");
                    dos.writeBytes("Content-Disposition: form-data; name=\"" + key + "\"\r\n\r\n");
                    dos.writeBytes(mAddedData.getString(key) + "\r\n");
                }

            } catch (Exception e){
                e.printStackTrace();
            }




            String today =  String.valueOf(new Date().getTime());

            // Add images to multipart form data
            for (int i = 0; i < mImageUris.size(); i++) {
                Uri imageUri = mImageUris.get(i).getImageUri();
                String imageName =  mImageUris.get(i).getId() + ".jpg";

                dos.writeBytes("--*****\r\n");
                dos.writeBytes("Content-Disposition: form-data; name=\"file" + i + "\";filename=\"" + imageName + "\"\r\n");
                dos.writeBytes("Content-Type: " + mMimeType + "\r\n\r\n");

                byte[] data = convertUriToBytes(mContext, imageUri);
                dos.write(data);

                dos.writeBytes("\r\n");
            }

            dos.writeBytes("--*****--\r\n");

            return bos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private byte[] convertUriToBytes(Context context, Uri uri) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ContentResolver contentResolver =  context.getContentResolver();
        byte[] buffer = new byte[1024];
        int bytesRead;
        try {
            InputStream inputStream = contentResolver.openInputStream(uri);
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                byteArrayOutputStream.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return byteArrayOutputStream.toByteArray();
    }

    @Override
    protected Response<String> parseNetworkResponse(NetworkResponse response) {
        try {
            String jsonString = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
            return Response.success(jsonString, HttpHeaderParser.parseCacheHeaders(response));
        } catch (UnsupportedEncodingException e) {
            return Response.error(new ParseError(e));
        }
    }

    @Override
    protected void deliverResponse(String response) {
        mListener.onResponse(response);
    }


}
