package com.example.e_barangayclient;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.github.chrisbanes.photoview.PhotoView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;

public class account_image extends AppCompatActivity {
    StorageReference storageReference;
    String filepath;
    PhotoView docImg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_image);

        docImg = findViewById(R.id.docImage);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null ){
            filepath = bundle.getString("Path");
        }
        storageReference = FirebaseStorage.getInstance().getReference(filepath);
        System.out.println(storageReference.getName());
        System.out.println(filepath);

        try {
            File localfile = File.createTempFile("tempfile", ".jpg");
            storageReference.getFile(localfile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                    Bitmap bitmap = BitmapFactory.decodeFile(localfile.getAbsolutePath());
                    System.out.println(localfile.getAbsolutePath());

                    docImg.setImageBitmap(bitmap);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    System.out.println(e.toString());
                }
            });

        } catch (IndexOutOfBoundsException | IOException e){
            e.printStackTrace();
        }
    }
}