package com.example.e_barangayclient.request_pages;

import android.content.Context;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;

import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.AccountModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.homepage;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class file_utilities {


    /**
     * Checks if a file exists in the external cache directory.
     *
     * @param context The context.
     * @param fileName The name of the file to check.
     * @return The file if it exists, null otherwise.
     */
    public static Uri getFromExternalCache(Context context, String fileName){

        File externalCacheDir = context.getExternalCacheDir();
        System.out.println(externalCacheDir);
        if (externalCacheDir != null) {
            System.out.println("OK");
            File file = new File(externalCacheDir, fileName);
            if (file.exists()) {
                System.out.println("OK!");
                return FileProvider.getUriForFile(context, "com.example.e_barangayclient.fileProvider", file);
            }
        }
        return null;
    }

    }


