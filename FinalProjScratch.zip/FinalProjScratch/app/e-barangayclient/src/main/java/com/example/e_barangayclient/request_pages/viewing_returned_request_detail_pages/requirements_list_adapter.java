package com.example.e_barangayclient.request_pages.viewing_returned_request_detail_pages;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayclient.R;
import com.example.e_barangayclient.data_models.documentRequirementModel;

import java.util.List;

public class requirements_list_adapter extends RecyclerView.Adapter<requirements_viewholder> {


    private Context context;
    private  Activity activity;
    private List<documentRequirementModel> requirements;
            public  requirements_list_adapter(Context context,  List<documentRequirementModel> requirements, com.example.e_barangayclient.request_pages.viewing_returned_request_detail_pages.cameraActionListener cameraActionListener ) {
                this.context = context;
                this.requirements = requirements;
            }

            @NonNull
            @Override
            public requirements_viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_card_requirement, parent, false);

                return new requirements_viewholder(view);

            }

            @Override
            public void onBindViewHolder(@NonNull requirements_viewholder holder, int position) {



                documentRequirementModel requirement = requirements.get(position);
                holder.requirementName.setText(requirement.getRequirement_name());
                Drawable noImage = ContextCompat.getDrawable(context, R.drawable.ic_action_take_photo);
                Drawable hasImage = ContextCompat.getDrawable(context, R.drawable.ic_action_confirm_edit);


                if (requirement.getRequirement_image() != null){
                    holder.takePhoto.setImageDrawable(hasImage);
                } else {
                    holder.takePhoto.setImageDrawable(noImage);
                }



                holder.takePhoto.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Button takePhoto, confirm;
                        TextView requirementName, requirementDesc , takePhotoText;

                         ImageView  requirementImage  ;

                        final Dialog dialog = new Dialog(context);


                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setContentView(R.layout.popup_requested_document_requirement);
                        dialog.setCancelable(false);


                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                        takePhoto = dialog.findViewById(R.id.requirement_popup_take_requirement);
                        confirm = dialog.findViewById(R.id.request_popup_confirm);
                        requirementName = dialog.findViewById(R.id.popup_requirement_name);
                        requirementDesc = dialog.findViewById(R.id.popup_requirement_desc);
                        requirementName.setText(requirement.getRequirement_name());
                        requirementDesc.setText(requirement.getRequirement_description());
                        requirementImage =  dialog.findViewById(R.id.requirement_pic);

                        if (requirement.getRequirement_image() != null){

                            requirementImage.setImageURI(requirement.getRequirement_image().getImageUri());
                        }

                        takePhoto.setVisibility(View.GONE);

                        confirm.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });


                        dialog.show();
                        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

                    }
                });

            }

            @Override
            public int getItemCount() {
                return requirements.size();
            }








}


class requirements_viewholder extends RecyclerView.ViewHolder{

    TextView requirementName, requested_document_status;
    ImageButton takePhoto;
    CardView requestCard;
    Uri imageUri;


    public  requirements_viewholder(@NonNull View itemView){
        super(itemView);


        requestCard = itemView.findViewById(R.id.recycler_card_requirement);
        requirementName = itemView.findViewById(R.id.requirement_Name);
        takePhoto = itemView.findViewById(R.id.requirement_take_photo);

    }



}
