package com.example.e_barangayclient.data_models_temp;

//Basically, parang form to. Parang questionnaire.

public class RequestedDocumentModel {

    private String requestDocID;

    private String docName;
    private String purpose;
    private String status;
    private String remarks;


    public String getRequestDocID() { return requestDocID; }
    public String getDocName() { return docName; }

    public String getPurpose() { return purpose; }
    public String getStatus() { return status; }
    public String getRemarks() { return remarks; }

    public void setPurpose(String purpose){
        this.purpose = purpose;
    }



    public RequestedDocumentModel(String requestDocID,
                                  String documentName,
                                  String purpose,
                                  String status,
                                  String remarks){

        this.requestDocID = requestDocID;
        this.docName = documentName;
        this.purpose = purpose;
        this.status = status;
        this.remarks = remarks;


    }

    public RequestedDocumentModel(){

    }

}


