package com.example.e_barangayclient.data_models;

//Basically, parang form to. Parang questionnaire.

import java.util.HashMap;

public class AvailableDocumentModel {

    private String documentID;

    private String docName;
    private String documentDescription;

    private String dateModified;
    private boolean available;

    private HashMap<String, documentRequirementModel> requirements;

    public String getDocumentID() { return documentID; }
    public String getDocName() { return docName; }

    public String getDateModified() {return dateModified; }
    public HashMap<String, documentRequirementModel> getRequirements() {return requirements; }



    public String getDocumentDescription() { return documentDescription; }
    public boolean isAvailable() { return available; }


    public void setDocumentID(String documentID) {
        this.documentID = documentID;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    public void setDocumentDescription(String documentDescription) {
        this.documentDescription = documentDescription;
    }

    public void setRequirements(HashMap<String, documentRequirementModel> requirements) {
        this.requirements = requirements;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public AvailableDocumentModel(String documentID,
                                  String documentName,
                                  String documentDescription,
                                  String docDate,
                                  HashMap<String, documentRequirementModel>  requirements,
                                  boolean isAvailable){

        this.documentID = documentID;
        this.docName = documentName;
        this.documentDescription = documentDescription;
        this.dateModified = docDate;
        this.requirements = requirements;
        this.available = isAvailable;


    }

    public AvailableDocumentModel(){

    }

}


