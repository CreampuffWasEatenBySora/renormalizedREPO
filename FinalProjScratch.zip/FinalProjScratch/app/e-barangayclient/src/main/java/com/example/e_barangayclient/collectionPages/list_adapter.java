package com.example.e_barangayclient.collectionPages;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayclient.R;
import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.collectionPages.collection_detail_pages.returned_collection_page;
import com.example.e_barangayclient.data_models.CollectFormModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class list_adapter extends RecyclerView.Adapter<RequestListViewHolder> {


    private Context context;
    private List<CollectFormModel> collectionList;

            public  list_adapter (Context context, List<CollectFormModel> collections) {
                this.context = context;
                this.collectionList = collections;
            }

            @NonNull
            @Override
            public RequestListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.request_recycler_card, parent, false);
                return new RequestListViewHolder(view);

            }

            @Override
            public void onBindViewHolder(@NonNull RequestListViewHolder holder, int position) {

                CollectFormModel collection = collectionList.get(position);
                ArrayList<String> docNames = new ArrayList<>();
                for (Map.Entry<String, RequestedDocumentModel> entry: collection.getRequest().getRequestedDocument().entrySet())
                {
                    docNames.add(entry.getValue().getDocName());
                }

                holder.request_ID.setText(collection.getRequest().getRequestCode());
                holder.requestee_name.setText("Request for " + docNames.get(0));

                if (collection.getStatus().equals("TBC")){
                    holder.request_dateNstatus.setText("Scheduled on: " + collection.getDateScheduled());
                } else if (collection.getStatus().equals("CAN")){
                    holder.request_dateNstatus.setText("Cancelled "  + Utility.getApproxDate(collection.getDateCollected()));
                } else {
                    holder.request_dateNstatus.setText("Collected "  + Utility.getApproxDate(collection.getDateCollected()));

                }
                holder.requestCard.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        utilities.collection = collection ;

                        Intent intent = new Intent(context, returned_collection_page.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);


                    }
                });



            }

            @Override
            public int getItemCount() {
                return collectionList.size();
            }
}

class RequestListViewHolder extends RecyclerView.ViewHolder{

    TextView requestee_name, request_dateNstatus, request_ID;
    LinearLayout editBox;
    CardView requestCard;


    public RequestListViewHolder(@NonNull View itemView){
        super(itemView);


        requestCard = itemView.findViewById(R.id.clientRequestCard);
        requestee_name = itemView.findViewById(R.id.clientRequestCard_Name);
        request_dateNstatus = itemView.findViewById(R.id.clientRequestCard_date);
        request_ID = itemView.findViewById(R.id.clientRequestCard_ID);


    }



}
