package com.example.e_barangayclient.signup_pages;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.e_barangayclient.signup_pages.fragments.Signup_stepFive_fragment;
import com.example.e_barangayclient.signup_pages.fragments.Signup_stepFour_fragment;
import com.example.e_barangayclient.signup_pages.fragments.Signup_stepOne_fragment;
import com.example.e_barangayclient.signup_pages.fragments.Signup_stepThree_fragment;
import com.example.e_barangayclient.signup_pages.fragments.Signup_stepTwo_fragment;

public class SignUpPagerAdapter extends FragmentStateAdapter {

    public SignUpPagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {

        Fragment frag = new Signup_stepOne_fragment();

        if (position == 0) {
            frag = new Signup_stepOne_fragment();

        } else if (position == 1){
            frag = new Signup_stepTwo_fragment();
        } else if (position == 2) {
            frag = new Signup_stepThree_fragment();
        } else if (position == 3) {
            frag = new Signup_stepFour_fragment();
        } else if (position == 4) {
            frag = new Signup_stepFive_fragment();
        }

        return frag;
    }

    @Override
    public int getItemCount() {
        return 5;
    }
}
