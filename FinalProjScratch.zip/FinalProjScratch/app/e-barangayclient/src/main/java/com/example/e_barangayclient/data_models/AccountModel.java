package com.example.e_barangayclient.data_models;

//Basically, parang form to. Parang questionnaire.

import java.util.List;

public class AccountModel {

    private String UUID;
    private String status;

    private String fullName;
    private String accessToken;
    private String birthday;
    private String email;
    private String registrationID;
    private String addressID;

    //   private List<String> tutorialsSeen;
    //   private registrationsRecord regDetails = new registrationsRecord();
    //   private address address = new address();
    //   private RequestFormModel Requests = new RequestFormModel();
    // private historyRecord history;


    public String getUUID() { return UUID; }
    public String getStatus() { return status; }
    public String getFullName() { return fullName; }
    public String getAccessToken() { return accessToken; }
    public String getBirthday() { return birthday; }
    public String getEmail() { return email; }

    public void setUUID(String UUID) {
        this.UUID = UUID;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setRegistration_id(String registrationID) {
        this.registrationID = registrationID;
    }

    public void setAddress_id(String addressID) {
        this.addressID = addressID;
    }

    // public List<String> getTutorialsSeen(){return tutorialsSeen;};
    // public registrationsRecord getRegDetails() { return regDetails; }
    // public address getAddress() { return address; }
    // public RequestFormModel getRequests() { return Requests; }

    // public historyRecord getHistory() { return history; }



    public AccountModel(String ID,
                        String status,
                        String fullName,
                        String birthdate,
                        String deviceToken,
                        String regID,
                        String addID,
                        String email
                        // registrationsRecord regDetails,
                        // address address,
                        // historyRecord history
                        ){

        this.UUID = ID;
        this.status = status;
        this.fullName = fullName;
        this.birthday = birthdate;
        this.accessToken = deviceToken;
        this.registrationID = regID;
        this.addressID = addID;
        this.email = email;

      //  this.regDetails = regDetails;
      //  this.address = address;
      //  this.Requests = requests;
      //   this.history = history;

    }

    public AccountModel(){

    }

}


