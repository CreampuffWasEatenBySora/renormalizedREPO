package com.example.e_barangayclient.signup_pages.fragments;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.example.e_barangayclient.R;
import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.imageData;
import com.example.e_barangayclient.signup_pages.documentImage;
import com.example.e_barangayclient.signup_pages.signup_base_page;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Signup_stepThree_fragment extends Fragment {

    private final static int CAMERA_PERMISSION_CODE = 1;

    ActivityResultLauncher<Uri> takePictureLauncher;

    Uri imageUri;

    Spinner spinner;

    TabLayout tabLayoutFromBase = signup_base_page.tabLayout;
    TabLayout.Tab tabText = tabLayoutFromBase.getTabAt(2);
    public Signup_stepThree_fragment() {}
    private Button retakeButton, nextButton;
    private ImageView photoSlot;
    private TextView takeselfietext;
    boolean photoTaken = false;
    // This one is to be used when multiple upload is supported
    // private ArrayList<Uri> images = new ArrayList<>();
    private Uri image;
    private DatabaseReference databaseReference;
    private FirebaseDatabase firebaseDatabase;
    private StorageReference storageReference;

    View view;
    final int[] spinnerIndex = {0};





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_signup_step_three, container, false);

        setUpComponents();




        // Set onClickListener for the signupButton here
        photoSlot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(photoTaken){
                    showImage();
                } else {
                    checkCameraPermission();
                }

            }

        });

        // Set onClickListener for the signupButton here
        retakeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tabText.setText("3");
                photoTaken = false;
                signup_base_page.verifiedSteps[2] = false;
                retakeButton.setVisibility(View.GONE);
                checkCameraPermission();

            }

        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (spinnerIndex[0] == 0){
                    Toast.makeText(getContext(), "Please choose a document type", Toast.LENGTH_SHORT).show();
                }
                else if (!photoTaken) {
                    tabText.setText("3");
                    photoTaken = false;
                    signup_base_page.verifiedSteps[2] = false;
                    Toast.makeText(getContext(), "Please take a close up photo of your valid ID.", Toast.LENGTH_SHORT).show();
                } else {
                    signup_base_page.enterIDtype  = spinner.getSelectedItem().toString();


                    signup_base_page.verifiedSteps[2] = true;
                    tabText.setText("\u2714");
                    Utility.nextPage(tabLayoutFromBase,2);
                }
            }
        });

        return view;
    }

    void showImage() {

        Intent intent = new Intent(getContext(), documentImage.class);
        documentImage.photoUri = imageUri;
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);

    }


    void setUpComponents(){
        // Initialize Buttons here
        spinner = view.findViewById(R.id.signup_spinner);
        List<String> documentTypes = new ArrayList<>(Arrays.asList("Choose Document Type", "Passport", "Driver's License", "ID Card"));
        Step_three_document_select_SpinnerAdapter adapter = new Step_three_document_select_SpinnerAdapter(requireContext(), documentTypes);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                //Change the selected item's text color
                spinnerIndex[0] = position;


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
            }
        });

        retakeButton = view.findViewById(R.id.signup_deletePhoto_Button);
        nextButton = view.findViewById(R.id.signup_next);
        photoSlot = view.findViewById(R.id.document_Pic);
        takeselfietext = view.findViewById(R.id.signuptext);
        imageUri = createUri();
        registerPictureLauncher();

        retakeButton.setVisibility(View.GONE);


    }

    private Uri createUri(){
        Context context = getContext().getApplicationContext();
        File imageFile = new File(context.getFilesDir(), "document_photo.jpg");
        return FileProvider.getUriForFile(
                context,
                "com.example.e_barangayclient.fileProvider",
                imageFile

        );

    }

    private void registerPictureLauncher(){
        takePictureLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicture(),
                new ActivityResultCallback<Boolean>() {
                    @Override
                    public void onActivityResult(Boolean result) {
                        try{
                            if (result){
                                signup_base_page.docData = new imageData(imageUri,"document");
                                photoSlot.setImageURI(null);
                                photoSlot.setImageURI(imageUri);
                                retakeButton.setText("Retake Photo");
                                photoTaken = true;
                                signup_base_page.docPic = imageUri;
                                retakeButton.setVisibility(View.VISIBLE);
                                takeselfietext.setVisibility(View.GONE);

                            }

                        } catch (Exception exception){
                            exception.printStackTrace();
                        }
                    }
                }
        );

    }


    private void checkCameraPermission(){
        Activity activity = (signup_base_page) getActivity();
        if (ActivityCompat.checkSelfPermission(activity,
                Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){

            ActivityCompat.requestPermissions(activity,
                    new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);


        } else {

            takePictureLauncher.launch(imageUri);
        }
    }

    public void onRequestPermissionResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults ){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                takePictureLauncher.launch(imageUri);
            } else {
                Toast.makeText(getContext(), "Camera Permission Denied, please allow permissions to take a picture", Toast.LENGTH_SHORT).show();
            }
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {}

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }}

