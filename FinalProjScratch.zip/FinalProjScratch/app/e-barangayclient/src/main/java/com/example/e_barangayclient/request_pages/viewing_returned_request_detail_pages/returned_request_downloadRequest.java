package com.example.e_barangayclient.request_pages.viewing_returned_request_detail_pages;

import android.content.Context;
import android.net.Uri;

import androidx.core.content.FileProvider;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

public class returned_request_downloadRequest  extends Request<byte[]> {

    private final Response.Listener<Uri> mListener;
    private final Map<String, String> mParams;
    private final File mFile;
    private final Context mContext;
    private final String mProviderAuthority;

    public returned_request_downloadRequest(int method, String url, Map<String, String> params, File file, Context context,
                                            String providerAuthority,  Response.Listener<Uri> listener,  Response.ErrorListener errorListener) {
        super(method, url, errorListener);
        this.mListener = listener;
        this.mParams = params;
        this.mFile = file;
        this.mContext = context;
        this.mProviderAuthority = providerAuthority;
    }

    @Override
    protected Map<String, String> getParams() {
        return mParams;
    }

    @Override
    protected Response<byte[]> parseNetworkResponse(NetworkResponse response) {
        try {
            if (mFile.exists()) {
                mFile.delete();
            }
            FileOutputStream fos = new FileOutputStream(mFile);
            fos.write(response.data);
            fos.close();
        } catch (IOException e) {
            return Response.error(new VolleyError(e));
        }
        return Response.success(response.data, HttpHeaderParser.parseCacheHeaders(response));
    }


    @Override
    protected void deliverResponse(byte[] response) {
        Uri fileUri = FileProvider.getUriForFile(mContext, mProviderAuthority, mFile);
        mListener.onResponse(fileUri);
    }



}
