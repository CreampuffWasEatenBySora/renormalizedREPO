package com.example.e_barangayclient.collectionPages.collection_detail_pages;

import com.example.e_barangayclient.data_models.documentRequirementModel;

public interface cameraActionListener {
    void onRequestCameraPermission( documentRequirementModel requirement );
}
