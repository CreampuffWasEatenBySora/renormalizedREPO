package com.example.e_barangayclient;

import static com.example.e_barangayclient.Utility.getFullName;

import android.Manifest;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.e_barangayclient.data_models.AccountModel;
// import com.example.e_barangayclient.request_pages.request_list_page;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class homepage_temp extends AppCompatActivity {

    public static AccountModel currentAccount = new AccountModel();

    ImageButton requestButton, documentsButton, accountsButton, logOutButton, detailsButton, information;

    ImageView status_icon;

    TextView greetingText, statusText , pendingTitle;
    LinearLayout userPanel, pendingMessage;


    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {


                    System.out.println("You can now receive notilkmpfications!");


                } else {
                    System.out.println("No notifications, that's alright!");

                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

       // setNewToken(currentAccount.getUUID(),currentAccount.getAccessToken(), homepage_temp.this);
        setGreeting();
        askNotificationPermission();
        setUpComponents();
        // checkforTutorials();

        requestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(getApplicationContext(), request_list_page.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
//                startActivity(intent);
            }
        });

        logOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FirebaseMessaging.getInstance().deleteToken().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }
                    }
                });
            }
        });

        detailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                account_details.account = currentAccount;
                Intent intent = new Intent(getApplicationContext(), account_details.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

//        information.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                readyHomepageTutorial();
//            }
//        });

    }

//    private void checkforTutorials() {
//        if (currentAccount.getTutorialsSeen() != null){
//
//            if (!currentAccount.getTutorialsSeen().contains("homepage")){
//                readyHomepageTutorial();
//
//            }
//    } else {
//            readyHomepageTutorial();
//        }
//
//    }



    void setUpComponents(){

        // accountsButton = findViewById(R.id.home_manageAccounts);
        //  documentsButton = findViewById(R.id.home_manageDocuments);
        information = findViewById(R.id.informationButton);
        requestButton = findViewById(R.id.home_manageRequests);
        logOutButton = findViewById(R.id.panel_exit);
        detailsButton = findViewById(R.id.panel_setting);
        userPanel = findViewById(R.id.homepage_userPanel);
        pendingMessage = findViewById(R.id.homepage_pending);
        status_icon = findViewById(R.id.homepage_status_icon);
        statusText = findViewById(R.id.homepage_status_message);
        pendingTitle =  findViewById(R.id.homepage_status_title);

//        if (currentAccount.getStatus().equals("Pending")){
//
//            userPanel.setVisibility(View.GONE);
//            pendingMessage.setVisibility(View.VISIBLE);
//
//        } else if (currentAccount.getStatus().equals("Rejected")) {
//            userPanel.setVisibility(View.GONE);
//            pendingMessage.setVisibility(View.VISIBLE);
//
//            status_icon.setImageResource(R.drawable.rejected_icon);
//        //    statusText.setText("Due to "+ currentAccount.getRegDetails().getRemarks() +" your account was rejected by "+ currentAccount.getRegDetails().getConfirmer() +". \n\nAfter fixing this issue, you can apply again.");
//            pendingTitle.setText("Rejected");
//
//        }

    }

    void setGreeting(){

        greetingText = findViewById(R.id.homepage_greeting);
        getFullName(currentAccount.getUUID(), new Utility.nameCallback() {
            @Override
            public void onFullNameReceived(String fullName) {
                // Use the first name here
                int firstNameFind = fullName.lastIndexOf('.') - 2 ;
                String firstName = fullName.substring(0, firstNameFind);
                greetingText.setText("Welcome, " + firstName + "!");

            }
        });

    }




    void sendNotification(String message, String recipient){

        // Username, message, current userID, and recipient token

        AccountModel currentUser = homepage_temp.currentAccount;

        try {
            JSONObject jsonObject = new JSONObject();
            JSONObject notifObject = new JSONObject();
            notifObject.put("title", "Testing notification");
            notifObject.put("body", message);

            JSONObject dataObject = new JSONObject();
            dataObject.put("userId", currentUser.getUUID());

            jsonObject.put("notification", notifObject);
            jsonObject.put("data", dataObject);
            jsonObject.put("to", currentUser.getAccessToken());

            System.out.println("sent to token: " + currentUser.getAccessToken());
            callApi(jsonObject);
        } catch (Exception e ){
            System.out.println("Error: " + e);
        }



    }

    void callApi(JSONObject jsonObject){
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        OkHttpClient client = new OkHttpClient();
        String url = "https://fcm.googleapis.com/fcm/send";
        RequestBody body = RequestBody.create(jsonObject.toString(), JSON);

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .header("Authorization", "Bearer AAAANw_N_io:APA91bEiwZMysEcbEyJhSdmvmOBeVPYQGfsu1JcPCpwykYbHKuurmKnP3vi-pj2UTIQ9YeyL5m8VX1WhkcQC4oe5GSp6mxOmyaA-QQAJ7wihhKS0XApwVEANub2ZyKZBmZGWmOWGi-TH")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {

            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {

            }
        });

    }
    private void askNotificationPermission() {
        // This is only necessary for API level >= 33 (TIRAMISU)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                    PackageManager.PERMISSION_GRANTED) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    // Create the NotificationChannel
                    CharSequence name = "Notification Channel Name";
                    String description = "Notification Channel Description";
                    int importance = NotificationManager.IMPORTANCE_DEFAULT;
                    NotificationChannel channel = new NotificationChannel("notifSample", name, importance);
                    channel.setDescription(description);

                    // Register the channel with the system
                    NotificationManager notificationManager = getSystemService(NotificationManager.class);
                    notificationManager.createNotificationChannel(channel);
                }

                System.out.println("You can now receive notifications!" );

            } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {

                System.out.println("Permission is needed" );


            } else {
                // Directly ask for the permission
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                System.out.println("You are now asked to enable receive notifications!" );

            }}}

//    void readyHomepageTutorial(){
//
//        Button next;
//        TabLayout StepTabLayout;
//        TextView stepText, appTitle;
//        ImageView stepImage;
//
//        final Dialog dialog = new Dialog(this);
//
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.popup_tutorial_welcome_document);
//        dialog.setCancelable(false);
//
//        next = dialog.findViewById(R.id.next_button);
//        StepTabLayout = dialog.findViewById(R.id.tutorialTab);
//        stepImage  = dialog.findViewById(R.id.stepImage);
//        stepText = dialog.findViewById(R.id.stepBox);
//        appTitle = dialog.findViewById(R.id.appTitle);
//
//        StepTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                switch (tab.getPosition()) {
//                    case 0:
//                        stepImage.setImageResource(R.drawable.logo_white_border);
//                        stepText.setText("Welcome to");
//                        appTitle.setText("Barangay E-Connect!");
//                        appTitle.setVisibility(View.VISIBLE);
//                        break;
//
//                    case 1:
//                        stepImage.setImageResource(R.drawable.welcome_icon1);
//                        stepText.setText("This app is designed to make Barangay transactions digital!");
//                        appTitle.setVisibility(View.GONE);
//                        break;
//
//                    case 2:
//                        stepImage.setImageResource(R.drawable.welcome_icon2);
//                        stepText.setText("And to Make acquiring documents more convenient and well-documented!");
//                        appTitle.setVisibility(View.GONE);
//                        break;
//
//                    case 3:
//                        stepImage.setImageResource(R.drawable.welcome_icon3);
//                        stepText.setText("Are you ready?");
//                        appTitle.setText("Click the button below to start!");
//                        appTitle.setVisibility(View.VISIBLE);
//
//                        break;
//
//                    default:
//                        stepImage.setImageResource(R.drawable.logo_white_border);
//                        stepText.setText("Welcome to");
//                        appTitle.setText("Barangay E-Connect!");
//                        appTitle.setVisibility(View.VISIBLE);
//                }
//            }
//
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {}
//
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {}
//        });
//
//        for (int i = 0; i < StepTabLayout.getTabCount(); i++) {
//            TextView tabTextView = (TextView) LayoutInflater.from(this).inflate(R.layout.bullet_empty_tab, null);
//            tabTextView.setText("");
//            StepTabLayout.getTabAt(i).setCustomView(tabTextView);
//        }
//
//
//        next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int tab = StepTabLayout.getSelectedTabPosition();
//                System.out.println("Selected tab: " + tab + " and tab count:" + StepTabLayout.getTabCount()  );
//                if (StepTabLayout.getTabCount() > tab+1){
//                    TabLayout.Tab selectTab = StepTabLayout.getTabAt(tab + 1);
//                    selectTab.select();
//                } else {
//
//                    if (currentAccount.getTutorialsSeen() != null){
//
//                        currentAccount.getTutorialsSeen().add("homepage");
//                        Map<String, Object> updateMap = new HashMap<>();
//                        updateMap.put("Accounts/"+ currentAccount.getUUID() +"/tutorialsSeen", currentAccount.getTutorialsSeen());
//                        Utility.updateFirebaseData(updateMap, homepage_temp.this , null, null);
//                        dialog.dismiss();
//
//                    } else {
//                       List<String> getTutorialsSeen = new ArrayList<>();
//                       getTutorialsSeen.add("homepage");
//                       Map<String, Object> updateMap = new HashMap<>();
//                       updateMap.put("Accounts/"+ currentAccount.getUUID() +"/tutorialsSeen",  getTutorialsSeen);
//                       Utility.updateFirebaseData(updateMap, homepage_temp.this, null, null);
//                       dialog.dismiss();
//                    }
//
//
//                }
//
//            }
//        });
//
//        dialog.show();
//        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
//
//    }
//
//    void setNewToken(String userId, String formerToken, Context context){
//
//        //Along with notification permission and settings, also manage token generation here:
//        FirebaseMessaging firebaseMessaging = FirebaseMessaging.getInstance();
//        FirebaseMessaging.getInstance().getToken()
//                .addOnCompleteListener(new OnCompleteListener<String>() {
//                    @Override
//                    public void onComplete(@NonNull Task<String> task) {
//                        if (!task.isSuccessful()) {
//                            System.out.println("Token is not received... " );
//                            return;
//                        }
//
//
//                        // Get new FCM registration token
//                        String token = task.getResult();
//                        System.out.println("Token is successfully received: " + token);
//                        MyFirebaseMessagingService.updateTokenInDatabase(token, formerToken, userId, context);
//
//                    }
//                }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//                        System.out.println("Token generation failed!: " + e);
//
//                    }
//                });
//
//
//    }



}