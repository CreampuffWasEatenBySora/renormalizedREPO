package com.example.e_barangayclient.request_pages;

import androidx.annotation.NonNull;

import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.AccountModel;
import com.example.e_barangayclient.data_models.AvailableDocumentModel;
import com.example.e_barangayclient.data_models.CollectFormModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.homepage;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class request_utilities {

    static ValueEventListener eventListener;
    static DatabaseReference databaseReference;
    static String title = "";
    static String body = "";
    static List<String> tokens = new ArrayList<>();

    public static RequestFormModel request = new RequestFormModel();
    public static CollectFormModel collection = new CollectFormModel();
    public static List<RequestedDocumentModel> temporary_requested_document_list = new ArrayList<>();
    public static List<documentRequirementModel>  temporary_requirement_list = new ArrayList<>();
    public static List<String>  temporary_documentList = new ArrayList<>();




    public static void prepareNewRequestNotifications(String title, String body){


        databaseReference = FirebaseDatabase.getInstance().getReference("Accounts");
        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
                    if (snapshot.exists()){

                        AccountModel account = itemSnapshot.getValue(AccountModel.class);

//                        if (account.isAdmin() && !account.getAccessToken().equals("emptyToken") ){
//                            tokens.add(account.getAccessToken());
//                            System.out.println("token added: " + account.getAccessToken());
//                        }
//
                    }}

                AccountModel currentUser = homepage.currentAccount;
                RequestFormModel request = request_utilities.request;


                LaunchRequestNotifications(title, body);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    static void LaunchRequestNotifications(String title, String body){

        // Username, message, current userID, and recipient token

        databaseReference.removeEventListener(eventListener);

        for (String token : tokens
        ) {

            try {
                JSONObject jsonObject = new JSONObject();
                JSONObject notifObject = new JSONObject();
                notifObject.put("title", title);
                notifObject.put("body", body);

                JSONObject dataObject = new JSONObject();
                dataObject.put("userId", homepage.currentAccount.getUUID());
                dataObject.put("requestId",request.getRequestID());

                jsonObject.put("notification", notifObject);
                jsonObject.put("data", dataObject);
                jsonObject.put("to", token);

                System.out.println("sent to token: " + token);
                Utility.launchNotificationAPI(jsonObject);
            } catch (Exception e ){
                System.out.println("Error: " + e);
            }
        }

        clearUtilityPage();

    }

    public static void clearUtilityPage(){

        request = new RequestFormModel();
        temporary_requested_document_list.clear();
        tokens.clear();

    }

    public static String generateRequestCode(){

        String UUID = homepage.currentAccount.getUUID();
        String UUIDPart ="ABCDS";
        Random rand = new Random();

        int upperBound = 10000000;

        if (UUID.length()>10){
            int letterIndex = rand.nextInt(UUID.length()-5);
            UUIDPart = UUID.substring(letterIndex, (letterIndex+4) );
        }
        StringBuilder numberPart = new StringBuilder("-" + rand.nextInt(upperBound));

        while (numberPart.length() < 9 ){
            numberPart.append("0");
        }



        return "REQ-" + UUIDPart + numberPart;
    }

}
