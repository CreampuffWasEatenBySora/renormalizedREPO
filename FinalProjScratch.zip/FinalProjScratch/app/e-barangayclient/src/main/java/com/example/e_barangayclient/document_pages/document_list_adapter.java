package com.example.e_barangayclient.document_pages;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayclient.R;
import com.example.e_barangayclient.data_models.AvailableDocumentModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.request_pages.request_purpose_select_SpinnerAdapter;
import com.example.e_barangayclient.request_pages.request_utilities;
import com.example.e_barangayclient.request_pages.viewing_request_detail_pages.requested_document_list_page;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class  document_list_adapter extends RecyclerView.Adapter<documentListViewHolder> {


    final int[] spinnerIndex = {0};
    private Context context;
    private List<AvailableDocumentModel> documents;

            public document_list_adapter(Context context, List<AvailableDocumentModel> documents) {
                this.context = context;
                this.documents = documents;
            }

            @NonNull
            @Override
            public documentListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.document_recycler_card, parent, false);
                return new documentListViewHolder(view);

            }

            @Override
            public void onBindViewHolder(@NonNull documentListViewHolder holder, int position) {


                AvailableDocumentModel document = documents.get(position);

                holder.document_name.setText(document.getDocName());
                holder.document_card.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Button confirmRequest, cancel;
                        TextView documentName, documentDesc, requirements;
                        Spinner requestPurpose;


                        final Dialog dialog = new Dialog(context);


                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setContentView(R.layout.popup_request_document);
                        dialog.setCancelable(false);


                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                        confirmRequest = dialog.findViewById(R.id.request_popup_confirm_request);
                        cancel = dialog.findViewById(R.id.request_popup_cancel);
                        requirements = dialog.findViewById(R.id.request_extraMessage);
                        requirements.setText("Requires:\n");
                        documentName = dialog.findViewById(R.id.request_popup_document_name);
                        documentDesc = dialog.findViewById(R.id.request_popup_document_description);
                        requestPurpose = dialog.findViewById(R.id.confirm_request_popup_signup_spinner);

                        requestPurpose.setVisibility(View.GONE);
                        documentName.setText(document.getDocName());
                        documentDesc.setText(document.getDocumentDescription());

                        for (Map.Entry<String, documentRequirementModel> entry: document.getRequirements().entrySet()
                             ) {

                            requirements.append("\n-"+entry.getValue().getRequirement_name());

                        }
                        confirmRequest.setText("Make a request for this document");

                        confirmRequest.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {


                                dialog.dismiss();
                                Date c = Calendar.getInstance().getTime();
                                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
                                String formattedDate = df.format(c);
                                request_utilities.request = new RequestFormModel(

                                        null, null, null,
                                        request_utilities.generateRequestCode(),
                                        null,null,
                                        null,
                                        formattedDate,
                                        "TBA",
                                        null,
                                        "New",
                                        "Waiting for approval"

                                );
                                RequestedDocumentModel documentModel = new RequestedDocumentModel(
                                        document.getDocumentID(),
                                        document.getDocName(),
                                        "Other",
                                        1,
                                        document.getRequirements(),
                                        "Pending");
                                request_utilities.temporary_requested_document_list.add(documentModel);

                                Intent intent = new Intent(context, requested_document_list_page.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                context.startActivity(intent);

                            }
                        });

                       cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });


                        dialog.show();
                        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

                    }
                });

            }

            @Override
            public int getItemCount() {
                return documents.size();
            }
}

class documentListViewHolder extends RecyclerView.ViewHolder{

    TextView document_name;
    CardView document_card;


    public documentListViewHolder(@NonNull View itemView){
        super(itemView);


        document_card = itemView.findViewById(R.id.document_recycler_card);
        document_name = itemView.findViewById(R.id.document_Name);


    }





}
