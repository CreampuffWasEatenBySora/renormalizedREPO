package com.example.e_barangayclient.signup_pages.fragments;

import static com.example.e_barangayclient.Utility.APILINK;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_barangayclient.R;
import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.address;
import com.example.e_barangayclient.signup_pages.signup_base_page;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Signup_stepFour_fragment extends Fragment {

    TabLayout tabLayoutFromBase = signup_base_page.tabLayout;
    TabLayout.Tab tabText = tabLayoutFromBase.getTabAt(3);
    public Signup_stepFour_fragment() {}
    private EditText subdivision_field, housenumber_field, mobile_number_field;
    private String municipality_text, barangay_text, subdivision_text, house_number, mobile_number;
    private Button nextButton;
    private AutoCompleteTextView municipal_field, barangay_field;
    View view;
    List<String> municipalities = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         view = inflater.inflate(R.layout.fragment_signup_step_four, container, false);


        setUpComponents();

        // Set onClickListener for the signupButton here
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (checkFields()){

                    findNumMatch(mobile_number);

                } else {
                    tabText.setText("4");
                    signup_base_page.verifiedSteps[3] = false;

                }
                }
        });


        return view;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {}

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }


    void setUpComponents(){
        // Initialize Buttons here
        nextButton = view.findViewById(R.id.signup_next);
       municipalities = new ArrayList<>(Arrays.asList(
                "Choose Municipality",
                "Alfonso",
                "Amadeo",
                "Bacoor",
                "Carmona",
                "Cavite City",
                "Dasmariñas",
                "General Emilio Aguinaldo",
                "General Mariano Alvarez",
                "General Trias",
                "Imus",
                "Indang",
                "Kawit",
                "Magallanes",
                "Maragondon",
                "Mendez-Nuñez",
                "Naic",
                "Noveleta",
                "Rosario",
                "Silang",
                "Tagaytay",
                "Tanza",
                "Ternate",
                "Trece Martires"
        ));

        // Initialize the details to be uploaded into the database

        ArrayAdapter<String> municipalityAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_dropdown_item_1line, municipalities);
        municipal_field = view.findViewById(R.id.municipality_text);
        municipal_field.setAdapter(municipalityAdapter);
        barangay_field = view.findViewById(R.id.barangay_text);

        subdivision_field = view.findViewById(R.id.signup_subdiv);
        housenumber_field = view.findViewById(R.id.signup_houseNum);
        mobile_number_field = view.findViewById(R.id.signup_phoneNum);

        setTextChangeListener(municipal_field, municipality_text);
        setTextChangeListener(barangay_field, barangay_text);
        setTextChangeListener(subdivision_field, subdivision_text);
        setTextChangeListener(housenumber_field, house_number);
        setTextChangeListener(mobile_number_field, mobile_number);

    }
    boolean checkFields(){
        boolean passed = true;
        boolean NoEmpty = true;
        municipality_text = municipal_field.getText().toString().trim();
        barangay_text = barangay_field.getText().toString().trim();
        subdivision_text = subdivision_field.getText().toString().trim();
        house_number = housenumber_field.getText().toString().trim();
        mobile_number = mobile_number_field.getText().toString().trim();

        HashMap <EditText, String> fields = new HashMap<>();
        fields.put(municipal_field, municipality_text);
        fields.put(barangay_field, barangay_text);
        fields.put(subdivision_field, subdivision_text);
        fields.put(housenumber_field, house_number);
        fields.put(mobile_number_field, mobile_number);

        for (Map.Entry<EditText, String> entry : fields.entrySet()){

            if (entry.getValue().isEmpty()){
                entry.getKey().setError("Do not leave empty fields.");
                NoEmpty = false;
                Utility.rejectRed(entry.getKey(), getContext(), getActivity());

            } else if (!validAddress(entry.getValue())){
                entry.getKey().setError("Only letters are allowed.");
                NoEmpty = false;
                Utility.rejectRed(entry.getKey(), getContext(), getActivity());
            } else {
                Utility.confirmGreen(entry.getKey(), getContext(), getActivity());
            }

        }


        if (!municipalities.contains(municipality_text)){
            municipal_field.setError("Please enter a included Municipality.");
            passed = false;
            Utility.rejectRed(municipal_field, getContext(), getActivity());
            return passed;


        } else {

            if (!validNums(mobile_number) || mobile_number.length() != 11 ){
                mobile_number_field.setError("Please enter a valid mobile number");
                passed = false;
                Utility.rejectRed(mobile_number_field, getContext(), getActivity());
                return passed;

            } else {
                Utility.confirmGreen(mobile_number_field, getContext(), getActivity());
            }

            Utility.confirmGreen(municipal_field, getContext(), getActivity());
        }



        if (NoEmpty && passed){ return true;} else{return false;}
    }

    private static boolean validAddress(String input) {
        // Regular expression to check if the string contains numbers
        String regex = "^[a-zA-Z0-9\\s.,-]*$";
        return input.matches(regex);
    }

    private static boolean validNums(String input) {
        boolean valid = false;

        // Regular expression to check if the string contains numbers
        if(!input.isEmpty()){

            char[] numcheck = input.toCharArray();
            String firstTwo = String.valueOf(numcheck[0] +""+ numcheck[1]);
            String regex = "^[0-9]+$";


            if (input.matches(regex) && firstTwo.equals("09")){
                valid = true;
            }
        } else { valid = false;}

        return valid;
    }

    void findNumMatch(String phoneNum){

        ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false); // prevent user from dismissing dialog
        progressDialog.show();

        JSONObject postData = new JSONObject();

        RequestQueue queue = Volley.newRequestQueue(getContext());
        String url = APILINK+"/findPhoneMatch";


        try {
            postData.put("phoneNum",phoneNum);

        } catch (Exception e){
            e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");

                            if ("success".equals(status)) {

                                tabText.setText("\u2714");
                                signup_base_page.verifiedSteps[3] = true;
                                signup_base_page.fragMunicipal = municipality_text;
                                signup_base_page.fragBarangay = barangay_text;
                                signup_base_page.fragSubdivision = subdivision_text;
                                signup_base_page.fragHouseNum = house_number;
                                signup_base_page.fragPhoneNum = mobile_number;
                                signup_base_page.Address = new address(municipality_text, barangay_text, subdivision_text, house_number, mobile_number);
                                Utility.hideKeyboard(getActivity());
                                Utility.nextPage(tabLayoutFromBase, 3);

                            } else {
                                Utility.rejectRed(mobile_number_field, getContext(), getActivity());
                                mobile_number_field.setError("This mobile number has already been used in another account.");
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getContext(), "Please try again.", Toast.LENGTH_SHORT);
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return postData.toString().getBytes();
            }
            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };
        queue.add(stringRequest);
    }



    void setTextChangeListener(EditText field, String value){

        field.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                // Called to notify you that somewhere within the text, characters have been added or removed.
                // This is where you can perform your action after the text has changed.
                String newText = editable.toString();
                // Add your logic here to handle the changed text
                if (!newText.equals(value)) {
                    Utility.resetColor(field, getContext());
                    tabText.setText("4");
                    signup_base_page.verifiedSteps[3] = false;

                }
            }
        });


    }

   }
