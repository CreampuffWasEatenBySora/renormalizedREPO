package com.example.e_barangayclient;


import static com.example.e_barangayclient.homepage.currentAccount;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.CountDownTimer;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_barangayclient.collectionPages.collection_detail_pages.returned_collection_page;
import com.example.e_barangayclient.collectionPages.utilities;
import com.example.e_barangayclient.collectionPages.collection_detail_pages.returned_request_downloadRequest;
import com.example.e_barangayclient.data_models.AccountModel;
import com.example.e_barangayclient.data_models.CollectFormModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.notification_pages.notification_list_page;
import com.example.e_barangayclient.request_pages.request_utilities;
import com.example.e_barangayclient.request_pages.viewing_returned_request_detail_pages.returned_request_list_page;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;  import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class Utility {
    static DatabaseReference databaseReference;

    public static ArrayList<String> notifsList = new ArrayList<>();

    public static String APILINK = "http://192.168.6.167/barangay_eConnect/renormalizedREPO/public/api";
    public static boolean onlyLetters(String input) {
        // Regular expression to check if the string contains numbers
        String regex = "^[a-zA-Z\\s]+$";
        return input.matches(regex);
    }

    public static boolean onlyLettersNsymbols(String input) {
        // Regular expression to check if the string contains numbers
        String regex = "^[a-zA-Z\\s\\W_]*$";
        return input.matches(regex);
    }

    public static void confirmGreen(EditText correct, Context context, Activity activity){
        correct.setCompoundDrawables(null, null, null, null);
        correct.setError(null);
        correct.invalidate();
        Drawable greenIcon = ContextCompat.getDrawable(activity, R.drawable.ic_action_accept);// Replace with your drawable resource
        correct.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, greenIcon, null);
        int acceptedColor = ContextCompat.getColor(context, R.color.acceptedGreen);
        correct.setTextColor(acceptedColor);
    }

    public static void rejectRed(EditText reject, Context context, Activity activity){
        reject.setCompoundDrawables(null, null, null, null);
        Drawable redIcon =  ContextCompat.getDrawable(activity, R.drawable.ic_action_rejected); // Replace with your drawable resource
        reject.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, redIcon, null);
        reject.invalidate();
        int rejectedColor = ContextCompat.getColor(context, R.color.rejectedRed);
        reject.setTextColor(rejectedColor);
    }

    public static void resetColor(EditText correct, Context context){
        correct.invalidate();
        correct.setCompoundDrawables(null, null, null, null);
        int resetColor = ContextCompat.getColor(context, R.color.black);
        correct.setTextColor(resetColor);
    }

    public static void nextPage(TabLayout tabLayoutFromBase, int position){
        // Delay in milliseconds
        long delayMillis = 1000; // 1 second

        CountDownTimer countDownTimer = new CountDownTimer(delayMillis, delayMillis) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Not used in this example
            }

            @Override
            public void onFinish() {
                TabLayout.Tab selectTab = tabLayoutFromBase.getTabAt(position + 1);
                if (selectTab != null){
                    selectTab.select();
                }
            }
        };

        countDownTimer.start();


    }

    public static void hideKeyboard(Activity activity) {
        View view = activity.findViewById(android.R.id.content);
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public interface nameCallback {
        void onFullNameReceived(String firstName);
    }


    public interface DocCountCallback {
        void onDocCountReceived(int counter);
    }

    public interface RequestStatusCallback {
        void onStatusReceived(String Status);
    }


    public static String getDate(){

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
        String formattedDate = df.format(c);
        return formattedDate;
    }

    public static void getFullName(String userId, nameCallback callback) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/" + userId);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    AccountModel acc = snapshot.getValue(AccountModel.class);

                    String fullName = acc.getFullName();


                    // Call the callback with the result
                    callback.onFullNameReceived(fullName);
                } else {
                    // Call the callback with null if the snapshot doesn't exist
                    callback.onFullNameReceived(null);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle errors
                callback.onFullNameReceived(null);
            }
        });
    }





    public static void getDocCount(String USERID, String REQID, DocCountCallback callback) {

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Accounts/"+USERID+"/Requests/"+REQID+"/requestedDocument");
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    long initCount = snapshot.getChildrenCount();
                    int count = (int) initCount;
                    callback.onDocCountReceived(count);
                } else {
                    callback.onDocCountReceived(0);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onDocCountReceived(0);

            }
        });
    }


    public static void updateFirebaseData(Map<String, Object> updateMap, Context context, String updateMessage, String failMessage){

        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.updateChildren(updateMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

                if (updateMessage != null){
                    Toast.makeText(context, updateMessage, Toast.LENGTH_SHORT).show();
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (updateMessage != null){
                    Toast.makeText(context, failMessage, Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public static void launchNotificationAPI(JSONObject jsonObject){
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        OkHttpClient client = new OkHttpClient();
        String url = "https://fcm.googleapis.com/fcm/send";
        RequestBody body = RequestBody.create(jsonObject.toString(), JSON);

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .header("Authorization", "Bearer AAAANw_N_io:APA91bEiwZMysEcbEyJhSdmvmOBeVPYQGfsu1JcPCpwykYbHKuurmKnP3vi-pj2UTIQ9YeyL5m8VX1WhkcQC4oe5GSp6mxOmyaA-QQAJ7wihhKS0XApwVEANub2ZyKZBmZGWmOWGi-TH")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                System.out.println("Failed: " + e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                System.out.println("Sent confirmed " + request);

            }
        });

    }


    public static String getApproxDate(String date){
        String approxDate = "";
        try{

            Date now = Calendar.getInstance().getTime();

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date eventDate = sdf.parse(date);
            Date nowDate = sdf.parse(sdf.format(now));
            long eventMillis = eventDate.getTime();
            long nowMillis = nowDate.getTime();

            System.out.println("Now date: "+ sdf.format(now));
            System.out.println("Event Date: "+date);


            long diff = nowMillis - eventMillis;
            if ((diff/86400000) >= 365) {
                approxDate = (diff/86400000) +" years(s) ago";
            } else if ((diff/86400000) >= 30) {
                approxDate = (diff/86400000) +" month(s) ago";
            } else if ((diff/86400000) >= 1) {
                approxDate = (diff/86400000) +" days(s) ago";
            }else if ((diff/3600000) >= 1) {
                approxDate = (diff/3600000) +" Hour(s) ago";
            } else if ((diff/60000) >= 1) {
                approxDate = (diff/60000) +" minute(s) ago";
            } else if ((diff/1000) >= 1){
                approxDate = (diff/1000) +" second(s) ago";
            }

            System.out.println("Diff is:" + diff);
            System.out.println(approxDate);

        } catch(Exception e){

            System.out.println(e);

        }

        return approxDate;

    }

    public static void createNotificationChannel(Context context) {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("GENERAL_NOTIF","NOTIFICATIONS", importance);
            channel.setDescription("general notifications");
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    public static void launchNotifs(Context context, String title, String body){

        Intent intent = new Intent(context, notification_list_page.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        int notificationId = (int) System.currentTimeMillis();
        System.out.println("launched notif:  " + title +" "+ body);

        // Create and show notification
        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(context, "GENERAL_NOTIF")
                        .setContentTitle(title)
                        .setContentText(body)
                        .setSmallIcon(R.drawable.baseline_circle_unread_notifications_24)
                        .setContentIntent(pendingIntent)
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        notificationBuilder.setAutoCancel(true);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        notificationManager.notify(notificationId, notificationBuilder.build());

    }

    public static void fetchNotifications(String UUID, Context context){

        RequestQueue queue = Volley.newRequestQueue( context);
        String url = APILINK+"/fetchNotifications";
        JSONObject postData = new JSONObject();
        JSONObject notifRequestObject = new JSONObject();
        try {
            notifRequestObject.put("userUUID", homepage.currentAccount.getUUID());
            notifRequestObject.put("accessKey", homepage.currentAccount.getAccessToken());
        } catch (Exception e ){
            e.printStackTrace();
        }
        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");
                            JSONArray notifyData = jsonResponse.getJSONArray("notif_data");
                            if ("success".equals(status)) {
                                for (int i = 0; i < notifyData.length() ; i++) {
                                    JSONObject notif = notifyData.getJSONObject(i);
                                    if( notif.getString( "readStatus").equals("0") && !notifsList.contains(notif.getString("id"))){
                                        System.out.println("Notified of: " + notif.getString("eventDesc") +" "+notif.getString("eventType"));
                                        launchNotifs(context, notif.getString("eventDesc") +" "+notif.getString("eventType"),
                                                "You have a " +notif.getString("eventType")+" notification!" );
                                    }
                                    notifsList.add(notif.getString("id"));

                                }
                            } else {
                                Toast.makeText( context, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            System.out.println("ERROR HERE");
                            e.printStackTrace();
                        }

                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return notifRequestObject.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(stringRequest);




    }

    public static void updateNotifReadStatus(Context context, String notifID){

        RequestQueue queue = Volley.newRequestQueue( context);
        String url = APILINK+"/updateNotifications";
        JSONObject postData = new JSONObject();
        JSONObject notifRequestObject = new JSONObject();
        try {
            notifRequestObject.put("id", notifID);
        } catch (Exception e ){
            e.printStackTrace();
        }
        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");
                            if (!"success".equals(status)) {
                                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            System.out.println("ERROR HERE");
                            e.printStackTrace();
                        }

                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return notifRequestObject.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(stringRequest);



    }

    public static String notificationText(String fromName, String eventType, String eventDesc){
      String notifyText = "";

        switch (eventType){

            case "Request":

                switch (eventDesc){
                    case "Approved":
                        notifyText =  fromName + " has approved your document request!\nSchedule your collection date. ";
                    break;

                    case "Rejected":
                        notifyText = fromName + " has rejected your document request.\nPlease check the remarks for more information";
                        break;
                }
            break;

            case "Collection":
                switch (eventDesc){
                    case "Ready":
                        notifyText =  fromName + " Your documents are now ready to collect!\nYou can go to the barangay hall now. ";
                        break;

                    case "Completed":
                            notifyText =  fromName + " has confirmed your document collection by the admin!\nThank you for using barangay-econnect! ";
                            break;
                }
                break;

            default:
                notifyText =   fromName + " has added a new document!\nCheck it out!";
                        break;
        }
        return notifyText;
    };

    public static void fetchParticularRequest(Context context, String requestID){



        JSONObject postData = new JSONObject();

        RequestQueue queue = Volley.newRequestQueue(context );
        String url = APILINK+"/fetchRequests ";


        try {

            postData.put("userID", currentAccount.getUUID());
            postData.put("requestID", requestID);

        } catch (Exception e){
            e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            RequestFormModel  fetchedRequest = new RequestFormModel();
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");
                            JSONArray request_data = jsonResponse.getJSONArray("request_data");

//                            System.out.println(request_data);

                            if ("success".equals(status)) {


                                for (int i = 0; i < request_data.length() ; i++) {

                                    JSONObject request = request_data.getJSONObject(i);
                                    HashMap<String, RequestedDocumentModel> requested_document_list = new HashMap<>();


                                        JSONArray requested_documents = request.getJSONArray("requested_doc");

                                        for (int j = 0; j < requested_documents.length(); j++) {

                                            JSONObject document = requested_documents.getJSONObject(j);
                                            RequestedDocumentModel requested_document_entry = new RequestedDocumentModel(
                                                    request.getString("requestID"),
                                                    document.getString("docName"),
                                                    document.getString("request_reason"),
                                                    document.getInt("request_quantity"),
                                                    null,
                                                    document.getString("status")
                                            );

                                            requested_document_list.put(document.getString("docName"), requested_document_entry);}

                                                fetchedRequest = new RequestFormModel(
                                                request.getString("requestID"),
                                                        request.getString("colID"),
                                                        request.getString("colStat"),
                                                request.getString("requestCode"),
                                                        request.getString("colSched"),
                                                        request.getString("colDate"),
                                                requested_document_list,
                                                request.getString("dateRequested"),
                                                request.getString("dateResponded"),
                                                request.getString("officerName"),
                                                request.getString("status"),
                                                request.getString("remarks")
                                        );

                                }

                                request_utilities.request = fetchedRequest;
                                Intent intent = new Intent(context, returned_request_list_page.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                context.startActivity(intent);

                            } else {
                                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            System.out.println("ERROR HERE");
                            e.printStackTrace();
                        }

                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(stringRequest);

    }



    public static void fetchParticularCollection(Context context, String collectionID) {


        JSONObject postData = new JSONObject();

        RequestQueue queue = Volley.newRequestQueue(context);
        String url = APILINK+"/fetchCollections ";


        try {

            postData.put("collectID", collectionID);
            postData.put("userID", currentAccount.getUUID());

        } catch (Exception e) {
            e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            CollectFormModel collection = new CollectFormModel();
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");

                            // Data about the collection record
                            JSONArray data = jsonResponse.getJSONArray("collection_data");


                            System.out.println(data);

                            if ("success".equals(status)) {


                                for (int i = 0; i < data.length(); i++) {

                                    JSONObject request = data.getJSONObject(i);
                                    HashMap<String, RequestedDocumentModel> requested_document_list = new HashMap<>();


                                        JSONArray requested_documents = request.getJSONArray("requested_doc");

                                        for (int j = 0; j < requested_documents.length(); j++) {

                                            JSONObject document = requested_documents.getJSONObject(j);

                                            if (!document.getString("status").equals("REJ")) {

                                                RequestedDocumentModel requested_document_entry = new RequestedDocumentModel(
                                                        request.getString("requestID"),
                                                        document.getString("docName"),
                                                        document.getString("request_reason"),
                                                        document.getInt("request_quantity"),
                                                        null,
                                                        document.getString("status")
                                                );

                                                requested_document_list.put(document.getString("docName"), requested_document_entry);
                                            }

                                        }

                                        RequestFormModel request_form = new RequestFormModel(
                                                request.getString("requestID"),
                                                request.getString("collectID"),
                                                request.getString("status"),
                                                request.getString("requestCode"),
                                                request.getString("dateScheduled"),
                                                request.getString("dateCollected"),
                                                requested_document_list,
                                                request.getString("dateRequested"),
                                                request.getString("dateResponded"),
                                                request.getString("reqApproveOfficerName"),
                                                request.getString("status"),
                                                null
                                        );


                                                collection = new CollectFormModel(
                                                request.getString("collectID"),
                                                request.getString("dateScheduled"),
                                                request.getString("dateCollected"),
                                                request_form,
                                                request.getString("reqCollectOfficerName"),
                                                request.getString("status"),
                                                request.getString("remarks")
                                        );

                                }

                                utilities.collection = collection ;
                                Intent intent = new Intent(context, returned_collection_page.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                context.startActivity(intent);

                            } else {
                                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            System.out.println("ERROR HERE");
                            e.printStackTrace();
                        }

                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }) {
            @Override
            public byte[] getBody() {
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(stringRequest);

    }


    }
