package com.example.e_barangayclient.data_models;

public class RegistrationDataClass {

    private String userID, userName, address;
    private String email;
    private String idtype;
    private String password;
    private String number;
    private String dateRegistered;
    private String dateResponded;
    private String status;

    public String getUserID() { return userID; }

    public String getUserName() { return userName; }

    public String getAddress() { return address; }
    public String getEmail() { return email; }

    public String getPassword() { return password; }

    public String getIDType() { return idtype; }

    public String getNumber() { return number; }

    public String getStatus() { return status; }
    public String getDateRegistered() { return dateRegistered; }
    public String getDateResponded() { return dateResponded; }


    public RegistrationDataClass(String userID,
                                 String userName,
                                 String address,
                                 String email,
                                 String num,
                                 String idType,
                                 String pass,
                                 String status,
                                 String dateRegistered,
                                 String dateResponded){

        this.userID = userID;
        this.userName = userName;
        this.address = address;
        this.email = email;
        this.number = num;
        this.idtype = idType;
        this.password = pass;
        this.status = status;
        this.dateRegistered = dateRegistered;
        this.dateResponded = dateResponded;

    }

    public RegistrationDataClass(){

    }

}
