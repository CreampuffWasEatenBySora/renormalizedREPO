package com.example.e_barangayclient.collectionPages;

import androidx.annotation.NonNull;

import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.AccountModel;
import com.example.e_barangayclient.data_models.CollectFormModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.homepage;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class utilities {

    static ValueEventListener eventListener;
    static DatabaseReference databaseReference;
    static String title = "";
    static String body = "";
    static List<String> tokens = new ArrayList<>();

    public static CollectFormModel collection = new CollectFormModel();
    public static List<RequestedDocumentModel> temporary_requested_document_list = new ArrayList<>();
    public static List<documentRequirementModel>  temporary_requirement_list = new ArrayList<>();




    public static void clearUtilityPage(){

        collection = new CollectFormModel();
        temporary_requested_document_list.clear();
        tokens.clear();

    }

    }


