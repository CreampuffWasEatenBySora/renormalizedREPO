package com.example.e_barangayclient.collectionPages.collection_detail_pages;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayclient.R;
import com.example.e_barangayclient.collectionPages.SpinnerAdapter;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class requested_documents_list_adapter extends RecyclerView.Adapter<requested_documents_viewholder> {


    final int[] spinnerIndex = {0};
    public Activity activity;
    public Context context;
    private List<RequestedDocumentModel> requestedDocuments;
    private com.example.e_barangayclient.collectionPages.collection_detail_pages.cameraActionListener cameraActionListener;

            public requested_documents_list_adapter(Context context, List<RequestedDocumentModel> requestedDocuments, Activity activity, com.example.e_barangayclient.collectionPages.collection_detail_pages.cameraActionListener cameraActionListener) {
                this.context = context;
                this.activity = activity;
                this.cameraActionListener = cameraActionListener;
                this.requestedDocuments = requestedDocuments;
            }

            @NonNull
            @Override
            public requested_documents_viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.requested_document_recycler_card, parent, false);
                return new requested_documents_viewholder(view);

            }

            @Override
            public void onBindViewHolder(@NonNull requested_documents_viewholder holder, int position) {



                RequestedDocumentModel document = requestedDocuments.get(position);
                HashMap<String, documentRequirementModel> requirements = document.getRequirements();

                holder.counterBox.setVisibility(View.INVISIBLE);

                List<String> purpose_list = new ArrayList<>(Arrays.asList(
                        "Scholarship",
                        "Employment",
                        "Business",
                        "Requirement For Another Barangay Document"));

                SpinnerAdapter spinner_adapter = new SpinnerAdapter(context, purpose_list);
                holder.edit_purpose.setAdapter(spinner_adapter);

                holder.edit_purpose.setSelection(purpose_list.indexOf(document.getPurpose()));

                holder.edit_purpose.setEnabled(false);

                holder.requested_doc_name.setText(document.getDocName());

                holder.detailsDropdown.setChecked(false);

                holder.detailsDropdown.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (!isChecked){
                            holder.detailsBox.setVisibility(View.GONE);
//                            System.out.println("unchecked");
                        } else {
                            holder.detailsBox.setVisibility(View.VISIBLE);
//                            System.out.println("checked");

                        }
                    }
                });

                holder.delete.setVisibility(View.GONE);
                holder.quantityPicker.setValue(document.getQuantity());
                holder.quantityPicker.setEnabled(false);
                holder.detailsBox.setVisibility(View.GONE);

            }


            @Override
            public int getItemCount() {
                return requestedDocuments.size();
            }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

    }
}



class requested_documents_viewholder extends RecyclerView.ViewHolder{

    TextView requested_doc_name, requested_document_status, requirement_counter;
    ImageButton  delete;
    Spinner edit_purpose;
    CheckBox detailsDropdown;
    NumberPicker quantityPicker;
    CardView requestCard;
    LinearLayout editBox, detailsBox, counterBox;
    List<documentRequirementModel> requirementList = new ArrayList<>();

    requirements_list_adapter adapter;
    public requested_documents_viewholder(@NonNull View itemView){
        super(itemView);


        requestCard = itemView.findViewById(R.id.requested_document_card);
        requested_doc_name = itemView.findViewById(R.id.requested_document_name);
        delete = itemView.findViewById(R.id.requested_document_delete);
        edit_purpose = itemView.findViewById(R.id.request_reason);
        detailsDropdown = itemView.findViewById(R.id.request_dropdown);
        detailsBox = itemView.findViewById(R.id. requestCard_detailsBox);
        counterBox = itemView.findViewById(R.id.counterBox);
        requested_document_status = itemView.findViewById(R.id.requested_document_status);
        editBox = itemView.findViewById(R.id.requested_document_editBox);
        requirement_counter = itemView.findViewById(R.id.requested_document_requirement_counter);
        quantityPicker = itemView.findViewById(R.id.requested_document_quantity);
        quantityPicker.setMinValue(1);
        quantityPicker.setMaxValue(5);

        requested_document_status.setVisibility(View.GONE);



    }



}
