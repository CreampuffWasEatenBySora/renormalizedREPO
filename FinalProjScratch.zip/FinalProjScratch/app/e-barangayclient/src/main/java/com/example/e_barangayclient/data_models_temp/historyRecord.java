package com.example.e_barangayclient.data_models_temp;

//Basically, parang form to. Parang questionnaire.

public class historyRecord {

    private String logID;

    private String eventID;
    private String eventDescription;
    private String eventPartyA_ID;
    private String eventPartyB_ID;
    private String eventDate;
    private String remarks;

    public String getLogID() { return logID; }
    public String getEventID() { return eventID; }
    public String getEventPartyA_ID() { return eventPartyA_ID; }

    public String getEventPartyB_ID() { return eventPartyB_ID; }
    public String getEventDate() { return eventDate; }
    public String getRemarks() { return remarks; }

    public historyRecord(String logID,
                         String eventID,
                         String eventDescription,
                         String eventP_A,
                         String eventP_B,
                         String eventDate,
                         String remarks){

        this.logID = logID;
        this.eventID = eventID;
        this.eventDescription = eventDescription;
        this.eventPartyA_ID = eventP_A;
        this.eventPartyB_ID = eventP_B;
        this.eventDate = eventDate;
        this.remarks = remarks;

    }

    public historyRecord(){

    }

}


