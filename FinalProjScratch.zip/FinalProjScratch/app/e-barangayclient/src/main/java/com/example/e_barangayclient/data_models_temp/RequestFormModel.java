package com.example.e_barangayclient.data_models_temp;

//Basically, parang form to. Parang questionnaire.

public class RequestFormModel {

    private String requestID;
    private String clientID;

    private com.example.e_barangayclient.data_models_temp.RequestedDocumentModel RequestedDocumentModel = new RequestedDocumentModel();
    private String dateRequested;
    private String dateRelease;

    private String dateCollected;
    private String status;
    private String confirmer;
    private String remarks;


    public String getRequestID() { return requestID; }
    public String getClientID() { return clientID; }
    public com.example.e_barangayclient.data_models_temp.RequestedDocumentModel getRequestedDocument() { return RequestedDocumentModel; }
    public String getDateRequested() { return dateRequested; }
    public String getDateRelease() { return dateRelease; }

    public String getDateCollected() { return dateCollected; }

    public String getStatus() { return status; }
    public String getRemarks() { return remarks; }
    public String getConfirmer() { return confirmer; }

    public void setStatus(String status){

        this.status = status;
    }




    public RequestFormModel(String requestID,
                            String clientID,
                            com.example.e_barangayclient.data_models_temp.RequestedDocumentModel requestDoc,
                            String dateRequested,
                            String dateRelease,
                            String dateCollect,
                            String confirmer,
                            String status,
                            String remarks){

        this.requestID = requestID;
        this.clientID = clientID;
        this.RequestedDocumentModel = requestDoc;
        this.dateRequested = dateRequested;
        this.dateRelease = dateRelease;
        this.dateCollected = dateCollect;
        this.confirmer = confirmer;
        this.status = status;
        this.remarks = remarks;


    }

    public RequestFormModel(){

    }

}


