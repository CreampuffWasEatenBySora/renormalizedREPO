package com.example.e_barangayclient.data_models;

//Basically, parang form to. Parang questionnaire.

import android.net.Uri;

public class documentRequirementModel {

    private String requirement_Id;
    private String requirement_name;

    private String requirement_description;
    private imageData requirement_image;
    private String requirement_filePath;

    public String getRequirement_Id() {
        return requirement_Id;
    }
    public void setRequirement_image(imageData imageData) {
        this.requirement_image = imageData;
    }



    public String getRequirement_name() {
        return requirement_name;
    }

    public imageData getRequirement_image(){return requirement_image;}
    public String getRequirement_description() {
        return requirement_description;
    }
    public String getRequirement_filePath() {
        return requirement_description;
    }

    public documentRequirementModel(String requirement_Id,
                                    String requirement_name,
                                    imageData requirement_requirementImage,
                                    String requirement_description,
                                    String requirement_filePath
    ){

        this.requirement_Id = requirement_Id;
        this.requirement_name = requirement_name;
        this.requirement_image = requirement_requirementImage;
        this.requirement_description = requirement_description;
        this.requirement_filePath = requirement_filePath;

    }

    public documentRequirementModel(){

    }

}


