package com.example.e_barangayclient;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.e_barangayclient.data_models.AccountModel;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class account_details extends AppCompatActivity {

    TextView status, fullName, address, phoneNumber, IDType, email, registration_date, accept_date, accept_person, reason, birthday;
    LinearLayout  IDCheck, selfieCheck , reject, accept, accept_box, detail_box, reject_box;
    ImageButton back;
    public static AccountModel account = new AccountModel();
    private DatabaseReference databaseReference;
    private FirebaseDatabase firebaseDatabase;


    static RelativeLayout layout;

    final int[] spinnerIndex = {0};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_details);



        setUpComponents();


    }

    void setUpComponents(){

        IDCheck = findViewById(R.id.pending_id_check);
        selfieCheck = findViewById(R.id.pending_selfie_check);
        back = findViewById(R.id.recycler_backward);
        fullName = findViewById(R.id.pending_fullname);
        address = findViewById(R.id.pending_address);
        detail_box = findViewById(R.id.detail_box);
        phoneNumber = findViewById(R.id.pending_phonenum);
        IDType = findViewById(R.id.pending_ID_type);
        email = findViewById(R.id.pending_email);
        registration_date = findViewById(R.id.pending_register_date);
        reject_box = findViewById(R.id.reject_box);
        accept_person = findViewById(R.id.verified_by);
        reason = findViewById(R.id.remarks);
        status = findViewById(R.id.recycler_subheader);
        birthday = findViewById(R.id.pending_birthday);

        accept_date = findViewById(R.id.date_verified);

//        String municipality = account.getAddress().getMunicipality();
//        String barangay = account.getAddress().getBarangay();
//        String subdivision = account.getAddress().getSubdivision();
//        String houseNum = account.getAddress().getHouseNum();

        // String Address = subdivision + ", " + houseNum + ", Barangay " + barangay +", " + municipality + ", Cavite." ;

        fullName.setText(account.getFullName());
//        address.setText(Address);
//        phoneNumber.setText(account.getAddress().getPhoneNum());
//        IDType.setText(account.getRegDetails().getIdtype());
//        email.setText(account.getEmail());
//        registration_date.setText(account.getRegDetails().getDateRegistered());
        status.setText(account.getStatus());
        birthday.setText(account.getBirthday());

        if(!account.getStatus().equals("Pending")){
           detail_box.setVisibility(View.VISIBLE);
//           accept_date.setText(account.getRegDetails().getDateResponded());
//           accept_person.setText(account.getRegDetails().getConfirmer());

        }



        selfieCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getBaseContext(), account_image.class);
                intent.putExtra("Path", "images/registrations/" + account.getUUID() + "/selfiePic");
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);

            }
        });

        IDCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getBaseContext(), account_image.class);
                intent.putExtra("Path", "images/registrations/" + account.getUUID() + "/docPic");
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              closeActivity();
            }
        });

    }



    void closeActivity(){

        finish();
        Intent intent = new Intent(getApplicationContext(), homepage.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);

    }
}