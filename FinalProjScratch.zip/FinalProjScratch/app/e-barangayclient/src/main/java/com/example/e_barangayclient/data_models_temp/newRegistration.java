package com.example.e_barangayclient.data_models_temp;

//Basically, parang form to. Parang questionnaire.

public class newRegistration {

    private String userID;

    private String fullname;
    private String idtype;
    private com.example.e_barangayclient.data_models_temp.address address = new address();

    private accDetails accountDetails = new accDetails();

    private String dateRegistered;
    private String dateResponded;

    public String getUserID() { return userID; }
    public String getFullname() { return fullname; }
    public String getIdtype() { return idtype; }
    public com.example.e_barangayclient.data_models_temp.address getAddress() { return address; }
    public accDetails getAccountDetails() { return accountDetails; }

    public String getDateRegistered() { return dateRegistered; }
    public String getDateResponded() { return dateResponded; }

    public newRegistration(String ID,
                                 String fullName,
                                 String idtype,
                                 com.example.e_barangayclient.data_models_temp.address address,
                                 accDetails AccDetails,
                                 String DateRegistered,
                                 String DateResponded){

        this.userID = ID;
        this.fullname = fullName;
        this.idtype = idtype;
        this.address = address;
        this.accountDetails = AccDetails;
        this.dateRegistered = DateRegistered;
        this.dateResponded = DateResponded;

    }

    public newRegistration(){

    }

}


