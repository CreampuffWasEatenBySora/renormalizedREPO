package com.example.e_barangayclient.request_pages.viewing_returned_request_detail_pages;

import com.example.e_barangayclient.data_models.documentRequirementModel;

public interface cameraActionListener {
    void onRequestCameraPermission( documentRequirementModel requirement );
}
