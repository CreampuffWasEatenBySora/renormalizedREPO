package com.example.e_barangayclient.notification_pages;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayclient.R;
import com.example.e_barangayclient.Utility;
import com.example.e_barangayclient.data_models.NotificationModel;
import com.example.e_barangayclient.document_pages.document_list_page;
import com.example.e_barangayclient.homepage;
import com.example.e_barangayclient.request_pages.request_purpose_select_SpinnerAdapter;
import com.example.e_barangayclient.request_pages.request_utilities;
import com.example.e_barangayclient.request_pages.viewing_returned_request_detail_pages.returned_request_list_page;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.internal.Util;

public class notification_adapter extends RecyclerView.Adapter< notificationViewHolder> {


    final int[] spinnerIndex = {0};
    private Context context;
    private List<NotificationModel> notification;

            public notification_adapter(Context context, List<NotificationModel> documents) {
                this.context = context;
                this.notification = documents;
            }

            @NonNull
            @Override
            public  notificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_recycler_card, parent, false);
                return new  notificationViewHolder(view);

            }
            @Override
            public void onBindViewHolder(@NonNull notificationViewHolder holder, int position) {


                NotificationModel notification = this.notification.get(position);
                holder.notification_desc.setText(notification.getEventDesc() + " " + notification.getEventType());
                holder.notifApproxDate.setText(Utility.getApproxDate(notification.getDateUpdated()));

                if (notification.getReadStatus().equals("0")){
                    int colorCompat = ContextCompat.getColor(context, R.color.notifyBlue);
                    holder.card.setBackgroundTintList(ColorStateList.valueOf(colorCompat));
                    holder.notification_desc.setTextColor(Color.WHITE);
                    holder.notifApproxDate.setTextColor(Color.WHITE);
                    holder.notifyImage.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.baseline_circle_unread_notifications_24));
                }




                holder.card.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Button gotoShortcut, cancel;
                        TextView notifyType, notifyDesc, notifyDate;


                        final Dialog dialog = new Dialog(context);


                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setContentView(R.layout.popup_notification);
                        dialog.setCancelable(false);


                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                        gotoShortcut = dialog.findViewById(R.id.request_popup_confirm_request);
                        cancel = dialog.findViewById(R.id.notification_cancel);
                        notifyType = dialog.findViewById(R.id.notification_type);
                        notifyDesc = dialog.findViewById(R.id.notification_desc);
                        notifyDate = dialog.findViewById(R.id.notification_date);

                        notifyDate.setText(Utility.getApproxDate(notification.getDateNotified()));
                        notifyType.setText(notification.getEventType());
                        notifyDesc.setText(Utility.notificationText(notification.getFrom_userName(), notification.getEventType(), notification.getEventDesc()));
                        gotoShortcut.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                dialog.dismiss();

                                if (notification.getEventType().equals("Request")){

                                     System.out.println("Event ID:" + notification.getEventID());
                                     Utility.updateNotifReadStatus(context, notification.getNotificationID());
                                     Utility.fetchParticularRequest(context, notification.getEventID());

                                } else if (notification.getEventType().equals("Collection")) {

                                    System.out.println("Event ID:" + notification.getEventID());
                                    Utility.updateNotifReadStatus(context, notification.getNotificationID());
                                    Utility.fetchParticularCollection(context, notification.getEventID());

                                } else {
                                    document_list_page.filterText = notification.getEventID();
                                    Utility.updateNotifReadStatus(context, notification.getNotificationID());
                                    Intent intent = new Intent(context, document_list_page.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                    context.startActivity(intent);

                                }
                            }
                        });

                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });
                        dialog.show();
                        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    }
                });

            }
            @Override
            public int getItemCount() {
                return notification.size();
            }
}

class notificationViewHolder extends RecyclerView.ViewHolder{

    ImageView notifyImage;
    TextView notification_desc, notifApproxDate;
    CardView card;


    public notificationViewHolder(@NonNull View itemView){
        super(itemView);


        card = itemView.findViewById(R.id.notification_recycler_card);
        notifyImage = itemView.findViewById(R.id.notificationIcon);
        notification_desc = itemView.findViewById(R.id.notif_desc);
        notifApproxDate = itemView.findViewById(R.id.notif_date);


    }





}
