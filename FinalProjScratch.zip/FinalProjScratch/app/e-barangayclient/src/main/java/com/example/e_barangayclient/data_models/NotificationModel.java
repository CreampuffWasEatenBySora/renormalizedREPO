package com.example.e_barangayclient.data_models;

//Basically, parang form to. Parang questionnaire.

public class NotificationModel {

    private  String dateUpdated;
    private String notificationID;

    private String dateNotified;
    private String from_userName;

    private String readStatus;
    private String eventID;
    private String eventType;
    private String eventDesc;


    public String getNotificationID() { return notificationID; }

    public String getDateUpdated() {
        return dateUpdated;
    }

    public String getDateNotified() { return dateNotified; }
    public String getFrom_userName() { return from_userName; }


    public String getReadStatus() { return readStatus; }
    public String getEventID() { return eventID; }
    public String getEventDesc() { return eventDesc; }
    public String getEventType() { return eventType; }

    public void setReadStatus(String readStatus){

        this.readStatus = readStatus;
    }




    public NotificationModel(String notificationID,
                             String dateNotified,
                             String dateUpdated,
                             String fromUserName,
                             String eventID,
                             String eventType,
                             String eventDesc,
                             String status){

        this.notificationID = notificationID;
        this.dateUpdated = dateUpdated;
        this.dateNotified = dateNotified;
        this.from_userName = fromUserName;
        this.eventType = eventType;
        this.eventID = eventID;
        this.readStatus = status;
        this.eventDesc = eventDesc;


    }

    public NotificationModel(){

    }

}


