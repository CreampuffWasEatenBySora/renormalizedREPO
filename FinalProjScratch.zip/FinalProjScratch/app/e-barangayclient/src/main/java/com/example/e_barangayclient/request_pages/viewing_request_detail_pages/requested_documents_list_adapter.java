package com.example.e_barangayclient.request_pages.viewing_request_detail_pages;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_barangayclient.R;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.request_pages.request_purpose_select_SpinnerAdapter;
import com.example.e_barangayclient.request_pages.request_utilities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class requested_documents_list_adapter extends RecyclerView.Adapter<requested_documents_viewholder> {


    final int[] spinnerIndex = {0};
    public Activity activity;
    public Context context;
    private List<RequestedDocumentModel> requestedDocuments;
    private cameraActionListener cameraActionListener;

            public requested_documents_list_adapter(Context context, List<RequestedDocumentModel> requestedDocuments, Activity activity, cameraActionListener cameraActionListener) {
                this.context = context;
                this.activity = activity;
                this.cameraActionListener = cameraActionListener;
                this.requestedDocuments = requestedDocuments;
            }

            @NonNull
            @Override
            public requested_documents_viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.requested_document_recycler_card, parent, false);
                return new requested_documents_viewholder(view);

            }

            @Override
            public void onBindViewHolder(@NonNull requested_documents_viewholder holder, int position) {



                RequestedDocumentModel document = requestedDocuments.get(position);
                HashMap<String, documentRequirementModel> requirements = document.getRequirements();



                int submittedReqs = 0;
                holder.requirementList.clear();
                for (Map.Entry<String, documentRequirementModel> entry : requirements.entrySet()){
                    holder.requirementList.add(entry.getValue());

                    if (entry.getValue().getRequirement_image() != null){
                        submittedReqs ++;
                        System.out.println("Requirement image found: " + entry.getValue().getRequirement_name());
                    } else {
                        System.out.println("Requirement image not found!");
                    }

                }

                if (submittedReqs == requirements.size()){

                    holder.requirement_counter.setText("Completed.");
                    holder.requirement_counter.setTextColor(Color.GREEN);
                } else {
                    holder.requirement_counter.setText(submittedReqs + " out of " + requirements.size() );
                    holder.requirement_counter.setTextColor(Color.RED
                    );

                }


                System.out.println("Requirement:" + holder.requirementList);

                List<String> purpose_list = new ArrayList<>(Arrays.asList(
                        "Scholarship",
                        "Employment",
                        "Business",
                        "Requirement For Another Barangay Document",
                        "Other"));

                request_purpose_select_SpinnerAdapter spinner_adapter = new  request_purpose_select_SpinnerAdapter(context, purpose_list);
                holder.edit_purpose.setAdapter(spinner_adapter);

                holder.edit_purpose.setSelection(purpose_list.indexOf(document.getPurpose()));

                holder.edit_purpose.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
                {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
                    {
                        //Change the selected item's text color

                        document.setPurpose(holder.edit_purpose.getSelectedItem().toString());

                     }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent)
                    {
                    }
                });


                holder.edit_purpose.setSelection(purpose_list.indexOf(document.getPurpose()));

                holder.requested_doc_name.setText(document.getDocName());
                if (!request_utilities.request.getStatus().equals("New")){
                    holder.detailsBox.setVisibility(View.GONE);
                    holder.requested_document_status.setVisibility(View.VISIBLE);

                    holder.editBox.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                                Button  cancel;
                                TextView documentName, documentPurpose;


                                final Dialog dialog = new Dialog(context);


                                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialog.setContentView(R.layout.popup_requested_document_reason);
                                dialog.setCancelable(false);


                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                                cancel = dialog.findViewById(R.id.request_popup_confirm);
                                documentName = dialog.findViewById(R.id.popup_requested_document_name);
                                documentPurpose = dialog.findViewById(R.id.popup_requested_document_purpose);
                                documentName.setText(document.getDocName());
                                documentPurpose.setText(document.getPurpose());


                                cancel.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialog.dismiss();
                                    }
                                });


                                dialog.show();
                                dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);


                        }


                    });

                }
                holder.detailsDropdown.setChecked(false);

                holder.detailsDropdown.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (!isChecked){
                            holder.detailsBox.setVisibility(View.GONE);
                            System.out.println("unchecked");
                        } else {
                            holder.detailsBox.setVisibility(View.VISIBLE);
                            System.out.println("checked");

                        }
                    }
                });




                holder.delete.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        AlertDialog.Builder removeDocumentDialog;
                        removeDocumentDialog = new AlertDialog.Builder(context);

                        removeDocumentDialog.setTitle("Remove document?");
                        removeDocumentDialog.setMessage("Remove this document from your request form. You can still include it later.");

                        removeDocumentDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();
                                request_utilities.temporary_documentList.remove(position);
                                request_utilities.temporary_requested_document_list.remove(position);
                                requested_document_list_page.populateNewRequestList();

                            }});

                        removeDocumentDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();

                            }});

                        Dialog dialog = removeDocumentDialog.create();
                        dialog.show();

                    }
                });


                holder.quantityPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
                    @Override
                    public void onValueChange(NumberPicker picker, int oldVal, int newVal) {


                        document.setQuantity(holder.quantityPicker.getValue());


                    }
                });
                holder.detailsBox.setVisibility(View.GONE);


            }



            @Override
            public int getItemCount() {
                return requestedDocuments.size();
            }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

    }
}



class requested_documents_viewholder extends RecyclerView.ViewHolder{

    TextView requested_doc_name, requested_document_status, requirement_counter;
    ImageButton  delete;
    Spinner edit_purpose;
    CheckBox detailsDropdown;
    NumberPicker quantityPicker;
    CardView requestCard;
    LinearLayout editBox, detailsBox;
    List<documentRequirementModel> requirementList = new ArrayList<>();

    requirements_list_adapter adapter;
    public requested_documents_viewholder(@NonNull View itemView){
        super(itemView);


        requestCard = itemView.findViewById(R.id.requested_document_card);
        requested_doc_name = itemView.findViewById(R.id.requested_document_name);
        delete = itemView.findViewById(R.id.requested_document_delete);
        edit_purpose = itemView.findViewById(R.id.request_reason);
        detailsDropdown = itemView.findViewById(R.id.request_dropdown);
        detailsBox = itemView.findViewById(R.id. requestCard_detailsBox);

        requested_document_status = itemView.findViewById(R.id.requested_document_status);
        editBox = itemView.findViewById(R.id.requested_document_editBox);
        requirement_counter = itemView.findViewById(R.id.requested_document_requirement_counter);
        quantityPicker = itemView.findViewById(R.id.requested_document_quantity);
        quantityPicker.setMinValue(1);
        quantityPicker.setMaxValue(5);

        requested_document_status.setVisibility(View.GONE);



    }



}
