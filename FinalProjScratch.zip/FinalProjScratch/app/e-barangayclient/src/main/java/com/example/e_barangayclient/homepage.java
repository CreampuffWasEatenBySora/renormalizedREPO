package com.example.e_barangayclient;

import static com.example.e_barangayclient.Utility.APILINK;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_barangayclient.collectionPages.collection_list_page;
import com.example.e_barangayclient.data_models.AccountModel;
// import com.example.e_barangayclient.request_pages.request_list_page;
import com.example.e_barangayclient.data_models.AvailableDocumentModel;
import com.example.e_barangayclient.data_models.RequestFormModel;
import com.example.e_barangayclient.data_models.RequestedDocumentModel;
import com.example.e_barangayclient.data_models.documentRequirementModel;
import com.example.e_barangayclient.document_pages.document_list_page;
import com.example.e_barangayclient.notification_pages.notification_list_page;
import com.example.e_barangayclient.request_pages.request_list_page;
import com.example.e_barangayclient.signup_pages.signup_base_page;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


public class homepage extends AppCompatActivity {

    public static AccountModel currentAccount = new AccountModel();

    ImageButton  logOutButton, detailsButton, information, documentButton;
    LinearLayout  requestButton, collectionButton;
    ImageView status_icon;

    TextView greetingText, statusText , pendingTitle;
    LinearLayout userPanel, pendingMessage, notificationPanel;


    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {


                    System.out.println("You can now receive notilkmpfications!");


                } else {
                    System.out.println("No notifications, that's alright!");

                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        Utility.createNotificationChannel(this);
        Utility.fetchNotifications(currentAccount.getUUID(), homepage.this);

        //   setNewToken(currentAccount.getUUID(),currentAccount.getAccessToken(),homepage.this);
        setGreeting();
    //    askNotificationPermission();
        setUpComponents();
     //   checkforTutorials();


        notificationPanel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), notification_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);

            }
        });

        documentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(homepage.this, document_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                homepage.this.startActivity(intent);
            }
        });

        requestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), request_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);

            }
        });

        collectionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), collection_list_page.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);

            }
        });

        logOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FirebaseMessaging.getInstance().deleteToken().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }
                    }
                });
            }
        });

        detailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                account_details.account = currentAccount;
                Intent intent = new Intent(getApplicationContext(), account_details.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

//        information.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                readyHomepageTutorial();
//            }
//        });

    }

//    private void checkforTutorials() {
//        if (currentAccount.getTutorialsSeen() != null){
//
//            if (!currentAccount.getTutorialsSeen().contains("homepage")){
//                readyHomepageTutorial();
//
//            }
//    } else {
//            readyHomepageTutorial();
//        }
//
//    }



    void setUpComponents(){

        // accountsButton = findViewById(R.id.home_manageAccounts);
        //  documentsButton = findViewById(R.id.home_manageDocuments);
        information = findViewById(R.id.informationButton);
        notificationPanel = findViewById(R.id.notification_container);
        documentButton = findViewById(R.id.home_Documents);
        requestButton = findViewById(R.id.home_manageRequests);
        collectionButton = findViewById(R.id.home_manageCollections);
        logOutButton = findViewById(R.id.panel_exit);
        detailsButton = findViewById(R.id.panel_setting);
        userPanel = findViewById(R.id.homepage_userPanel);
        pendingMessage = findViewById(R.id.homepage_pending);
        status_icon = findViewById(R.id.homepage_status_icon);
        statusText = findViewById(R.id.homepage_status_message);
        pendingTitle =  findViewById(R.id.homepage_status_title);

//        if (currentAccount.getStatus().equals("Pending")){
//
//            userPanel.setVisibility(View.GONE);
//            pendingMessage.setVisibility(View.VISIBLE);
//
//        } else if (currentAccount.getStatus().equals("Rejected")) {
//            userPanel.setVisibility(View.GONE);
//            pendingMessage.setVisibility(View.VISIBLE);
//
//            status_icon.setImageResource(R.drawable.rejected_icon);
//            statusText.setText("Due to "+ currentAccount.getRegDetails().getRemarks() +" your account was rejected by "+ currentAccount.getRegDetails().getConfirmer() +". \n\nAfter fixing this issue, you can apply again.");
//            pendingTitle.setText("Rejected");
//
//        }

    }

    void setGreeting(){

        greetingText = findViewById(R.id.homepage_greeting);

                greetingText.setText("Welcome, " + currentAccount.getFullName() + "!");

    }


//    public void SQLRequestFetch(){
//
//        JSONObject postData = new JSONObject();
//
//        RequestQueue queue = Volley.newRequestQueue(homepage.this);
//        String url ="http://192.168.56.1/example-app/public/api/fetchRequests ";
//
//
//        try {
//
//            postData.put("userID", currentAccount.getUUID());
//
//        } catch (Exception e){
//            e.printStackTrace();
//        }
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
//                new com.android.volley.Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        try {
//                            JSONObject jsonResponse = new JSONObject(response);
//                            String status = jsonResponse.getString("status");
//                            String message = jsonResponse.getString("message");
//                            JSONArray request_data = jsonResponse.getJSONArray("request_data");
//
//
//                            System.out.println(request_data);
//                            List<RequestFormModel> request_forms_list = new ArrayList<>();
//
//                            if ("success".equals(status)) {
//
//
//                                for (int i = 0; i < request_data.length() ; i++) {
//
//                                    JSONObject request = request_data.getJSONObject(i);
//                                    HashMap<String, RequestedDocumentModel> requested_document_list = new HashMap<>();
//                                    JSONArray requested_documents = request.getJSONArray("requested_doc");
//
//                                    for (int j = 0; j < requested_documents.length(); j++) {
//
//                                        JSONObject document = requested_documents.getJSONObject(j);
//                                        RequestedDocumentModel requested_document_entry = new RequestedDocumentModel(
//                                                request.getString("requestID"),
//                                                document.getString("docName"),
//                                                document.getString("remarks"),
//                                                document.getInt("quantity"),
//                                                null,
//                                                document.getString("status"),
//                                                document.getString("remarks")
//                                        );
//
//                                        requested_document_list.put(document.getString("docName"), requested_document_entry);}
//
//                                    RequestFormModel request_form = new RequestFormModel(
//                                            request.getString("requestID"),
//                                            request.getString("requestCode"),
//                                            requested_document_list,
//                                            request.getString("dateRequested"),
//                                            request.getString("dateResponded"),
//                                            request.getString("officerName"),
//                                            request.getString("status"),
//                                            request.getString("remarks")
//                                    );
//
//                                    request_forms_list.add(request_form);
//
//                                }
//
//                                System.out.println(request_forms_list);
//
//                            } else {
//                                Toast.makeText(homepage.this, message, Toast.LENGTH_SHORT).show();
//                            }
//
//                        } catch (Exception e) {
//                            System.out.println("ERROR HERE");
//                            e.printStackTrace();
//                        }
//
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                error.printStackTrace();
//
//            }
//        }){
//            @Override
//            public byte[] getBody() {
//                return postData.toString().getBytes();
//            }
//
//            @Override
//            public String getBodyContentType() {
//                return "application/json";
//            }
//        };
//
//        queue.add(stringRequest);
//
//    }

    public void SQLdocumentFetch(){


        RequestQueue queue = Volley.newRequestQueue(homepage.this);
        String url = APILINK+"/fetchDocuments";
        JSONObject postData = new JSONObject();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");
                            JSONObject document_data = jsonResponse.getJSONObject("document_data");
                            JSONObject documents = document_data.getJSONObject("documents");
                            List<AvailableDocumentModel> availableDocuments = new ArrayList<>();

                            if ("success".equals(status)) {


                                JSONArray doc_keys = documents.names();

                                for (int i = 0; i < doc_keys.length() ; i++) {

                                    AvailableDocumentModel availableDocument = new AvailableDocumentModel();

                                    String key = doc_keys.getString (i);
                                    JSONObject document = documents.getJSONObject(key);
                                    availableDocument.setDocumentID(document.getString("id"));
                                    availableDocument.setDocName(document.getString("name"));
                                    availableDocument.setDocumentDescription(document.getString("description"));

                                    HashMap<String, documentRequirementModel> requirement_list = new HashMap<>();
                                    JSONObject requirements = document.getJSONObject("requirements");

                                    JSONArray req_keys = requirements.names();

                                    for (int j = 0; j < requirements.length(); j++) {

                                       String req_key = req_keys.getString(j);

                                        JSONObject requirement = requirements.getJSONObject(req_key);
                                        documentRequirementModel requirement_entry =  new documentRequirementModel(
                                                requirement.getString("id"),
                                                requirement.getString("name"),
                                                null,
                                                requirement.getString("description"), null
                                        );

                                        requirement_list.put( requirement.getString("name"), requirement_entry);


                                    }
                                    availableDocument.setRequirements(requirement_list);
                                    availableDocuments.add(availableDocument);



                                }

                                System.out.println(availableDocuments);

                            } else {
                                Toast.makeText(homepage.this, message, Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            System.out.println("ERROR HERE");
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            @Override
            public byte[] getBody() {
                return postData.toString().getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(stringRequest);

    }




//    void sendNotification(String message, String recipient){
//
//        // Username, message, current userID, and recipient token
//
//        AccountModel currentUser = homepage.currentAccount;
//
//        try {
//            JSONObject jsonObject = new JSONObject();
//            JSONObject notifObject = new JSONObject();
//            notifObject.put("title", "Testing notification");
//            notifObject.put("body", message);
//
//            JSONObject dataObject = new JSONObject();
//            dataObject.put("userId", currentUser.getUUID());
//
//            jsonObject.put("notification", notifObject);
//            jsonObject.put("data", dataObject);
//            jsonObject.put("to", currentUser.getAccessToken());
//
//            System.out.println("sent to token: " + currentUser.getAccessToken());
//            callApi(jsonObject);
//        } catch (Exception e ){
//            System.out.println("Error: " + e);
//        }
//
//
//
//    }

//    void callApi(JSONObject jsonObject){
//        MediaType JSON = MediaType.get("application/json; charset=utf-8");
//
//        OkHttpClient client = new OkHttpClient();
//        String url = "https://fcm.googleapis.com/fcm/send";
//        RequestBody body = RequestBody.create(jsonObject.toString(), JSON);
//
//        Request request = new Request.Builder()
//                .url(url)
//                .post(body)
//                .header("Authorization", "Bearer AAAANw_N_io:APA91bEiwZMysEcbEyJhSdmvmOBeVPYQGfsu1JcPCpwykYbHKuurmKnP3vi-pj2UTIQ9YeyL5m8VX1WhkcQC4oe5GSp6mxOmyaA-QQAJ7wihhKS0XApwVEANub2ZyKZBmZGWmOWGi-TH")
//                .build();
//        client.newCall(request).enqueue(new Callback() {
//            @Override
//            public void onFailure(@NonNull Call call, @NonNull IOException e) {
//
//            }
//
//            @Override
//            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
//
//            }
//        });
//
//    }
//
//    private void askNotificationPermission() {
//        // This is only necessary for API level >= 33 (TIRAMISU)
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
//                    PackageManager.PERMISSION_GRANTED) {
//
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                    // Create the NotificationChannel
//                    CharSequence name = "Notification Channel Name";
//                    String description = "Notification Channel Description";
//                    int importance = NotificationManager.IMPORTANCE_DEFAULT;
//                    NotificationChannel channel = new NotificationChannel("notifSample", name, importance);
//                    channel.setDescription(description);
//
//                    // Register the channel with the system
//                    NotificationManager notificationManager = getSystemService(NotificationManager.class);
//                    notificationManager.createNotificationChannel(channel);
//                }
//
//                System.out.println("You can now receive notifications!" );
//
//            } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
//
//                System.out.println("Permission is needed" );
//
//
//            } else {
//                // Directly ask for the permission
//                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
//                System.out.println("You are now asked to enable receive notifications!" );
//
//            }}}

//    void readyHomepageTutorial(){
//
//        Button next;
//        TabLayout StepTabLayout;
//        TextView stepText, appTitle;
//        ImageView stepImage;
//
//        final Dialog dialog = new Dialog(this);
//
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.popup_tutorial_welcome_document);
//        dialog.setCancelable(false);
//
//        next = dialog.findViewById(R.id.next_button);
//        StepTabLayout = dialog.findViewById(R.id.tutorialTab);
//        stepImage  = dialog.findViewById(R.id.stepImage);
//        stepText = dialog.findViewById(R.id.stepBox);
//        appTitle = dialog.findViewById(R.id.appTitle);
//
//        StepTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                switch (tab.getPosition()) {
//                    case 0:
//                        stepImage.setImageResource(R.drawable.logo_white_border);
//                        stepText.setText("Welcome to");
//                        appTitle.setText("Barangay E-Connect!");
//                        appTitle.setVisibility(View.VISIBLE);
//                        break;
//
//                    case 1:
//                        stepImage.setImageResource(R.drawable.welcome_icon1);
//                        stepText.setText("This app is designed to make Barangay transactions digital!");
//                        appTitle.setVisibility(View.GONE);
//                        break;
//
//                    case 2:
//                        stepImage.setImageResource(R.drawable.welcome_icon2);
//                        stepText.setText("And to Make acquiring documents more convenient and well-documented!");
//                        appTitle.setVisibility(View.GONE);
//                        break;
//
//                    case 3:
//                        stepImage.setImageResource(R.drawable.welcome_icon3);
//                        stepText.setText("Are you ready?");
//                        appTitle.setText("Click the button below to start!");
//                        appTitle.setVisibility(View.VISIBLE);
//
//                        break;
//
//                    default:
//                        stepImage.setImageResource(R.drawable.logo_white_border);
//                        stepText.setText("Welcome to");
//                        appTitle.setText("Barangay E-Connect!");
//                        appTitle.setVisibility(View.VISIBLE);
//                }
//            }
//
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {}
//
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {}
//        });
//
//        for (int i = 0; i < StepTabLayout.getTabCount(); i++) {
//            TextView tabTextView = (TextView) LayoutInflater.from(this).inflate(R.layout.bullet_empty_tab, null);
//            tabTextView.setText("");
//            StepTabLayout.getTabAt(i).setCustomView(tabTextView);
//        }
//
//
////        next.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                int tab = StepTabLayout.getSelectedTabPosition();
////                System.out.println("Selected tab: " + tab + " and tab count:" + StepTabLayout.getTabCount()  );
////                if (StepTabLayout.getTabCount() > tab+1){
////                    TabLayout.Tab selectTab = StepTabLayout.getTabAt(tab + 1);
////                    selectTab.select();
////                } else {
////
////                    if (currentAccount.getTutorialsSeen() != null){
////
////                        currentAccount.getTutorialsSeen().add("homepage");
////                        Map<String, Object> updateMap = new HashMap<>();
////                        updateMap.put("Accounts/"+ currentAccount.getUUID() +"/tutorialsSeen", currentAccount.getTutorialsSeen());
////                        Utility.updateFirebaseData(updateMap,homepage.this , null, null);
////                        dialog.dismiss();
////
////                    } else {
////                       List<String> getTutorialsSeen = new ArrayList<>();
////                       getTutorialsSeen.add("homepage");
////                       Map<String, Object> updateMap = new HashMap<>();
////                       updateMap.put("Accounts/"+ currentAccount.getUUID() +"/tutorialsSeen",  getTutorialsSeen);
////                       Utility.updateFirebaseData(updateMap,homepage.this, null, null);
////                       dialog.dismiss();
////                    }
////
////
////                }
////
////            }
////        });
//
//        dialog.show();
//        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
//
//    }

//    void setNewToken(String userId, String formerToken, Context context){
//
//        //Along with notification permission and settings, also manage token generation here:
//        FirebaseMessaging firebaseMessaging = FirebaseMessaging.getInstance();
//        FirebaseMessaging.getInstance().getToken()
//                .addOnCompleteListener(new OnCompleteListener<String>() {
//                    @Override
//                    public void onComplete(@NonNull Task<String> task) {
//                        if (!task.isSuccessful()) {
//                            System.out.println("Token is not received... " );
//                            return;
//                        }
//
//
//                        // Get new FCM registration token
//                        String token = task.getResult();
//                        System.out.println("Token is successfully received: " + token);
//                        MyFirebaseMessagingService.updateTokenInDatabase(token, formerToken, userId, context);
//
//                    }
//                }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//                        System.out.println("Token generation failed!: " + e);
//
//                    }
//                });
//
//
//    }



}