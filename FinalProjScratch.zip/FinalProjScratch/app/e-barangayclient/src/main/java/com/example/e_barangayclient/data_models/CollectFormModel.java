package com.example.e_barangayclient.data_models;

//Basically, parang form to. Parang questionnaire.

import java.util.HashMap;

public class CollectFormModel {

    private String collectionId;

    private String dateScheduled;
    private String dateCollected;

    private String status;
    private String officerName;
    private String remarks;
    private RequestFormModel request = new RequestFormModel();




    public String getCollectionId() { return collectionId; }

    public RequestFormModel getRequest() {
        return request;
    }

    public String getDateScheduled() { return dateScheduled; }
    public String getDateCollected() { return dateCollected; }


    public String getStatus() { return status; }
    public String getRemarks() { return remarks; }
    public String getOfficerName() { return officerName; }

    public void setStatus(String status){

        this.status = status;
    }


    public void setRequest(RequestFormModel request) {
        this.request = request;
    }


    public CollectFormModel(String collectionId,
                            String dateScheduled,
                            String dateCollected,
                            RequestFormModel request,
                            String confirmerName,
                            String status,
                            String remarks){

        this.collectionId = collectionId;
        this.request = request;
        this.dateScheduled = dateScheduled;
        this.dateCollected = dateCollected;
        this.officerName = confirmerName;
        this.status = status;
        this.remarks = remarks;


    }

    public CollectFormModel(){

    }

}


